package com.borntocraft.typewriter.adminmode.server

import com.borntocraft.typewriter.adminmode.protocol.Capability
import com.borntocraft.typewriter.adminmode.protocol.ErrorCode
import com.borntocraft.typewriter.adminmode.protocol.MutationEnvelope
import com.borntocraft.typewriter.adminmode.protocol.Operation
import com.borntocraft.typewriter.adminmode.protocol.PreviewSnapshot
import com.borntocraft.typewriter.adminmode.protocol.SessionMode
import com.borntocraft.typewriter.adminmode.protocol.EditorPresence
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

public sealed interface Outcome<out T> {
    data class Ok<T>(val value: T) : Outcome<T>
    data class Denied(val code: ErrorCode, val reason: String) : Outcome<Nothing>
}

/**
 * Connection epochs, edit sessions, optimistic revisions and replay protection.
 *
 * Everything here is pure state with no Bukkit types, so it can be exercised from unit tests and
 * touched from any thread — which matters because plugin messages arrive off the main thread.
 */
public class AdminSessions(private val now: () -> Long = System::currentTimeMillis) {
    /** A session left untouched for this long is reclaimed, so a crashed client frees its target. */
    private val sessionTtlMillis = 5 * 60 * 1000L

    /** Bounded per session; enough to absorb reordering without growing without limit. */
    private val rememberedRequests = 256

    private val random = SecureRandom()
    private val epochs = AtomicLong(0)

    data class Connection(
        val epoch: Long,
        val nonce: Long,
        val offered: Set<Capability>,
        @Volatile var granted: Set<Capability> = emptySet(),
        @Volatile var confirmed: Boolean = false,
    )

    class Session(
        val id: String,
        val owner: UUID,
        val epoch: Long,
        val targetId: String,
        val mode: SessionMode,
        val playerName: String,
        @Volatile var revision: Long,
        @Volatile var lastSequence: Long = -1,
        @Volatile var touchedAt: Long,
    ) {
        val undoStack: ArrayDeque<Long> = ArrayDeque()
        val seenRequests: LinkedHashSet<Long> = LinkedHashSet()
        @Volatile var preview: PreviewSnapshot? = null
        @Volatile var lastPreviewAt: Long = Long.MIN_VALUE
    }

    private val connections = ConcurrentHashMap<UUID, Connection>()
    private val sessions = ConcurrentHashMap<String, Session>()
    private val targetOwners = ConcurrentHashMap<String, String>()

    public data class PreviewState(
        val sessionId: String,
        val targetId: String,
        val playerId: UUID,
        val playerName: String,
        val operation: Operation,
    ) {
        fun snapshot(): PreviewSnapshot = PreviewSnapshot(sessionId, targetId, playerId.toString(), playerName, operation)
    }

    // ------------------------------------------------------------------ handshake

    /** A fresh epoch per handshake invalidates every frame still in flight from a previous one. */
    fun beginHandshake(player: UUID, offered: Set<Capability>): Connection {
        closeAll(player)
        val connection = Connection(epochs.incrementAndGet(), random.nextLong(), offered)
        connections[player] = connection
        return connection
    }

    fun confirmNonce(player: UUID, nonce: Long): Boolean {
        val connection = connections[player] ?: return false
        if (connection.nonce != nonce) return false
        connection.confirmed = true
        return true
    }

    fun connection(player: UUID): Connection? = connections[player]

    fun ready(player: UUID): Connection? = connections[player]?.takeIf(Connection::confirmed)

    // ------------------------------------------------------------------ sessions

    fun open(
        player: UUID,
        epoch: Long,
        targetId: String,
        revision: Long,
        mode: SessionMode,
        playerName: String = "",
    ): Outcome<Session> {
        val connection = ready(player)
            ?: return Outcome.Denied(ErrorCode.UNKNOWN_SESSION, "Handshake not completed")
        if (connection.epoch != epoch) {
            return Outcome.Denied(ErrorCode.STALE_EPOCH, "Connection epoch has been superseded")
        }
        expire()

        if (mode == SessionMode.READ_WRITE) {
            val existingId = targetOwners[targetId]
            if (existingId != null) {
                val existing = sessions[existingId]
                if (existing != null && existing.owner != player) {
                    return Outcome.Denied(ErrorCode.REVISION_CONFLICT, "Target is locked by another editor")
                }
                if (existing != null) {
                    existing.touchedAt = now()
                    return Outcome.Ok(existing)
                }
                targetOwners.remove(targetId, existingId)
            }
        }

        val session = Session(
            id = UUID.randomUUID().toString(),
            owner = player,
            epoch = epoch,
            targetId = targetId,
            mode = mode,
            playerName = playerName,
            revision = revision,
            touchedAt = now(),
        )
        if (mode == SessionMode.READ_WRITE && targetOwners.putIfAbsent(targetId, session.id) != null) {
            return Outcome.Denied(ErrorCode.REVISION_CONFLICT, "Target is locked by another editor")
        }
        sessions[session.id] = session
        return Outcome.Ok(session)
    }

    /**
     * Full envelope check. Order matters: identity, then liveness, then ordering, then revision,
     * so a stale frame can never be mistaken for a conflict on current data.
     */
    fun validate(player: UUID, envelope: MutationEnvelope, targetId: String): Outcome<Session> {
        val session = sessions[envelope.sessionId]
            ?: return Outcome.Denied(ErrorCode.UNKNOWN_SESSION, "Unknown session")
        if (session.owner != player) {
            return Outcome.Denied(ErrorCode.UNKNOWN_SESSION, "Session belongs to another player")
        }
        if (session.targetId != targetId) {
            return Outcome.Denied(ErrorCode.UNKNOWN_TARGET, "Session does not cover this target")
        }
        val connection = ready(player)
            ?: return Outcome.Denied(ErrorCode.STALE_EPOCH, "Connection is no longer active")
        if (connection.epoch != envelope.connectionEpoch || session.epoch != envelope.connectionEpoch) {
            return Outcome.Denied(ErrorCode.STALE_EPOCH, "Frame belongs to a previous connection")
        }
        if (session.mode != SessionMode.READ_WRITE) {
            return Outcome.Denied(ErrorCode.NO_PERMISSION, "Session is read-only")
        }
        synchronized(session) {
            if (envelope.sequence <= session.lastSequence) {
                return Outcome.Denied(ErrorCode.OUT_OF_SEQUENCE, "Replayed or reordered frame")
            }
            if (!session.seenRequests.add(envelope.requestId)) {
                return Outcome.Denied(ErrorCode.OUT_OF_SEQUENCE, "Duplicate request id")
            }
            while (session.seenRequests.size > rememberedRequests) {
                session.seenRequests.iterator().let { if (it.hasNext()) { it.next(); it.remove() } }
            }
            if (session.revision != envelope.baseRevision) {
                return Outcome.Denied(ErrorCode.REVISION_CONFLICT, "Target moved to revision ${session.revision}")
            }
            session.lastSequence = envelope.sequence
            session.touchedAt = now()
        }
        return Outcome.Ok(session)
    }

    /** Validates a transient preview without touching the persisted revision or Typewriter data. */
    fun acceptPreview(
        player: UUID,
        sessionId: String,
        epoch: Long,
        sequence: Long,
        targetId: String,
        baseRevision: Long,
        operation: Operation,
    ): Outcome<PreviewState> {
        val session = sessions[sessionId]
            ?: return Outcome.Denied(ErrorCode.UNKNOWN_SESSION, "Unknown session")
        if (session.owner != player || session.targetId != targetId) {
            return Outcome.Denied(ErrorCode.UNKNOWN_SESSION, "Session does not belong to this player and target")
        }
        val connection = ready(player)
            ?: return Outcome.Denied(ErrorCode.STALE_EPOCH, "Connection is no longer active")
        if (connection.epoch != epoch || session.epoch != epoch) {
            return Outcome.Denied(ErrorCode.STALE_EPOCH, "Frame belongs to a previous connection")
        }
        if (session.mode != SessionMode.READ_WRITE) {
            return Outcome.Denied(ErrorCode.NO_PERMISSION, "Session is read-only")
        }
        synchronized(session) {
            if (sequence <= session.lastSequence) {
                return Outcome.Denied(ErrorCode.OUT_OF_SEQUENCE, "Replayed or reordered preview")
            }
            if (session.revision != baseRevision) {
                return Outcome.Denied(ErrorCode.REVISION_CONFLICT, "Target moved to revision ${session.revision}")
            }
            session.lastSequence = sequence
            session.touchedAt = now()
            val timestamp = now()
            if (session.lastPreviewAt != Long.MIN_VALUE &&
                timestamp - session.lastPreviewAt < PREVIEW_MIN_INTERVAL_MILLIS
            ) {
                return Outcome.Denied(ErrorCode.RATE_LIMITED, "Preview coalesced")
            }
            session.lastPreviewAt = timestamp
            val state = PreviewState(session.id, session.targetId, session.owner, session.playerName, operation)
            session.preview = state.snapshot()
            return Outcome.Ok(state)
        }
    }

    /** Clears a preview using the same session/epoch/sequence checks as an edit stream. */
    fun clearPreview(
        player: UUID,
        sessionId: String,
        epoch: Long,
        sequence: Long,
        targetId: String,
    ): Outcome<PreviewSnapshot?> {
        val session = sessions[sessionId]
            ?: return Outcome.Denied(ErrorCode.UNKNOWN_SESSION, "Unknown session")
        if (session.owner != player || session.targetId != targetId) {
            return Outcome.Denied(ErrorCode.UNKNOWN_SESSION, "Session does not belong to this player and target")
        }
        val connection = ready(player)
            ?: return Outcome.Denied(ErrorCode.STALE_EPOCH, "Connection is no longer active")
        if (connection.epoch != epoch || session.epoch != epoch) {
            return Outcome.Denied(ErrorCode.STALE_EPOCH, "Frame belongs to a previous connection")
        }
        synchronized(session) {
            if (sequence <= session.lastSequence) {
                return Outcome.Denied(ErrorCode.OUT_OF_SEQUENCE, "Replayed or reordered preview clear")
            }
            session.lastSequence = sequence
            session.touchedAt = now()
            val previous = session.preview
            session.preview = null
            return Outcome.Ok(previous)
        }
    }

    /** Clears server-side preview state after a commit, disconnect or explicit session close. */
    fun clearStoredPreview(sessionId: String): PreviewSnapshot? = sessions[sessionId]?.let { session ->
        synchronized(session) {
            val previous = session.preview
            session.preview = null
            previous
        }
    }

    /** Called only after the adapter accepted the mutation, so revisions track real writes. */
    fun recordCommit(session: Session): Long = synchronized(session) {
        session.undoStack.addLast(session.revision)
        session.revision += 1
        session.touchedAt = now()
        session.revision
    }

    fun recordUndo(session: Session): Outcome<Long> = synchronized(session) {
        val previous = session.undoStack.removeLastOrNull()
            ?: return Outcome.Denied(ErrorCode.REVISION_CONFLICT, "Nothing to undo in this session")
        // Undo is a new commit, never a rewind: the revision keeps moving forward.
        session.revision += 1
        session.touchedAt = now()
        Outcome.Ok(previous)
    }

    fun close(player: UUID, sessionId: String): PreviewSnapshot? {
        val session = sessions[sessionId] ?: return null
        if (session.owner != player) return null
        val previous = clearStoredPreview(sessionId)
        sessions.remove(sessionId)
        if (session.mode == SessionMode.READ_WRITE) targetOwners.remove(session.targetId, sessionId)
        return previous
    }

    fun closeAll(player: UUID): List<PreviewSnapshot> {
        val previews = sessions.values.filter { it.owner == player }.mapNotNull { close(player, it.id) }
        connections.remove(player)
        return previews
    }

    /** Stable snapshots used by the transport to publish live editor presence. */
    fun presence(targetId: String): List<EditorPresence> = sessions.values
        .asSequence()
        .filter { it.targetId == targetId }
        .map {
            EditorPresence(
                playerId = it.owner.toString(),
                playerName = it.playerName,
                sessionId = it.id,
                targetId = it.targetId,
                readOnly = it.mode == SessionMode.READ_ONLY,
            )
        }
        .sortedBy(EditorPresence::playerName)
        .toList()

    fun sessionTarget(player: UUID, sessionId: String): String? =
        sessions[sessionId]?.takeIf { it.owner == player }?.targetId

    fun sessionTargets(player: UUID): List<String> = sessions.values
        .asSequence()
        .filter { it.owner == player }
        .map(Session::targetId)
        .distinct()
        .toList()

    fun readyPlayers(): List<UUID> = connections.asSequence()
        .filter { it.value.confirmed }
        .map { it.key }
        .toList()

    private fun expire() {
        val deadline = now() - sessionTtlMillis
        sessions.values.filter { it.touchedAt < deadline }.forEach { stale ->
            sessions.remove(stale.id)
            targetOwners.remove(stale.targetId, stale.id)
        }
    }

    private companion object {
        const val PREVIEW_MIN_INTERVAL_MILLIS = 40L
    }
}
