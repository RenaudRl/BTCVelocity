package com.borntocraft.typewriter.adminmode.server

import com.borntocraft.typewriter.adminmode.protocol.Capability
import com.borntocraft.typewriter.adminmode.protocol.ClientMessage
import com.borntocraft.typewriter.adminmode.protocol.DiagnosticsSnapshot
import com.borntocraft.typewriter.adminmode.protocol.ErrorCode
import com.borntocraft.typewriter.adminmode.protocol.Protocol
import com.borntocraft.typewriter.adminmode.protocol.ProtocolException
import com.borntocraft.typewriter.adminmode.protocol.ServerMessage
import com.borntocraft.typewriter.adminmode.protocol.SessionMode
import com.borntocraft.typewriter.adminmode.protocol.WireCodec
import org.bukkit.entity.Player
import org.bukkit.plugin.Plugin
import org.bukkit.plugin.messaging.PluginMessageListener
import java.util.UUID

/**
 * Authoritative entry point for every companion frame.
 *
 * Decoding happens on the network thread because it is pure computation over a byte array.
 * Anything that reads the world or mutates Typewriter is handed to [PlatformScheduler] first,
 * so the same code path is correct on Paper and on Folia.
 */
public class AdminModeChannel(
    private val plugin: Plugin,
    private val scheduler: PlatformScheduler,
    private val sessions: AdminSessions,
    private val adapters: TargetAdapters,
) : PluginMessageListener {

    override fun onPluginMessageReceived(channel: String, player: Player, message: ByteArray) {
        if (channel != Protocol.CHANNEL) return
        val request = try {
            WireCodec.decodeClient(message)
        } catch (malformed: ProtocolException) {
            // Never echo the decoder's detail back to the client: it describes our parser.
            return reply(player, ServerMessage.Failure(0, ErrorCode.MALFORMED, "Malformed frame"))
        }
        // A scheduling failure used to kill the frame on the network thread without a trace, and
        // the operator only saw a handshake that never completed. It is now reported as such.
        runCatching { scheduler.forPlayer(player) { dispatch(player, request) } }
            .onFailure { failure ->
                reply(
                    player,
                    ServerMessage.Failure(0, ErrorCode.INTERNAL, failure.message ?: "Scheduler unavailable"),
                )
            }
    }

    private fun dispatch(player: Player, request: ClientMessage) {
        when (request) {
            is ClientMessage.Hello -> handshake(player, request)
            is ClientMessage.NonceConfirm -> sessions.confirmNonce(player.uniqueId, request.nonce)
            is ClientMessage.SelectRequest -> select(player, request)
            is ClientMessage.Deselect -> Unit // Selection is client-side state; nothing is held here.
            is ClientMessage.SearchRequest -> search(player, request)
            is ClientMessage.DiagnosticsRequest -> diagnostics(player, request)
            is ClientMessage.OpenSession -> openSession(player, request)
            is ClientMessage.Preview -> preview(player, request)
            is ClientMessage.Commit -> commit(player, request)
            is ClientMessage.Undo -> undo(player, request)
            is ClientMessage.CloseSession -> {
                val targetId = sessions.sessionTarget(player.uniqueId, request.sessionId)
                sessions.close(player.uniqueId, request.sessionId)
                targetId?.let(::broadcastPresence)
            }
        }
    }

    // ------------------------------------------------------------------ handshake

    private fun handshake(player: Player, request: ClientMessage.Hello) {
        if (request.protocolVersion != Protocol.VERSION) {
            return reply(
                player,
                ServerMessage.Failure(
                    0,
                    ErrorCode.UNSUPPORTED_VERSION,
                    "Server speaks protocol ${Protocol.VERSION}, client speaks ${request.protocolVersion}",
                ),
            )
        }
        if (!Permissions.mayConnect(player)) {
            return reply(player, ServerMessage.Failure(0, ErrorCode.NO_PERMISSION, "Missing ${Permissions.CONNECT}"))
        }

        val previousTargets = sessions.sessionTargets(player.uniqueId)
        val connection = sessions.beginHandshake(player.uniqueId, request.capabilities)
        connection.granted = Permissions.grant(player, request.capabilities, supportedCapabilities())
        reply(
            player,
            ServerMessage.Welcome(
                negotiatedVersion = Protocol.VERSION,
                nonce = connection.nonce,
                connectionEpoch = connection.epoch,
                capabilities = connection.granted,
                folia = scheduler.isFolia,
            ),
        )
        previousTargets.forEach(::broadcastPresence)
    }

    /** Common phase-5 services are deliberately independent from domain integrations. */
    private fun supportedCapabilities(): Set<Capability> =
        adapters.supportedCapabilities() + setOf(
            Capability.INSPECT,
            Capability.UNDO,
            Capability.SEARCH,
            Capability.PRESETS,
            Capability.PRESENCE,
            Capability.DIAGNOSTICS,
            Capability.BUILDER_READ_ONLY,
        )

    // ------------------------------------------------------------------ selection

    private fun select(player: Player, request: ClientMessage.SelectRequest) {
        val connection = sessions.ready(player.uniqueId)
            ?: return deny(player, request.requestId, ErrorCode.UNKNOWN_SESSION, "Handshake not completed")
        if (Capability.INSPECT !in connection.granted) {
            return deny(player, request.requestId, ErrorCode.MISSING_CAPABILITY, "Inspection is not granted")
        }
        // The client reports a dimension key (`minecraft:overworld`), not a Bukkit world name:
        // those two namespaces do not coincide, and comparing them would reject every selection.
        if (player.world.key.asString() != request.world) {
            return deny(player, request.requestId, ErrorCode.UNKNOWN_TARGET, "Selection targets another world")
        }

        val selection = SelectionRequest(
            actor = player,
            world = request.world,
            eyeX = request.eyeX, eyeY = request.eyeY, eyeZ = request.eyeZ,
            dirX = request.dirX, dirY = request.dirY, dirZ = request.dirZ,
            maxDistance = request.maxDistance.coerceIn(0.0, MAX_SELECTION_DISTANCE),
            mode = request.mode,
        )
        val resolved = adapters.resolve(selection, connection.granted)
            ?: return deny(player, request.requestId, ErrorCode.UNKNOWN_TARGET, "Nothing editable under the cursor")

        val (adapter, targetId) = resolved
        val schema = adapter.describe(targetId, player)
            ?: return deny(player, request.requestId, ErrorCode.UNKNOWN_TARGET, "Target vanished before it was described")

        reply(player, ServerMessage.SelectResult(request.requestId, schema, connection.granted))
    }

    private fun search(player: Player, request: ClientMessage.SearchRequest) {
        val connection = sessions.ready(player.uniqueId)
            ?: return deny(player, request.requestId, ErrorCode.UNKNOWN_SESSION, "Handshake not completed")
        if (Capability.SEARCH !in connection.granted) {
            return deny(player, request.requestId, ErrorCode.MISSING_CAPABILITY, "Search is not granted")
        }
        val query = request.query.trim().take(MAX_SEARCH_QUERY)
        val kind = request.kind.trim().take(MAX_SEARCH_KIND)
        val limit = request.limit.coerceIn(1, MAX_SEARCH_RESULTS)
        val results = adapters.search(query, kind, player, connection.granted, limit)
        reply(player, ServerMessage.SearchResults(request.requestId, query, results))
    }

    private fun diagnostics(player: Player, request: ClientMessage.DiagnosticsRequest) {
        val connection = sessions.ready(player.uniqueId)
            ?: return deny(player, request.requestId, ErrorCode.UNKNOWN_SESSION, "Handshake not completed")
        if (Capability.DIAGNOSTICS !in connection.granted) {
            return deny(player, request.requestId, ErrorCode.MISSING_CAPABILITY, "Diagnostics are not granted")
        }
        val warnings = buildList {
            if (!scheduler.isFolia) add("Runtime Paper détecté : les capacités Folia ne sont pas actives")
            if (adapters.kinds().isEmpty()) add("Aucun adaptateur d'entry n'est installé")
            add("Le bridge Axiom est optionnel et n'est pas installé")
        }
        reply(
            player,
            ServerMessage.DiagnosticsResult(
                requestId = request.requestId,
                snapshot = DiagnosticsSnapshot(
                    protocolVersion = Protocol.VERSION,
                    serverVersion = plugin.server.version,
                    folia = scheduler.isFolia,
                    capabilities = connection.granted,
                    adapterKinds = adapters.kinds(),
                    warnings = warnings,
                ),
            ),
        )
    }

    // ------------------------------------------------------------------ sessions

    private fun openSession(player: Player, request: ClientMessage.OpenSession) {
        val connection = sessions.ready(player.uniqueId)
            ?: return deny(player, request.requestId, ErrorCode.UNKNOWN_SESSION, "Handshake not completed")
        if (Capability.INSPECT !in connection.granted) {
            return deny(player, request.requestId, ErrorCode.MISSING_CAPABILITY, "Inspection is not granted")
        }
        val adapter = adapters.forTarget(request.targetId)
            ?: return deny(player, request.requestId, ErrorCode.UNKNOWN_TARGET, "No adapter owns this target")
        if (!connection.granted.containsAll(adapter.capabilities)) {
            return deny(player, request.requestId, ErrorCode.MISSING_CAPABILITY, "Target integration is not granted")
        }
        val schema = adapter.describe(request.targetId, player)
            ?: return deny(player, request.requestId, ErrorCode.UNKNOWN_TARGET, "Unknown target")

        // An adapter may expose a read-only target while still being selectable with INSPECT.
        val mode = if (adapter.canWrite(request.targetId, player, connection.granted)) {
            SessionMode.READ_WRITE
        } else {
            SessionMode.READ_ONLY
        }

        when (val outcome = sessions.open(player.uniqueId, connection.epoch, request.targetId, schema.revision, mode, player.name)) {
            is Outcome.Denied -> deny(player, request.requestId, outcome.code, outcome.reason)
            is Outcome.Ok -> {
                reply(
                    player,
                    ServerMessage.SessionOpened(
                        requestId = request.requestId,
                        sessionId = outcome.value.id,
                        targetId = request.targetId,
                        revision = outcome.value.revision,
                        mode = mode,
                        schema = schema,
                    ),
                )
                broadcastPresence(request.targetId)
            }
        }
    }

    /** Shared preview is non-persistent, so an ungranted preview is dropped rather than refused. */
    private fun preview(player: Player, request: ClientMessage.Preview) {
        val connection = sessions.ready(player.uniqueId) ?: return
        if (Capability.SHARED_PREVIEW !in connection.granted) return
        // Preview remains intentionally coalesced client-side. Presence is broadcast on session
        // changes; persistent target updates are broadcast after a successful commit.
    }

    // ------------------------------------------------------------------ mutations

    private fun commit(player: Player, request: ClientMessage.Commit) {
        val requestId = request.envelope.requestId
        val adapter = adapters.forTarget(request.targetId)
            ?: return deny(player, requestId, ErrorCode.UNKNOWN_TARGET, "No adapter owns this target")

        when (val validation = sessions.validate(player.uniqueId, request.envelope, request.targetId)) {
            is Outcome.Denied -> deny(player, requestId, validation.code, validation.reason)
            is Outcome.Ok -> adapter.applyAsync(request.targetId, request.operation, player) { result ->
                scheduler.forPlayer(player.uniqueId) { livePlayer ->
                    result.fold(
                        onSuccess = {
                            val revision = sessions.recordCommit(validation.value)
                            reply(livePlayer, ServerMessage.CommitResult(requestId, request.targetId, revision))
                            broadcast(livePlayer, adapter, request.targetId)
                        },
                        onFailure = { failure ->
                            deny(livePlayer, requestId, ErrorCode.FIELD_NOT_EDITABLE, failure.message ?: "Mutation rejected")
                        },
                    )
                }
            }
        }
    }

    private fun undo(player: Player, request: ClientMessage.Undo) {
        val requestId = request.envelope.requestId
        val adapter = adapters.forTarget(request.targetId)
            ?: return deny(player, requestId, ErrorCode.UNKNOWN_TARGET, "No adapter owns this target")
        val connection = sessions.ready(player.uniqueId)
            ?: return deny(player, requestId, ErrorCode.UNKNOWN_SESSION, "Handshake not completed")
        if (Capability.UNDO !in connection.granted) {
            return deny(player, requestId, ErrorCode.MISSING_CAPABILITY, "Undo is not granted")
        }
        if (!player.hasPermission(Permissions.UNDO_SELF)) {
            return deny(player, requestId, ErrorCode.NO_PERMISSION, "Missing ${Permissions.UNDO_SELF}")
        }

        when (val validation = sessions.validate(player.uniqueId, request.envelope, request.targetId)) {
            is Outcome.Denied -> deny(player, requestId, validation.code, validation.reason)
            is Outcome.Ok -> adapter.undoAsync(request.targetId, player) { result ->
                scheduler.forPlayer(player.uniqueId) { livePlayer ->
                    result.fold(
                        onSuccess = {
                            when (val undone = sessions.recordUndo(validation.value)) {
                                is Outcome.Denied -> deny(livePlayer, requestId, undone.code, undone.reason)
                                is Outcome.Ok -> {
                                    reply(
                                        livePlayer,
                                        ServerMessage.CommitResult(requestId, request.targetId, validation.value.revision),
                                    )
                                    broadcast(livePlayer, adapter, request.targetId)
                                }
                            }
                        },
                        onFailure = { failure ->
                            deny(livePlayer, requestId, ErrorCode.INTERNAL, failure.message ?: "Undo rejected")
                        },
                    )
                }
            }
        }
    }

    /** Canonical patch, so a mod client and the web editor converge on the same state. */
    private fun broadcast(actor: Player, adapter: TargetAdapter, targetId: String) {
        sessions.readyPlayers().forEach { playerId ->
            val connection = sessions.ready(playerId)
            if (connection == null ||
                Capability.INSPECT !in connection.granted ||
                !connection.granted.containsAll(adapter.capabilities)
            ) return@forEach
            scheduler.forPlayer(playerId) { livePlayer ->
                adapter.describe(targetId, livePlayer)?.let { schema ->
                    reply(livePlayer, ServerMessage.TargetUpdated(schema))
                }
            }
        }
        broadcastPresence(targetId)
    }

    private fun broadcastPresence(targetId: String) {
        val adapter = adapters.forTarget(targetId) ?: return
        val snapshot = ServerMessage.PresenceSnapshot(targetId, sessions.presence(targetId))
        sessions.readyPlayers().forEach { playerId ->
            val connection = sessions.ready(playerId)
            if (connection == null ||
                Capability.INSPECT !in connection.granted ||
                !connection.granted.containsAll(adapter.capabilities)
            ) return@forEach
            scheduler.forPlayer(playerId) { reply(it, snapshot) }
        }
    }

    // ------------------------------------------------------------------ commands

    /**
     * Asks the client to open its editor surface on whatever target it already holds a session on.
     *
     * Meant for a `/tweditor`-style command: the server never opens a session on the player's
     * behalf here, it only nudges an already-selected target into the full surface. Returns false
     * when there is nothing to open, so the caller can report that instead of sending a dead frame.
     */
    public fun requestOpenSurface(player: Player): Boolean {
        val targetId = sessions.sessionTargets(player.uniqueId).firstOrNull() ?: return false
        reply(player, ServerMessage.OpenSurface(targetId))
        return true
    }

    // ------------------------------------------------------------------ transport

    /** Drops all player-owned state and informs the remaining editors about the departure. */
    public fun onPlayerQuit(playerId: UUID) {
        val affectedTargets = sessions.sessionTargets(playerId)
        sessions.closeAll(playerId)
        affectedTargets.forEach(::broadcastPresence)
    }

    private fun deny(player: Player, requestId: Long, code: ErrorCode, reason: String) =
        reply(player, ServerMessage.Failure(requestId, code, reason))

    private fun reply(player: Player, message: ServerMessage) {
        val frame = try {
            WireCodec.encode(message)
        } catch (oversized: ProtocolException) {
            WireCodec.encode(ServerMessage.Failure(0, ErrorCode.INTERNAL, "Response too large to send"))
        }
        player.sendPluginMessage(plugin, Protocol.CHANNEL, frame)
    }

    private companion object {
        /** Matches the furthest a player could plausibly be editing from. */
        const val MAX_SELECTION_DISTANCE = 128.0
        const val MAX_SEARCH_QUERY = 256
        const val MAX_SEARCH_KIND = 128
        const val MAX_SEARCH_RESULTS = 64
    }
}
