package com.borntocraft.typewriter.adminmode.server

import org.bukkit.entity.Player
import org.bukkit.plugin.Plugin
import java.util.UUID
import java.util.function.Consumer

/**
 * Keeps Folia symbols out of the static linkage graph. This matters because a Paper
 * server must be able to load the extension without resolving any Folia-only type.
 */
public class PlatformScheduler(private val plugin: Plugin) {
    val isFolia: Boolean = runCatching { Class.forName("io.papermc.paper.threadedregions.RegionizedServer") }.isSuccess

    fun forPlayer(player: Player, action: () -> Unit) {
        forPlayer(player.uniqueId) { action() }
    }

    fun forPlayer(playerId: UUID, action: (Player) -> Unit) {
        val player = plugin.server.getPlayer(playerId) ?: return
        // EntityScheduler exists on the supported Paper API and is also the only safe route on
        // Folia. Reflection keeps the shared artifact loadable on older public Typewriter hosts.
        val scheduler = player.javaClass.methods
            .firstOrNull { it.name == "getScheduler" && it.parameterCount == 0 }
            ?.invoke(player)
            ?: throw IllegalStateException("Paper EntityScheduler is unavailable")
        // EntityScheduler.run(Plugin, Consumer<ScheduledTask>, Runnable retired) — three
        // parameters, not four: `runDelayed` is the one that takes a delay. Matching on the
        // arity alone found nothing, so every incoming frame used to die right here.
        val run = scheduler.javaClass.methods.firstOrNull { it.name == "run" && it.parameterCount == 3 }
            ?: throw IllegalStateException("Paper/Folia EntityScheduler.run is unavailable")
        run.invoke(scheduler, plugin, Consumer<Any> { action(player) }, null)
    }
}
