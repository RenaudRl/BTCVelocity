package com.borntocraft.typewriter.adminmode.server

import com.borntocraft.typewriter.adminmode.protocol.Capability
import com.borntocraft.typewriter.adminmode.protocol.Operation
import com.borntocraft.typewriter.adminmode.protocol.SearchResult
import com.borntocraft.typewriter.adminmode.protocol.TargetSchema
import org.bukkit.entity.Player
import java.util.concurrent.CopyOnWriteArrayList

/** A selection intent. The ray is recomputed here; the client's own hit result is never trusted. */
public data class SelectionRequest(
    val actor: Player,
    val world: String,
    val eyeX: Double,
    val eyeY: Double,
    val eyeZ: Double,
    val dirX: Double,
    val dirY: Double,
    val dirZ: Double,
    val maxDistance: Double,
)

/**
 * Plug-in point for anything editable through the companion mod.
 *
 * Implementations own a family of Typewriter documents and are responsible for describing their
 * editable surface. Because the client renders purely from [describe], adding a new adapter makes
 * a new entry type editable without shipping a new mod build.
 */
public interface TargetAdapter {
    /** Stable discriminator, echoed in [TargetSchema.kind] — for example `bettermodel_instance`. */
    public val kind: String

    /** Capabilities this adapter needs; it stays dormant unless all of them are granted. */
    public val capabilities: Set<Capability>

    /** Capabilities advertised by the extension; field-level permissions can be narrower. */
    public val supportedCapabilities: Set<Capability>
        get() = capabilities

    /** Returns the stable business id of whatever the ray hit, or null when nothing matches. */
    public fun resolve(request: SelectionRequest): String?

    /** Full editable description, including locked fields and the reason they are locked. */
    public fun describe(targetId: String, viewer: Player): TargetSchema?

    /**
     * Searches the adapter's stable target directory. Implementations must return at most
     * [limit] results and must not expose targets the viewer cannot inspect.
     */
    public fun search(query: String, kind: String, viewer: Player, limit: Int): List<SearchResult> = emptyList()

    /**
     * Whether this concrete target can open a write session for this player.
     *
     * Adapters may be selectable with inspection alone (`capabilities = emptySet()`) while
     * deciding writability from field-level permissions or target state.
     */
    public fun canWrite(targetId: String, actor: Player, granted: Set<Capability>): Boolean =
        granted.containsAll(capabilities) && actor.hasPermission(Permissions.COMMIT)

    /** Applies a validated mutation through the Typewriter staging façade. */
    public fun apply(targetId: String, operation: Operation, actor: Player): Result<Unit>

    /**
     * Async variant for domain APIs whose official mutation is suspend-based. The default keeps
     * existing adapters synchronous; the callback must not retain Bukkit objects longer than the
     * adapter needs to snapshot its input.
     */
    public fun applyAsync(
        targetId: String,
        operation: Operation,
        actor: Player,
        completion: (Result<Unit>) -> Unit,
    ) {
        completion(apply(targetId, operation, actor))
    }

    /** Reverts the last mutation as a new forward write, never by rewinding history. */
    public fun undo(targetId: String, actor: Player): Result<Unit>

    public fun undoAsync(targetId: String, actor: Player, completion: (Result<Unit>) -> Unit) {
        completion(undo(targetId, actor))
    }
}

/**
 * Ordered registry of adapters. Registration order decides selection priority, so a specific
 * adapter can shadow a broader one.
 */
public class TargetAdapters {
    private val adapters = CopyOnWriteArrayList<TargetAdapter>()

    public fun register(adapter: TargetAdapter) {
        adapters += adapter
    }

    public fun unregister(adapter: TargetAdapter) {
        adapters -= adapter
    }

    internal fun supportedCapabilities(): Set<Capability> =
        adapters.flatMapTo(LinkedHashSet(), TargetAdapter::supportedCapabilities)

    /** Public so an extension can report what it actually bridges instead of guessing. */
    public fun kinds(): List<String> = adapters.map(TargetAdapter::kind).distinct()

    internal fun search(
        query: String,
        kind: String,
        viewer: Player,
        granted: Set<Capability>,
        limit: Int,
    ): List<SearchResult> =
        adapters.asSequence()
            .filter { kind.isBlank() || it.kind == kind }
            .filter { adapter ->
                // Search is inspection-only; adapters with integration requirements stay hidden
                // unless the current handshake actually granted those capabilities.
                Capability.INSPECT in granted &&
                    viewer.hasPermission(Permissions.INSPECT) &&
                    adapter.capabilities.all { it in granted && Permissions.allows(viewer, it) }
            }
            .flatMap { adapter -> adapter.search(query, kind, viewer, limit).asSequence() }
            .distinctBy(SearchResult::targetId)
            .take(limit)
            .toList()

    internal fun resolve(request: SelectionRequest, granted: Set<Capability>): Pair<TargetAdapter, String>? =
        adapters.asSequence()
            .filter { granted.containsAll(it.capabilities) }
            .mapNotNull { adapter -> adapter.resolve(request)?.let { adapter to it } }
            .firstOrNull()

    internal fun forTarget(targetId: String): TargetAdapter? =
        adapters.firstOrNull { targetId.startsWith("${it.kind}:") }
}
