package com.borntocraft.typewriter.adminmode.server

import com.borntocraft.typewriter.adminmode.protocol.Capability
import org.bukkit.entity.Player

/**
 * Permission nodes of the admin editor.
 *
 * A capability is never granted because the client asked for it: the server intersects what the
 * client offered, what this build can actually honour, and what the player is allowed to do.
 */
public object Permissions {
    const val CONNECT = "btceditor.connect"
    const val INSPECT = "btceditor.inspect"
    const val EDIT_INSTANCE = "btceditor.edit.instance"
    const val EDIT_TRANSFORM = "btceditor.edit.transform"
    const val EDIT_DEFINITION = "btceditor.edit.definition"
    const val EDIT_ROAD = "btceditor.edit.road"
    const val EDIT_PROTECTION = "btceditor.edit.protection"
    const val COMMIT = "btceditor.commit"
    const val UNDO_SELF = "btceditor.undo.self"
    const val UNDO_ANY = "btceditor.undo.any"
    const val ADMIN = "btceditor.admin"
    const val BUILDER_READ_ONLY = "btceditor.builder.readonly"

    private val required: Map<Capability, List<String>> = mapOf(
        Capability.INSPECT to listOf(INSPECT),
        Capability.TRANSFORM_INSTANCE to listOf(EDIT_TRANSFORM, COMMIT),
        Capability.EDIT_DEFINITION to listOf(EDIT_DEFINITION, COMMIT),
        Capability.EDIT_DATA to listOf(EDIT_INSTANCE, COMMIT),
        Capability.ROAD_NETWORK to listOf(EDIT_ROAD, COMMIT),
        Capability.PROTECTION to listOf(EDIT_PROTECTION, COMMIT),
        Capability.UNDO to listOf(UNDO_SELF),
        Capability.SHARED_PREVIEW to listOf(INSPECT),
        Capability.HUD_PROFILE to listOf(INSPECT),
        Capability.SEARCH to listOf(INSPECT),
        Capability.PRESETS to listOf(INSPECT),
        Capability.PRESENCE to listOf(INSPECT),
        Capability.DIAGNOSTICS to listOf(INSPECT),
        Capability.BUILDER_READ_ONLY to listOf(BUILDER_READ_ONLY),
    )

    fun mayConnect(player: Player): Boolean = player.hasPermission(CONNECT)

    fun allows(player: Player, capability: Capability): Boolean =
        required[capability]?.all(player::hasPermission) ?: false

    /** Intersection of what the client offered, what the server supports, and what is permitted. */
    fun grant(player: Player, offered: Set<Capability>, supported: Set<Capability>): Set<Capability> =
        offered.filterTo(LinkedHashSet()) { it in supported && allows(player, it) }
}
