package com.borntocraft.typewriter.adminmode.protocol

/**
 * Every mutating request carries the full anti-replay envelope: which session, which connection,
 * which position in that session's stream, and which revision the client believed it was editing.
 * The server rejects the frame unless all four agree.
 */
public data class MutationEnvelope(
    val requestId: Long,
    val sessionId: String,
    val connectionEpoch: Long,
    val sequence: Long,
    val baseRevision: Long,
)

/** A bounded result returned by the server-side target directory. */
public data class SearchResult(
    val targetId: String,
    val kind: String,
    val title: String,
    val revision: Long,
)

/** One editor currently holding a read or write session on a target. */
public data class EditorPresence(
    val playerId: String,
    val playerName: String,
    val sessionId: String,
    val targetId: String,
    val readOnly: Boolean,
)

/** Server health and capability information shown by the diagnostics panel. */
public data class DiagnosticsSnapshot(
    val protocolVersion: Int,
    val serverVersion: String,
    val folia: Boolean,
    val capabilities: Set<Capability>,
    val adapterKinds: List<String>,
    val warnings: List<String>,
)

/** A bounded, typed edit. The client never sends raw JSON or field paths it invented itself. */
public sealed interface Operation {
    /** Whole-position write, matching a Typewriter `Var<Position>` annotated `@WithRotation`. */
    public data class SetPosition(
        val x: Double,
        val y: Double,
        val z: Double,
        val yaw: Float,
        val pitch: Float,
    ) : Operation

    /** Single-field write against a key the server itself published in the [TargetSchema]. */
    public data class SetField(val key: String, val value: FieldValue) : Operation
}

/** Frames sent by the Fabric client to the Typewriter extension. */
public sealed interface ClientMessage {
    public data class Hello(
        val protocolVersion: Int,
        val modVersion: String,
        val capabilities: Set<Capability>,
    ) : ClientMessage

    /** Closes the handshake by echoing the server nonce. */
    public data class NonceConfirm(val nonce: Long) : ClientMessage

    /**
     * The client sends its intent, never its conclusion: the server recomputes the ray itself
     * and decides what was actually hit.
     */
    public data class SelectRequest(
        val requestId: Long,
        val world: String,
        val eyeX: Double,
        val eyeY: Double,
        val eyeZ: Double,
        val dirX: Double,
        val dirY: Double,
        val dirZ: Double,
        val maxDistance: Double,
        val additive: Boolean,
        /** Only adapters registered for this mode may resolve the ray. */
        val mode: EditorMode,
    ) : ClientMessage

    public data class Deselect(val requestId: Long) : ClientMessage

    /** Server-side search; the query is an intent and is bounded again by the extension. */
    public data class SearchRequest(
        val requestId: Long,
        val query: String,
        val kind: String = "",
        val limit: Int = 32,
    ) : ClientMessage

    public data class DiagnosticsRequest(val requestId: Long) : ClientMessage

    public data class OpenSession(val requestId: Long, val targetId: String) : ClientMessage

    /** Non-persistent, coalesced at 10–20 Hz, and only honoured with [Capability.SHARED_PREVIEW]. */
    public data class Preview(
        val sessionId: String,
        val connectionEpoch: Long,
        val sequence: Long,
        val targetId: String,
        val baseRevision: Long,
        val operation: Operation,
    ) : ClientMessage

    public data class ClearPreview(
        val sessionId: String,
        val connectionEpoch: Long,
        val sequence: Long,
        val targetId: String,
    ) : ClientMessage

    public data class Commit(
        val envelope: MutationEnvelope,
        val targetId: String,
        val operation: Operation,
    ) : ClientMessage

    public data class Undo(val envelope: MutationEnvelope, val targetId: String) : ClientMessage

    public data class CloseSession(val sessionId: String) : ClientMessage
}

/** Frames sent by the Typewriter extension to the Fabric client. */
public sealed interface ServerMessage {
    public data class Welcome(
        val negotiatedVersion: Int,
        val nonce: Long,
        val connectionEpoch: Long,
        val capabilities: Set<Capability>,
        val folia: Boolean,
    ) : ServerMessage

    public data class SelectResult(
        val requestId: Long,
        val schema: TargetSchema,
        val granted: Set<Capability>,
    ) : ServerMessage

    public data class SessionOpened(
        val requestId: Long,
        val sessionId: String,
        val targetId: String,
        val revision: Long,
        val mode: SessionMode,
        val schema: TargetSchema,
    ) : ServerMessage

    public data class CommitResult(
        val requestId: Long,
        val targetId: String,
        val newRevision: Long,
    ) : ServerMessage

    /**
     * Canonical patch broadcast after any accepted mutation, whatever its origin. This is what
     * keeps a mod client and the web editor from drifting apart.
     */
    public data class TargetUpdated(val schema: TargetSchema) : ServerMessage

    public data class PreviewUpdated(val preview: PreviewSnapshot) : ServerMessage

    public data class PreviewCleared(
        val sessionId: String,
        val targetId: String,
        val playerId: String,
    ) : ServerMessage

    public data class SearchResults(
        val requestId: Long,
        val query: String,
        val results: List<SearchResult>,
    ) : ServerMessage

    public data class PresenceSnapshot(
        val targetId: String,
        val editors: List<EditorPresence>,
    ) : ServerMessage

    public data class DiagnosticsResult(
        val requestId: Long,
        val snapshot: DiagnosticsSnapshot,
    ) : ServerMessage

    public data class Failure(
        val requestId: Long,
        val code: ErrorCode,
        val message: String,
    ) : ServerMessage

    /**
     * Pushed unsolicited, typically from a command: asks the client to show its editor surface for
     * a target it already holds a session on. The server never opens a session on the client's
     * behalf — if the target does not match what the client has selected, it says so instead of
     * opening blind.
     */
    public data class OpenSurface(val targetId: String) : ServerMessage
}

public data class PreviewSnapshot(
    val sessionId: String,
    val targetId: String,
    val playerId: String,
    val playerName: String,
    val operation: Operation,
)
