package com.borntocraft.typewriter.adminmode.protocol

/**
 * Server-described shape of an editable target.
 *
 * The client renders an inspector purely from this description, so a new Typewriter entry type
 * becomes editable without shipping a new mod build. Bounds and editability are decided by the
 * server and merely displayed by the client — they are re-validated on commit regardless.
 */
public data class TargetSchema(
    val targetId: String,
    val kind: String,
    val title: String,
    val revision: Long,
    val sections: List<SchemaSection>,
    /** Conservative local-space bounds for a transient movement preview. */
    val previewBounds: PreviewBounds? = null,
)

public data class PreviewBounds(
    val minX: Double,
    val maxX: Double,
    val minY: Double,
    val maxY: Double,
    val minZ: Double,
    val maxZ: Double,
)

public data class SchemaSection(
    val label: String,
    val fields: List<SchemaField>,
)

/**
 * One editable (or explicitly locked) value.
 *
 * [editable] false is always paired with a human [reason] — a greyed-out field with no
 * explanation is the single most common complaint about in-game editors.
 */
public data class SchemaField(
    val key: String,
    val label: String,
    val type: FieldType,
    val value: FieldValue,
    val unit: String = "",
    val min: Double = Double.NEGATIVE_INFINITY,
    val max: Double = Double.POSITIVE_INFINITY,
    val step: Double = 0.0,
    val editable: Boolean = false,
    val reason: String = "",
    val capability: Capability? = null,
)

public enum class FieldType {
    FLOAT,
    INT,
    BOOL,
    STRING,
    VEC3,
    ROTATION,
    POSITION,
    ENUM,
    REF,
}

/** Closed set of transportable values. The tag byte is assigned by the codec. */
public sealed interface FieldValue {
    public data class FloatValue(val value: Double) : FieldValue

    public data class IntValue(val value: Long) : FieldValue

    public data class BoolValue(val value: Boolean) : FieldValue

    public data class StringValue(val value: String) : FieldValue

    public data class Vec3Value(val x: Double, val y: Double, val z: Double) : FieldValue

    public data class RotationValue(val yaw: Float, val pitch: Float) : FieldValue

    /** Matches Typewriter's `Position`: a world plus coordinates plus rotation. */
    public data class PositionValue(
        val world: String,
        val x: Double,
        val y: Double,
        val z: Double,
        val yaw: Float,
        val pitch: Float,
    ) : FieldValue

    /** Enum selection carrying its allowed set so the client can render a picker. */
    public data class EnumValue(val selected: String, val options: List<String>) : FieldValue

    /** Reference to another Typewriter entry, shown as a navigable chip. */
    public data class RefValue(val entryId: String, val display: String) : FieldValue
}
