package com.borntocraft.typewriter.adminmode.protocol

/**
 * Single source of truth for the Typewriter Admin Mode wire contract.
 *
 * This module is deliberately free of Minecraft, Bukkit and Typewriter types so the Fabric
 * client and both Typewriter extensions can link the exact same bytes. Everything travels on
 * one plugin channel; the first byte of every frame is the message discriminator.
 */
public object Protocol {
    /**
     * Namespaced plugin channel shared by the mod and both extensions.
     *
     * Bukkit takes the joined form, while the client must build its identifier from the two
     * halves: a Minecraft `Identifier` parsed from a path alone lands in `minecraft:` and rejects
     * the colon.
     */
    public const val NAMESPACE: String = "typewriter_admin_mode"
    public const val PATH: String = "control"
    public const val CHANNEL: String = "$NAMESPACE:$PATH"

    /** Bumped on any breaking change to the frame layout. Negotiated during the handshake. */
    public const val VERSION: Int = 3

    /** Hard ceiling applied before any decoding, mirroring the plugin-message limit. */
    public const val MAX_FRAME_BYTES: Int = 32 * 1024

    /** Defensive bounds so a hostile frame cannot allocate unbounded collections. */
    public const val MAX_STRING_CHARS: Int = 4096
    public const val MAX_COLLECTION_SIZE: Int = 512

    /** Coordinates and rotations are rejected outside these bounds before reaching Typewriter. */
    public const val MAX_ABS_COORDINATE: Double = 3.0E7
}

/**
 * Optional behaviour negotiated at handshake time. A capability is only ever announced by the
 * side that can actually honour it, so a fork-specific feature degrades to absent rather than
 * to a runtime failure.
 */
public enum class Capability(public val id: String) {
    INSPECT("inspect"),
    TRANSFORM_INSTANCE("transform.instance"),
    EDIT_DEFINITION("edit.definition"),
    EDIT_DATA("edit.data"),
    ROAD_NETWORK("road.network"),
    PROTECTION("protection"),
    UNDO("undo"),
    SHARED_PREVIEW("preview.shared"),
    HUD_PROFILE("hud.profile"),
    SEARCH("search"),
    PRESETS("presets"),
    PRESENCE("presence"),
    DIAGNOSTICS("diagnostics"),
    BUILDER_READ_ONLY("builder.readonly"),
    AXIOM_BRIDGE("axiom.bridge"),
    ;

    public companion object {
        private val byId: Map<String, Capability> = entries.associateBy(Capability::id)

        /** Unknown ids are dropped: an older peer must not choke on a newer capability. */
        public fun parse(ids: Collection<String>): Set<Capability> =
            ids.mapNotNullTo(LinkedHashSet(), byId::get)
    }
}

/** Stable, machine-readable rejection reasons. The human message is advisory only. */
public enum class ErrorCode(public val id: String) {
    MALFORMED("malformed"),
    UNSUPPORTED_VERSION("unsupported_version"),
    NO_PERMISSION("no_permission"),
    MISSING_CAPABILITY("missing_capability"),
    UNKNOWN_TARGET("unknown_target"),
    UNKNOWN_SESSION("unknown_session"),
    STALE_EPOCH("stale_epoch"),
    OUT_OF_SEQUENCE("out_of_sequence"),
    REVISION_CONFLICT("revision_conflict"),
    FIELD_NOT_EDITABLE("field_not_editable"),
    OUT_OF_BOUNDS("out_of_bounds"),
    RATE_LIMITED("rate_limited"),
    INTERNAL("internal"),
    ;

    public companion object {
        private val byId: Map<String, ErrorCode> = entries.associateBy(ErrorCode::id)

        public fun parse(id: String): ErrorCode = byId[id] ?: INTERNAL
    }
}

/** Whether a session may mutate, decided by the server from permissions and capabilities. */
public enum class SessionMode { READ_ONLY, READ_WRITE }

/**
 * The single state that decides what a selection ray can hit.
 *
 * There used to be a "profile" that only rearranged panels; a mode is the real filter. Switching
 * mode always deselects, so a target from one domain can never stay open while another is armed.
 */
public enum class EditorMode { NPC, ROAD, PROTECTION }

/** Raised by the codec for every malformed or out-of-bounds frame. Never leaks to the peer. */
public class ProtocolException(message: String) : RuntimeException(message)
