package com.borntocraft.typewriter.adminmode.protocol

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException

/**
 * Binary framing for [ClientMessage] and [ServerMessage].
 *
 * Decoding is hostile-input first: every length is bounded before it is used to allocate, every
 * floating point number must be finite and within world bounds, and a truncated frame fails as a
 * [ProtocolException] rather than as an arbitrary runtime exception.
 */
public object WireCodec {
    private const val HELLO = 0x01
    private const val NONCE_CONFIRM = 0x02
    private const val SELECT_REQUEST = 0x10
    private const val DESELECT = 0x11
    private const val SEARCH_REQUEST = 0x12
    private const val DIAGNOSTICS_REQUEST = 0x13
    private const val OPEN_SESSION = 0x20
    private const val PREVIEW = 0x21
    private const val COMMIT = 0x22
    private const val UNDO = 0x23
    private const val CLOSE_SESSION = 0x24

    private const val WELCOME = 0x81
    private const val SELECT_RESULT = 0x82
    private const val SESSION_OPENED = 0x83
    private const val COMMIT_RESULT = 0x84
    private const val TARGET_UPDATED = 0x85
    private const val SEARCH_RESULTS = 0x86
    private const val PRESENCE_SNAPSHOT = 0x87
    private const val DIAGNOSTICS_RESULT = 0x88
    private const val FAILURE = 0xFF

    private const val OP_SET_POSITION = 0x01
    private const val OP_SET_FIELD = 0x02

    private const val VAL_FLOAT = 0x01
    private const val VAL_INT = 0x02
    private const val VAL_BOOL = 0x03
    private const val VAL_STRING = 0x04
    private const val VAL_VEC3 = 0x05
    private const val VAL_ROTATION = 0x06
    private const val VAL_POSITION = 0x07
    private const val VAL_ENUM = 0x08
    private const val VAL_REF = 0x09

    // ---------------------------------------------------------------- encoding

    public fun encode(message: ClientMessage): ByteArray = frame { out ->
        when (message) {
            is ClientMessage.Hello -> {
                out.writeByte(HELLO)
                out.writeInt(message.protocolVersion)
                out.writeText(message.modVersion)
                out.writeCapabilities(message.capabilities)
            }

            is ClientMessage.NonceConfirm -> {
                out.writeByte(NONCE_CONFIRM)
                out.writeLong(message.nonce)
            }

            is ClientMessage.SelectRequest -> {
                out.writeByte(SELECT_REQUEST)
                out.writeLong(message.requestId)
                out.writeText(message.world)
                out.writeDouble(message.eyeX); out.writeDouble(message.eyeY); out.writeDouble(message.eyeZ)
                out.writeDouble(message.dirX); out.writeDouble(message.dirY); out.writeDouble(message.dirZ)
                out.writeDouble(message.maxDistance)
                out.writeBoolean(message.additive)
            }

            is ClientMessage.Deselect -> {
                out.writeByte(DESELECT)
                out.writeLong(message.requestId)
            }

            is ClientMessage.SearchRequest -> {
                out.writeByte(SEARCH_REQUEST)
                out.writeLong(message.requestId)
                out.writeText(message.query)
                out.writeText(message.kind)
                out.writeSize(message.limit)
            }

            is ClientMessage.DiagnosticsRequest -> {
                out.writeByte(DIAGNOSTICS_REQUEST)
                out.writeLong(message.requestId)
            }

            is ClientMessage.OpenSession -> {
                out.writeByte(OPEN_SESSION)
                out.writeLong(message.requestId)
                out.writeText(message.targetId)
            }

            is ClientMessage.Preview -> {
                out.writeByte(PREVIEW)
                out.writeText(message.sessionId)
                out.writeLong(message.connectionEpoch)
                out.writeLong(message.sequence)
                out.writeText(message.targetId)
                out.writeOperation(message.operation)
            }

            is ClientMessage.Commit -> {
                out.writeByte(COMMIT)
                out.writeEnvelope(message.envelope)
                out.writeText(message.targetId)
                out.writeOperation(message.operation)
            }

            is ClientMessage.Undo -> {
                out.writeByte(UNDO)
                out.writeEnvelope(message.envelope)
                out.writeText(message.targetId)
            }

            is ClientMessage.CloseSession -> {
                out.writeByte(CLOSE_SESSION)
                out.writeText(message.sessionId)
            }
        }
    }

    public fun encode(message: ServerMessage): ByteArray = frame { out ->
        when (message) {
            is ServerMessage.Welcome -> {
                out.writeByte(WELCOME)
                out.writeInt(message.negotiatedVersion)
                out.writeLong(message.nonce)
                out.writeLong(message.connectionEpoch)
                out.writeCapabilities(message.capabilities)
                out.writeBoolean(message.folia)
            }

            is ServerMessage.SelectResult -> {
                out.writeByte(SELECT_RESULT)
                out.writeLong(message.requestId)
                out.writeSchema(message.schema)
                out.writeCapabilities(message.granted)
            }

            is ServerMessage.SessionOpened -> {
                out.writeByte(SESSION_OPENED)
                out.writeLong(message.requestId)
                out.writeText(message.sessionId)
                out.writeText(message.targetId)
                out.writeLong(message.revision)
                out.writeByte(message.mode.ordinal)
                out.writeSchema(message.schema)
            }

            is ServerMessage.CommitResult -> {
                out.writeByte(COMMIT_RESULT)
                out.writeLong(message.requestId)
                out.writeText(message.targetId)
                out.writeLong(message.newRevision)
            }

            is ServerMessage.TargetUpdated -> {
                out.writeByte(TARGET_UPDATED)
                out.writeSchema(message.schema)
            }

            is ServerMessage.SearchResults -> {
                out.writeByte(SEARCH_RESULTS)
                out.writeLong(message.requestId)
                out.writeText(message.query)
                out.writeSize(message.results.size)
                message.results.forEach { result ->
                    out.writeText(result.targetId)
                    out.writeText(result.kind)
                    out.writeText(result.title)
                    out.writeLong(result.revision)
                }
            }

            is ServerMessage.PresenceSnapshot -> {
                out.writeByte(PRESENCE_SNAPSHOT)
                out.writeText(message.targetId)
                out.writeSize(message.editors.size)
                message.editors.forEach { editor ->
                    out.writeText(editor.playerId)
                    out.writeText(editor.playerName)
                    out.writeText(editor.sessionId)
                    out.writeText(editor.targetId)
                    out.writeBoolean(editor.readOnly)
                }
            }

            is ServerMessage.DiagnosticsResult -> {
                out.writeByte(DIAGNOSTICS_RESULT)
                out.writeLong(message.requestId)
                out.writeDiagnostics(message.snapshot)
            }

            is ServerMessage.Failure -> {
                out.writeByte(FAILURE)
                out.writeLong(message.requestId)
                out.writeText(message.code.id)
                out.writeText(message.message)
            }
        }
    }

    // ---------------------------------------------------------------- decoding

    public fun decodeClient(bytes: ByteArray): ClientMessage = read(bytes) { input ->
        when (val tag = input.readUnsignedByte()) {
            HELLO -> ClientMessage.Hello(input.readInt(), input.readText(), input.readCapabilities())
            NONCE_CONFIRM -> ClientMessage.NonceConfirm(input.readLong())
            SELECT_REQUEST -> ClientMessage.SelectRequest(
                requestId = input.readLong(),
                world = input.readText(),
                eyeX = input.readCoordinate(), eyeY = input.readCoordinate(), eyeZ = input.readCoordinate(),
                dirX = input.readFinite(), dirY = input.readFinite(), dirZ = input.readFinite(),
                maxDistance = input.readFinite(),
                additive = input.readBoolean(),
            )

            DESELECT -> ClientMessage.Deselect(input.readLong())
            SEARCH_REQUEST -> ClientMessage.SearchRequest(
                requestId = input.readLong(),
                query = input.readText(),
                kind = input.readText(),
                limit = input.readSize(),
            )

            DIAGNOSTICS_REQUEST -> ClientMessage.DiagnosticsRequest(input.readLong())
            OPEN_SESSION -> ClientMessage.OpenSession(input.readLong(), input.readText())
            PREVIEW -> ClientMessage.Preview(
                sessionId = input.readText(),
                connectionEpoch = input.readLong(),
                sequence = input.readLong(),
                targetId = input.readText(),
                operation = input.readOperation(),
            )

            COMMIT -> ClientMessage.Commit(input.readEnvelope(), input.readText(), input.readOperation())
            UNDO -> ClientMessage.Undo(input.readEnvelope(), input.readText())
            CLOSE_SESSION -> ClientMessage.CloseSession(input.readText())
            else -> throw ProtocolException("Unknown client message tag 0x${tag.toString(16)}")
        }
    }

    public fun decodeServer(bytes: ByteArray): ServerMessage = read(bytes) { input ->
        when (val tag = input.readUnsignedByte()) {
            WELCOME -> ServerMessage.Welcome(
                negotiatedVersion = input.readInt(),
                nonce = input.readLong(),
                connectionEpoch = input.readLong(),
                capabilities = input.readCapabilities(),
                folia = input.readBoolean(),
            )

            SELECT_RESULT -> ServerMessage.SelectResult(input.readLong(), input.readSchema(), input.readCapabilities())
            SESSION_OPENED -> ServerMessage.SessionOpened(
                requestId = input.readLong(),
                sessionId = input.readText(),
                targetId = input.readText(),
                revision = input.readLong(),
                mode = input.readEnum(SessionMode.entries),
                schema = input.readSchema(),
            )

            COMMIT_RESULT -> ServerMessage.CommitResult(input.readLong(), input.readText(), input.readLong())
            TARGET_UPDATED -> ServerMessage.TargetUpdated(input.readSchema())
            SEARCH_RESULTS -> {
                val requestId = input.readLong()
                val query = input.readText()
                val size = input.readSize()
                val results = ArrayList<SearchResult>(size)
                repeat(size) {
                    results += SearchResult(input.readText(), input.readText(), input.readText(), input.readLong())
                }
                ServerMessage.SearchResults(requestId, query, results)
            }

            PRESENCE_SNAPSHOT -> {
                val targetId = input.readText()
                val size = input.readSize()
                val editors = ArrayList<EditorPresence>(size)
                repeat(size) {
                    editors += EditorPresence(
                        playerId = input.readText(),
                        playerName = input.readText(),
                        sessionId = input.readText(),
                        targetId = input.readText(),
                        readOnly = input.readBoolean(),
                    )
                }
                ServerMessage.PresenceSnapshot(targetId, editors)
            }

            DIAGNOSTICS_RESULT -> ServerMessage.DiagnosticsResult(input.readLong(), input.readDiagnostics())
            FAILURE -> ServerMessage.Failure(input.readLong(), ErrorCode.parse(input.readText()), input.readText())
            else -> throw ProtocolException("Unknown server message tag 0x${tag.toString(16)}")
        }
    }

    // ---------------------------------------------------------------- framing

    private inline fun frame(body: (DataOutputStream) -> Unit): ByteArray {
        val buffer = ByteArrayOutputStream()
        DataOutputStream(buffer).use(body)
        val bytes = buffer.toByteArray()
        if (bytes.size > Protocol.MAX_FRAME_BYTES) {
            throw ProtocolException("Frame of ${bytes.size} bytes exceeds ${Protocol.MAX_FRAME_BYTES}")
        }
        return bytes
    }

    private inline fun <T> read(bytes: ByteArray, body: (DataInputStream) -> T): T {
        if (bytes.isEmpty()) throw ProtocolException("Empty frame")
        if (bytes.size > Protocol.MAX_FRAME_BYTES) {
            throw ProtocolException("Frame of ${bytes.size} bytes exceeds ${Protocol.MAX_FRAME_BYTES}")
        }
        return try {
            DataInputStream(ByteArrayInputStream(bytes)).use { input ->
                val result = body(input)
                if (input.available() != 0) {
                    throw ProtocolException("Trailing bytes after frame")
                }
                result
            }
        } catch (expected: ProtocolException) {
            throw expected
        } catch (truncated: EOFException) {
            throw ProtocolException("Truncated frame: ${truncated.message ?: "unexpected end of input"}")
        }
    }

    // ---------------------------------------------------------------- primitives

    private fun DataOutputStream.writeText(value: String) {
        if (value.length > Protocol.MAX_STRING_CHARS) {
            throw ProtocolException("String of ${value.length} chars exceeds ${Protocol.MAX_STRING_CHARS}")
        }
        writeUTF(value)
    }

    private fun DataInputStream.readText(): String {
        val value = readUTF()
        if (value.length > Protocol.MAX_STRING_CHARS) {
            throw ProtocolException("String of ${value.length} chars exceeds ${Protocol.MAX_STRING_CHARS}")
        }
        return value
    }

    private fun DataOutputStream.writeSize(size: Int) {
        if (size < 0 || size > Protocol.MAX_COLLECTION_SIZE) {
            throw ProtocolException("Collection of $size exceeds ${Protocol.MAX_COLLECTION_SIZE}")
        }
        writeInt(size)
    }

    private fun DataInputStream.readSize(): Int {
        val size = readInt()
        if (size < 0 || size > Protocol.MAX_COLLECTION_SIZE) {
            throw ProtocolException("Collection size $size out of bounds")
        }
        return size
    }

    private fun DataInputStream.readFinite(): Double {
        val value = readDouble()
        if (!value.isFinite()) throw ProtocolException("Non-finite double")
        return value
    }

    private fun DataInputStream.readBound(): Double {
        // ±Infinity is the explicit "unbounded" sentinel used by schema limits.
        val value = readDouble()
        if (value.isNaN()) throw ProtocolException("NaN schema bound")
        return value
    }

    private fun DataInputStream.readCoordinate(): Double {
        val value = readFinite()
        if (kotlin.math.abs(value) > Protocol.MAX_ABS_COORDINATE) {
            throw ProtocolException("Coordinate $value out of world bounds")
        }
        return value
    }

    private fun DataInputStream.readFiniteFloat(): Float {
        val value = readFloat()
        if (!value.isFinite()) throw ProtocolException("Non-finite float")
        return value
    }

    private fun <E : Enum<E>> DataInputStream.readEnum(values: List<E>): E {
        val ordinal = readUnsignedByte()
        return values.getOrNull(ordinal) ?: throw ProtocolException("Unknown enum ordinal $ordinal")
    }

    private fun DataOutputStream.writeCapabilities(capabilities: Set<Capability>) {
        writeSize(capabilities.size)
        capabilities.forEach { writeText(it.id) }
    }

    private fun DataInputStream.readCapabilities(): Set<Capability> {
        val size = readSize()
        val ids = ArrayList<String>(size)
        repeat(size) { ids += readText() }
        return Capability.parse(ids)
    }

    private fun DataOutputStream.writeEnvelope(envelope: MutationEnvelope) {
        writeLong(envelope.requestId)
        writeText(envelope.sessionId)
        writeLong(envelope.connectionEpoch)
        writeLong(envelope.sequence)
        writeLong(envelope.baseRevision)
    }

    private fun DataInputStream.readEnvelope(): MutationEnvelope =
        MutationEnvelope(readLong(), readText(), readLong(), readLong(), readLong())

    private fun DataOutputStream.writeDiagnostics(snapshot: DiagnosticsSnapshot) {
        writeInt(snapshot.protocolVersion)
        writeText(snapshot.serverVersion)
        writeBoolean(snapshot.folia)
        writeCapabilities(snapshot.capabilities)
        writeSize(snapshot.adapterKinds.size)
        snapshot.adapterKinds.forEach { writeText(it) }
        writeSize(snapshot.warnings.size)
        snapshot.warnings.forEach { writeText(it) }
    }

    private fun DataInputStream.readDiagnostics(): DiagnosticsSnapshot {
        val protocolVersion = readInt()
        val serverVersion = readText()
        val folia = readBoolean()
        val capabilities = readCapabilities()
        val adapterCount = readSize()
        val adapterKinds = ArrayList<String>(adapterCount)
        repeat(adapterCount) { adapterKinds += readText() }
        val warningCount = readSize()
        val warnings = ArrayList<String>(warningCount)
        repeat(warningCount) { warnings += readText() }
        return DiagnosticsSnapshot(protocolVersion, serverVersion, folia, capabilities, adapterKinds, warnings)
    }

    // ---------------------------------------------------------------- operations

    private fun DataOutputStream.writeOperation(operation: Operation) {
        when (operation) {
            is Operation.SetPosition -> {
                requireFiniteCoordinate(operation.x, "x")
                requireFiniteCoordinate(operation.y, "y")
                requireFiniteCoordinate(operation.z, "z")
                requireFinite(operation.yaw.toDouble(), "yaw")
                requireFinite(operation.pitch.toDouble(), "pitch")
                writeByte(OP_SET_POSITION)
                writeDouble(operation.x); writeDouble(operation.y); writeDouble(operation.z)
                writeFloat(operation.yaw); writeFloat(operation.pitch)
            }

            is Operation.SetField -> {
                writeByte(OP_SET_FIELD)
                writeText(operation.key)
                writeValue(operation.value)
            }
        }
    }

    private fun DataInputStream.readOperation(): Operation = when (val tag = readUnsignedByte()) {
        OP_SET_POSITION -> Operation.SetPosition(
            readCoordinate(), readCoordinate(), readCoordinate(), readFiniteFloat(), readFiniteFloat(),
        )

        OP_SET_FIELD -> Operation.SetField(readText(), readValue())
        else -> throw ProtocolException("Unknown operation tag 0x${tag.toString(16)}")
    }

    // ---------------------------------------------------------------- values

    private fun DataOutputStream.writeValue(value: FieldValue) {
        when (value) {
            is FieldValue.FloatValue -> {
                requireFinite(value.value, "float value")
                writeByte(VAL_FLOAT); writeDouble(value.value)
            }
            is FieldValue.IntValue -> { writeByte(VAL_INT); writeLong(value.value) }
            is FieldValue.BoolValue -> { writeByte(VAL_BOOL); writeBoolean(value.value) }
            is FieldValue.StringValue -> { writeByte(VAL_STRING); writeText(value.value) }
            is FieldValue.Vec3Value -> {
                requireFinite(value.x, "vec3.x")
                requireFinite(value.y, "vec3.y")
                requireFinite(value.z, "vec3.z")
                writeByte(VAL_VEC3); writeDouble(value.x); writeDouble(value.y); writeDouble(value.z)
            }

            is FieldValue.RotationValue -> {
                requireFinite(value.yaw.toDouble(), "rotation.yaw")
                requireFinite(value.pitch.toDouble(), "rotation.pitch")
                writeByte(VAL_ROTATION); writeFloat(value.yaw); writeFloat(value.pitch)
            }

            is FieldValue.PositionValue -> {
                requireFiniteCoordinate(value.x, "position.x")
                requireFiniteCoordinate(value.y, "position.y")
                requireFiniteCoordinate(value.z, "position.z")
                requireFinite(value.yaw.toDouble(), "position.yaw")
                requireFinite(value.pitch.toDouble(), "position.pitch")
                writeByte(VAL_POSITION)
                writeText(value.world)
                writeDouble(value.x); writeDouble(value.y); writeDouble(value.z)
                writeFloat(value.yaw); writeFloat(value.pitch)
            }

            is FieldValue.EnumValue -> {
                writeByte(VAL_ENUM)
                writeText(value.selected)
                writeSize(value.options.size)
                value.options.forEach { writeText(it) }
            }

            is FieldValue.RefValue -> {
                writeByte(VAL_REF); writeText(value.entryId); writeText(value.display)
            }
        }
    }

    private fun DataInputStream.readValue(): FieldValue = when (val tag = readUnsignedByte()) {
        VAL_FLOAT -> FieldValue.FloatValue(readFinite())
        VAL_INT -> FieldValue.IntValue(readLong())
        VAL_BOOL -> FieldValue.BoolValue(readBoolean())
        VAL_STRING -> FieldValue.StringValue(readText())
        VAL_VEC3 -> FieldValue.Vec3Value(readFinite(), readFinite(), readFinite())
        VAL_ROTATION -> FieldValue.RotationValue(readFiniteFloat(), readFiniteFloat())
        VAL_POSITION -> FieldValue.PositionValue(
            readText(), readCoordinate(), readCoordinate(), readCoordinate(), readFiniteFloat(), readFiniteFloat(),
        )

        VAL_ENUM -> {
            val selected = readText()
            val size = readSize()
            val options = ArrayList<String>(size)
            repeat(size) { options += readText() }
            FieldValue.EnumValue(selected, options)
        }

        VAL_REF -> FieldValue.RefValue(readText(), readText())
        else -> throw ProtocolException("Unknown value tag 0x${tag.toString(16)}")
    }

    // ---------------------------------------------------------------- schema

    private fun DataOutputStream.writeSchema(schema: TargetSchema) {
        writeText(schema.targetId)
        writeText(schema.kind)
        writeText(schema.title)
        writeLong(schema.revision)
        writeSize(schema.sections.size)
        schema.sections.forEach { section ->
            writeText(section.label)
            writeSize(section.fields.size)
            section.fields.forEach { field ->
                writeText(field.key)
                writeText(field.label)
                writeByte(field.type.ordinal)
                writeValue(field.value)
                writeText(field.unit)
                writeDouble(field.min); writeDouble(field.max); writeDouble(field.step)
                writeBoolean(field.editable)
                writeText(field.reason)
                writeText(field.capability?.id ?: "")
            }
        }
    }

    private fun DataInputStream.readSchema(): TargetSchema {
        val targetId = readText()
        val kind = readText()
        val title = readText()
        val revision = readLong()
        val sectionCount = readSize()
        val sections = ArrayList<SchemaSection>(sectionCount)
        repeat(sectionCount) {
            val label = readText()
            val fieldCount = readSize()
            val fields = ArrayList<SchemaField>(fieldCount)
            repeat(fieldCount) {
                val key = readText()
                val label = readText()
                val type = readEnum(FieldType.entries)
                val value = readValue()
                val unit = readText()
                val min = readBound()
                val max = readBound()
                val step = readFinite()
                fields += SchemaField(
                    key = key,
                    label = label,
                    type = type,
                    value = value,
                    unit = unit,
                    min = min,
                    max = max,
                    step = step,
                    editable = readBoolean(),
                    reason = readText(),
                    capability = readText().takeIf(String::isNotEmpty)
                        ?.let { id -> Capability.parse(listOf(id)).firstOrNull() },
                )
            }
            sections += SchemaSection(label, fields)
        }
        return TargetSchema(targetId, kind, title, revision, sections)
    }

    private fun requireFinite(value: Double, label: String) {
        if (!value.isFinite()) throw ProtocolException("Non-finite $label")
    }

    private fun requireFiniteCoordinate(value: Double, label: String) {
        requireFinite(value, label)
        if (kotlin.math.abs(value) > Protocol.MAX_ABS_COORDINATE) {
            throw ProtocolException("Coordinate $value out of world bounds")
        }
    }
}
