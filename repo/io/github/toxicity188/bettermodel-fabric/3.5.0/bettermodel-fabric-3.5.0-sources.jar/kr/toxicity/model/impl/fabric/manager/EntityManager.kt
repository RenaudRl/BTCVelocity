/*
 * This source file is part of BetterModel.
 * Copyright (c) 2026 toxicity188
 * Licensed under the MIT License.
 * See LICENSE.md file for full license text.
 */

package kr.toxicity.model.impl.fabric.manager

import kr.toxicity.model.api.BetterModel
import kr.toxicity.model.api.mod.entity.BaseModEntity
import kr.toxicity.model.api.nms.HitBox
import kr.toxicity.model.api.pack.PackZipper
import kr.toxicity.model.api.tracker.EntityTracker
import kr.toxicity.model.api.tracker.EntityTrackerRegistry
import kr.toxicity.model.api.tracker.Tracker
import kr.toxicity.model.api.tracker.TrackerExtraAnimation
import kr.toxicity.model.impl.fabric.events.ServerEntityDismountCallback
import kr.toxicity.model.impl.fabric.events.ServerLivingEntityJumpCallback
import kr.toxicity.model.impl.fabric.events.ServerMobEffectLoadCallback
import kr.toxicity.model.impl.fabric.events.ServerMobEffectUnloadCallback
import kr.toxicity.model.impl.fabric.wrap
import kr.toxicity.model.manager.GlobalManager
import kr.toxicity.model.manager.ReloadPipeline
import kr.toxicity.model.util.PLATFORM
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityLevelChangeEvents
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents
import net.fabricmc.fabric.api.event.player.UseEntityCallback
import net.minecraft.server.level.ServerPlayer
import net.minecraft.world.InteractionHand
import net.minecraft.world.InteractionResult
import net.minecraft.world.effect.MobEffects
import net.minecraft.world.entity.Entity

object EntityManager : GlobalManager {
    override fun reload(pipeline: ReloadPipeline, zipper: PackZipper) {
        EntityTrackerRegistry.registries { registry ->
            registry.reload()
        }
    }

    override fun end() {
        EntityTrackerRegistry.registries { registry ->
            registry.save()
            registry.close(Tracker.CloseReason.PLUGIN_DISABLE)
        }
    }

    /*
        EntityAddToWorldEvent ✅
        EntityRemoveFromWorldEvent ✅
        EntityJumpEvent ✅
        EntityDamageEvent ✅
        EntityDamageByEntityEvent ✅
        EntityDeathEvent ✅
        EntityDismountEvent ✅
        EntityPotionEffectEvent ✅
        EntityRemoveEvent ✅
        EntitySpawnEvent ✅
        PlayerChangedWorldEvent ✅
        PlayerDeathEvent ✅
        PlayerInteractAtEntityEvent ✅
        PlayerInteractEntityEvent ✅
        PlayerQuitEvent ✅
        EntitiesUnloadEvent ❌ probably because ENTITY_UNLOAD contains this
     */
    override fun start() {
        registerStateEvents()
        registerLifecycleEvents()
        registerCombatEvents()
        registerInteractionEvents()
    }

    private fun registerStateEvents() {
        // same as EntityPotionEffectEvent (added)
        ServerMobEffectLoadCallback.EVENT.register { entity, instance ->
            if (instance.effect == MobEffects.GLOWING ||
                instance.effect == MobEffects.INVISIBILITY
            ) {
                entity.eachTracker { tracker ->
                    tracker.updateBaseEntity()
                }
            }
        }

        // same as EntityPotionEffectEvent (removed)
        ServerMobEffectUnloadCallback.EVENT.register { entity, instance ->
            if (instance.effect == MobEffects.GLOWING ||
                instance.effect == MobEffects.INVISIBILITY
            ) {
                entity.eachTracker { tracker ->
                    tracker.updateBaseEntity()
                }
            }
        }

        // same as EntityDismountEvent
        ServerEntityDismountCallback.EVENT.register { _, vehicle ->
            vehicle !is HitBox ||
                !(vehicle.mountController().canFly() || !vehicle.mountController().canDismountBySelf()) ||
                vehicle.forceDismount()
        }

        // same as EntityJumpEvent
        ServerLivingEntityJumpCallback.EVENT.register { entity ->
            entity.eachTracker { tracker ->
                tracker.animate(TrackerExtraAnimation.JUMP)
            }
        }
    }

    private fun registerLifecycleEvents() {
        ServerEntityLevelChangeEvents.AFTER_ENTITY_CHANGE_LEVEL.register { oldEntity, newEntity, _, _ ->
            BetterModel.registryOrNull(oldEntity.uuid)?.let { registry ->
                (registry.entity() as BaseModEntity).entity(newEntity)
            }
        }

        // same as EntityAddToWorldEvent, EntitySpawnEvent
        ServerEntityEvents.ENTITY_LOAD.register { entity, _ ->
            BetterModel.registryOrNull(entity.uuid)?.refresh()
        }

        // same as EntityRemoveFromWorldEvent, EntityRemoveEvent
        ServerEntityEvents.ENTITY_UNLOAD.register { entity, _ ->
            BetterModel.registryOrNull(entity.uuid)?.despawn()
        }

        // same as PlayerChangedWorldEvent
        ServerEntityLevelChangeEvents.AFTER_PLAYER_CHANGE_LEVEL.register { player, _, _ ->
            BetterModel.registryOrNull(player.uuid)?.let { registry ->
                registry.despawn()
                registry.refresh()
            }
        }

        // same as PlayerQuitEvent
        ServerPlayerEvents.LEAVE.register { player ->
            val fabricPlayer = player.connection.wrap()
            BetterModel.registryOrNull(fabricPlayer.uuid())?.close()

            PLATFORM.scheduler().asyncTask {
                EntityTrackerRegistry.registries { registry ->
                    registry.remove(fabricPlayer)
                }
            }

            (player.vehicle as? HitBox)?.dismount(fabricPlayer)
        }
    }

    private fun registerCombatEvents() {
        // same as EntityDamageByEntityEvent
        //
        // EntityDamageByEntityEvent are not expected to be called for non-living entities.
        // therefore, ServerLivingEntityEvents is used.
        //
        ServerLivingEntityEvents.ALLOW_DAMAGE.register { entity, source, _ ->
            val damager = source.entity
            if (damager != null) {
                val victim = if (entity is HitBox) entity.source().uuid() else entity.uuid
                val vehicle = damager.vehicle
                if (vehicle is HitBox &&
                    !vehicle.mountController().canBeDamagedByRider() &&
                    vehicle.source().uuid() == victim
                ) {
                    return@register false
                }
            }

            return@register true
        }

        // same as EntityDamageEvent
        //
        // EntityDamageEvent and EntityDamageByEntityEvent are not expected to be called for non-living entities.
        // therefore, ServerLivingEntityEvents is used.
        //
        ServerLivingEntityEvents.AFTER_DAMAGE.register { entity, _, _, _, _ ->
            entity.eachTracker { tracker ->
                tracker.animate(TrackerExtraAnimation.DAMAGE)
                tracker.damageTint()
            }
        }

        // same as EntityDeathEvent, PlayerDeathEvent
        ServerLivingEntityEvents.AFTER_DEATH.register { entity, _ ->
            entity.eachTracker { tracker ->
                tracker.animate(TrackerExtraAnimation.DEATH)
            }

            if (entity is ServerPlayer) {
                BetterModel.registryOrNull(entity.uuid)?.despawn()
            }
        }
    }

    private fun registerInteractionEvents() {
        // same as PlayerInteractAtEntityEvent, PlayerInteractEntityEvent
        UseEntityCallback.EVENT.register { clicker, _, hand, clicked, _ ->
            if (clicker !is ServerPlayer) {
                return@register InteractionResult.PASS
            }

            // for PlayerInteractAtEntityEvent
            (clicked as? HitBox)?.let { hitBox ->
                if (hand == InteractionHand.MAIN_HAND && !clicker.triggerDismount(clicked)) {
                    clicker.triggerMount(hitBox)
                }
            }

            return@register InteractionResult.PASS
        }
    }

    private fun ServerPlayer.triggerDismount(entity: Entity): Boolean {
        val oldVehicle = vehicle
        if (oldVehicle !is HitBox) {
            return false
        }

        val uuid = if (entity is HitBox) entity.source().uuid() else entity.uuid
        if (oldVehicle.source().uuid() != uuid || !oldVehicle.mountController().canDismountBySelf()) {
            return false
        }

        oldVehicle.dismount(connection.wrap())
        return true
    }

    private fun ServerPlayer.triggerMount(hitBox: HitBox) {
        if (hitBox.mountController().canMount()) {
            hitBox.mount(connection.wrap())
        }
    }

    private fun Entity.eachTracker(block: (EntityTracker) -> Unit) {
        BetterModel.registryOrNull(uuid)?.trackers()?.forEach { tracker ->
            block(tracker)
        }
    }
}
