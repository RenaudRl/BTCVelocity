/*
 * This source file is part of BetterModel.
 * Copyright (c) 2026 toxicity188
 * Licensed under the MIT License.
 * See LICENSE.md file for full license text.
 */

package kr.toxicity.model.impl.fabric

import kr.toxicity.model.api.mod.platform.*
import kr.toxicity.model.api.mod.platform.ModAdapter.adapt
import kr.toxicity.model.api.platform.*
import net.minecraft.server.network.ServerPlayerConnection
import net.minecraft.world.entity.Entity
import net.minecraft.world.entity.LivingEntity
import net.minecraft.world.item.ItemStack

val PlatformLocation.asFabric get() = this as ModLocation

fun Entity.wrap() = adapt(this)
fun LivingEntity.wrap() = adapt(this)
fun ServerPlayerConnection.wrap() = adapt(this)
fun ItemStack.wrap() = adapt(this)

fun PlatformEntity.unwarp(): Entity = (this as ModEntity).source()
fun PlatformLivingEntity.unwarp(): LivingEntity = (this as ModLivingEntity).source()
fun PlatformPlayer.unwarp(): ServerPlayerConnection = (this as ModPlayer).source()
fun PlatformItemStack.unwarp(): ItemStack = (this as ModItemStack).source()
