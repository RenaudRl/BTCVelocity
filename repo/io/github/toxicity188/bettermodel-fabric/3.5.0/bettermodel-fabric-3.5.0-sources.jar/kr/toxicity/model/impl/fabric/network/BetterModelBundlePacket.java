/*
 * This source file is part of BetterModel.
 * Copyright (c) 2026 toxicity188
 * Licensed under the MIT License.
 * See LICENSE.md file for full license text.
 */

package kr.toxicity.model.impl.fabric.network;

public interface BetterModelBundlePacket {
    boolean bettermodel$isBetterModelPacket();
    void bettermodel$setBetterModelPacket(boolean isBetterModel);
}
