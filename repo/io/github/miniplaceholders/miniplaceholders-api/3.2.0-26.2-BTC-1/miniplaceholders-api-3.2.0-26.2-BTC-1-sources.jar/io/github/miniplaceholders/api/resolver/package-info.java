/**
 * Resolvers available based on information obtained from Audiences
 */
package io.github.miniplaceholders.api.resolver;
