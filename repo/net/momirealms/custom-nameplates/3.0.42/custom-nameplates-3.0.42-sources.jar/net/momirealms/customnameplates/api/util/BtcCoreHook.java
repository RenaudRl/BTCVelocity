package net.momirealms.customnameplates.api.util;

import java.lang.reflect.Method;

/**
 * BTC-CORE integration hook (reflection-based, zero compile-time dependency).
 *
 * <p>Resolves {@code dev.btc.core.api.BTCCoreAPI.instance().getCurrentMspt()} via reflection so
 * CustomNameplates keeps its build fully aligned with upstream — no hard dependency on BTC-CORE.
 * When BTC-CORE is absent every call degrades gracefully (MSPT reported as 0), preserving the
 * exact original behaviour.</p>
 *
 * <p>Used by {@link net.momirealms.customnameplates.api.MainTask} to back off the periodic
 * refresh cycle when the server is under load, exactly as the task's own comment intends.</p>
 */
public final class BtcCoreHook {

    private static final Object API_INSTANCE;
    private static final Method GET_CURRENT_MSPT;

    static {
        Object instance = null;
        Method mspt = null;
        try {
            Class<?> apiClass = Class.forName("dev.btc.core.api.BTCCoreAPI");
            instance = apiClass.getMethod("instance").invoke(null);
            mspt = apiClass.getMethod("getCurrentMspt");
        } catch (Throwable ignored) {
            // BTC-CORE not present — hook stays inert.
        }
        API_INSTANCE = instance;
        GET_CURRENT_MSPT = mspt;
    }

    /**
     * MSPT (ms/tick) above which the refresh cycle starts backing off. A healthy 20-TPS server
     * runs at &le;50ms; we begin throttling slightly before that so we never amplify lag.
     */
    public static final double MSPT_THRESHOLD = 45.0;

    /**
     * Maximum number of refresh cycles to skip between two effective refreshes, even under
     * severe load — keeps nameplates from freezing entirely.
     */
    public static final int MAX_SKIP = 4;

    private BtcCoreHook() {
    }

    /**
     * @return the current server MSPT, or {@code 0.0} when BTC-CORE is unavailable.
     */
    public static double currentMspt() {
        if (API_INSTANCE == null || GET_CURRENT_MSPT == null) return 0.0;
        try {
            Object value = GET_CURRENT_MSPT.invoke(API_INSTANCE);
            return value instanceof Number ? ((Number) value).doubleValue() : 0.0;
        } catch (Throwable ignored) {
            return 0.0;
        }
    }

    /**
     * @return the number of upcoming refresh cycles to skip based on current MSPT, clamped to
     *         {@code [0, MAX_SKIP]}. Returns 0 when the server is healthy or BTC-CORE is absent.
     */
    public static int skipTicks() {
        double mspt = currentMspt();
        if (mspt <= MSPT_THRESHOLD) return 0;
        return Math.min(MAX_SKIP, (int) (mspt / MSPT_THRESHOLD) - 1);
    }
}
