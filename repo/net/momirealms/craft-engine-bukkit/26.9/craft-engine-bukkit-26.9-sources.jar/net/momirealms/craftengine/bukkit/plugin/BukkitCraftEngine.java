package net.momirealms.craftengine.bukkit.plugin;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.momirealms.antigrieflib.AntiGriefCompatibility;
import net.momirealms.antigrieflib.AntiGriefLib;
import net.momirealms.craftengine.bukkit.advancement.BukkitAdvancementManager;
import net.momirealms.craftengine.bukkit.api.event.CraftEngineReloadEvent;
import net.momirealms.craftengine.bukkit.attribute.BukkitAttributeManager;
import net.momirealms.craftengine.bukkit.attribute.damage.BukkitDamageIndicators;
import net.momirealms.craftengine.bukkit.block.BukkitBlockManager;
import net.momirealms.craftengine.bukkit.block.behavior.BukkitBlockBehaviors;
import net.momirealms.craftengine.bukkit.block.entity.renderer.constant.BukkitBlockEntityElementConfigs;
import net.momirealms.craftengine.bukkit.entity.BukkitEntityManager;
import net.momirealms.craftengine.bukkit.entity.furniture.BukkitFurnitureManager;
import net.momirealms.craftengine.bukkit.entity.furniture.behavior.BukkitFurnitureBehaviors;
import net.momirealms.craftengine.bukkit.entity.furniture.element.BukkitFurnitureElementConfigs;
import net.momirealms.craftengine.bukkit.entity.furniture.hitbox.BukkitFurnitureHitboxTypes;
import net.momirealms.craftengine.bukkit.entity.projectile.BukkitProjectileManager;
import net.momirealms.craftengine.bukkit.entity.seat.BukkitSeatManager;
import net.momirealms.craftengine.bukkit.font.BukkitFontManager;
import net.momirealms.craftengine.bukkit.item.BukkitItemManager;
import net.momirealms.craftengine.bukkit.item.behavior.BukkitItemBehaviors;
import net.momirealms.craftengine.bukkit.item.recipe.BukkitRecipeManager;
import net.momirealms.craftengine.bukkit.item.recipe.predicate.BukkitDataComponentPredicates;
import net.momirealms.craftengine.bukkit.loot.BukkitLootManager;
import net.momirealms.craftengine.bukkit.pack.BukkitPackManager;
import net.momirealms.craftengine.bukkit.painting.BukkitPaintingManager;
import net.momirealms.craftengine.bukkit.plugin.agent.RuntimePatcher;
import net.momirealms.craftengine.bukkit.plugin.command.BukkitCommandManager;
import net.momirealms.craftengine.bukkit.plugin.command.BukkitSenderFactory;
import net.momirealms.craftengine.bukkit.plugin.context.condition.TestFlagCondition;
import net.momirealms.craftengine.bukkit.plugin.gui.BukkitGuiManager;
import net.momirealms.craftengine.bukkit.plugin.injector.*;
import net.momirealms.craftengine.bukkit.plugin.network.BukkitNetworkManager;
import net.momirealms.craftengine.bukkit.plugin.proxy.BukkitProxyMessageManager;
import net.momirealms.craftengine.bukkit.plugin.scheduler.BukkitSchedulerAdapter;
import net.momirealms.craftengine.bukkit.plugin.script.BukkitScriptEventManager;
import net.momirealms.craftengine.bukkit.plugin.script.BukkitScriptPlaceholderManager;
import net.momirealms.craftengine.bukkit.sound.BukkitSoundManager;
import net.momirealms.craftengine.bukkit.util.EventUtils;
import net.momirealms.craftengine.bukkit.util.ServerUtils;
import net.momirealms.craftengine.bukkit.world.BukkitWorldManager;
import net.momirealms.craftengine.core.plugin.CraftEngine;
import net.momirealms.craftengine.core.plugin.classpath.ClassPathAppender;
import net.momirealms.craftengine.core.plugin.classpath.ReflectionClassPathAppender;
import net.momirealms.craftengine.core.plugin.classpath.URLClassPathAppender;
import net.momirealms.craftengine.core.plugin.command.sender.SenderFactory;
import net.momirealms.craftengine.core.plugin.compatibility.CompatibilityManager;
import net.momirealms.craftengine.core.plugin.config.Config;
import net.momirealms.craftengine.core.plugin.context.CommonConditions;
import net.momirealms.craftengine.core.plugin.dependency.Dependencies;
import net.momirealms.craftengine.core.plugin.dependency.Dependency;
import net.momirealms.craftengine.core.plugin.logger.JavaPluginLogger;
import net.momirealms.craftengine.core.plugin.logger.PluginLogger;
import net.momirealms.craftengine.core.plugin.scheduler.SchedulerTask;
import net.momirealms.craftengine.core.plugin.script.ScriptManagerImpl;
import net.momirealms.craftengine.core.util.*;
import net.momirealms.craftengine.proxy.BukkitProxy;
import net.momirealms.craftengine.proxy.adventure.text.event.RelocatedClickEventProxy;
import net.momirealms.sparrow.nbt.adventure.NBTComponentSerializer;
import org.bstats.bukkit.Metrics;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.Nullable;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@SuppressWarnings("unchecked")
public final class BukkitCraftEngine extends CraftEngine {
    private static final String COMPATIBILITY_CLASS = "net.momirealms.craftengine.bukkit.compatibility.BukkitCompatibilityManager";
    private static BukkitCraftEngine instance;
    private final List<AntiGriefCompatibility> antiGriefProviders = new ArrayList<>(1);
    private final Path dataFolderPath;
    private SchedulerTask tickTask;
    private SchedulerTask asyncTickTask;
    private boolean successfullyLoaded = false;
    private boolean successfullyEnabled = false;
    private AntiGriefLib antiGrief;
    private JavaPlugin javaPlugin;
    private ServerEventListener serverEventListener;

    BukkitCraftEngine(JavaPlugin plugin) {
        this(new JavaPluginLogger(plugin.getLogger()), plugin.getDataFolder().toPath().toAbsolutePath(),
                new URLClassPathAppender(Bukkit.class.getClassLoader()), new ReflectionClassPathAppender(plugin.getClass().getClassLoader()));
        this.setJavaPlugin(plugin);
    }

    BukkitCraftEngine(PluginLogger logger, Path dataFolderPath, ClassPathAppender sharedClassPathAppender, ClassPathAppender privateClassPathAppender) {
        instance = this;
        this.dataFolderPath = dataFolderPath;
        super.sharedClassPathAppender = sharedClassPathAppender;
        super.privateClassPathAppender = privateClassPathAppender;
        super.logger = logger;
        super.platform = new BukkitPlatform(this);
        super.scheduler = new BukkitSchedulerAdapter(this);
        Class<?> compatibilityClass = ReflectionUtils.getClazz(COMPATIBILITY_CLASS);
        if (compatibilityClass != null) {
            try {
                super.compatibilityManager = (CompatibilityManager) Objects.requireNonNull(ReflectionUtils.getConstructor(compatibilityClass, 0)).newInstance(this);
            } catch (ReflectiveOperationException e) {
                logger().warn("Compatibility class could not be instantiated: " + compatibilityClass.getName());
            }
        }
    }

    public static BukkitCraftEngine instance() {
        return instance;
    }

    @Override
    protected void callReloadEvent() {
        EventUtils.fireAndForget(new CraftEngineReloadEvent(this));
    }

    void setJavaPlugin(JavaPlugin javaPlugin) {
        this.javaPlugin = javaPlugin;
    }

    @Override
    public void setUpConfigAndLocale() {
        super.setUpConfigAndLocale();
        super.packManager = new BukkitPackManager(this);
    }

    // 这个方法应该尽早被执行，最好是boostrap阶段
    public void injectRegistries() {
        if (super.blockManager != null) return;
        this.logger.info("Initializing registries...");
        try {
            BlockGenerator.init();
            BlockStateGenerator.init();
            StatePredicateGenerator.init();
            FallingBlockEntityGenerator.init();
            super.blockManager = new BukkitBlockManager(this);
        } catch (Throwable e) {
            throw new InjectionException("Error injecting blocks", e);
        }
        try {
            LootEntryInjector.init();
        } catch (Throwable e) {
            throw new InjectionException("Error injecting loot entries", e);
        }
        try {
            FeatureInjector.init();
        } catch (Throwable e) {
            throw new InjectionException("Error injecting features", e);
        }
        try {
            BiomeFilterGenerator.init();
        } catch (Throwable e) {
            throw new InjectionException("Error injecting biome filter", e);
        }
        try {
            BlockStateProviderInjector.init();
        } catch (Throwable e) {
            throw new InjectionException("Error injecting block state providers", e);
        }
    }

    @Override
    public void onPluginLoad() {
        // 普通bukkit插件会到这里才注册自定义方块
        if (super.blockManager == null) {
            this.injectRegistries();
        }
        // 注入一些新的类型，但是并不需要太早
        try {
            RecipeInjector.init();
        } catch (Throwable e) {
            throw new InjectionException("Error injecting recipes", e);
        }
        try {
            DispenserInjector.init();
        } catch (Throwable e) {
            throw new InjectionException("Error injecting dispensers", e);
        }
        // 初始化一些注册表
        super.onPluginLoad();
        NBTComponentSerializer.setClickEventFactory(RelocatedClickEventProxy.INSTANCE::newInstance);
        BukkitBlockBehaviors.init();
        BukkitItemBehaviors.init();
        BukkitFurnitureBehaviors.init();
        BukkitFurnitureHitboxTypes.init();
        BukkitDamageIndicators.init();
        BukkitBlockEntityElementConfigs.init();
        BukkitFurnitureElementConfigs.init();
        BukkitDataComponentPredicates.init();
        CommonConditions.register(Key.ce("test_flag"), TestFlagCondition.factory());
        // 创建网络管理器
        super.networkManager = new BukkitNetworkManager(this);
        // 初始化方块管理器，获取镜像注册表，初始化网络映射
        super.blockManager.init();
        // 初始化物品管理器
        super.itemManager = new BukkitItemManager(this);
        // 初始化配方管理器
        super.recipeManager = new BukkitRecipeManager(this);
        // 初始化GUI管理器
        super.guiManager = new BukkitGuiManager(this);
        // 初始化世界管理器
        super.worldManager = new BukkitWorldManager(this);
        // 初始化声音管理器
        super.soundManager = new BukkitSoundManager(this);
        // 初始化战利品管理器
        super.lootManager = new BukkitLootManager(this);
        // 初始化字体管理器
        super.fontManager = new BukkitFontManager(this);
        // 初始化进度管理器
        super.advancementManager = new BukkitAdvancementManager(this);
        // 初始化弹射物管理器
        super.projectileManager = new BukkitProjectileManager(this);
        // 初始化座椅管理器
        super.seatManager = new BukkitSeatManager(this);
        // 初始化家具管理器
        super.furnitureManager = new BukkitFurnitureManager(this);
        // 初始化画管理器
        super.paintingManager = new BukkitPaintingManager(this);
        // 初始化属性管理器
        super.attributeManager = new BukkitAttributeManager(this);
        // 初始化实体管理器
        super.entityManager = new BukkitEntityManager(this);
        // 阻止无物品谓词的原版商人交易接受 CE 物品
        RuntimePatcher.installMerchantItemMatchHook(this);
        // 重定义 LivingEntity
        RuntimePatcher.installEquipmentChangeHook(this);
        // 为 Spigot 补上世界实体加入/移除回调；Paper 使用原生事件。
        RuntimePatcher.installEntityWorldHook(this);
        // 注册默认的parser
        this.registerDefaultParsers();
        // 脚本事件订阅挂到 Bukkit 事件总线
        if (super.scriptManager instanceof ScriptManagerImpl scriptManager) {
            scriptManager.setEventSubscriber(new BukkitScriptEventManager(this));
            scriptManager.setPlaceholderManager(new BukkitScriptPlaceholderManager());
        }
        // 完成加载
        this.successfullyLoaded = true;
    }

    @Override
    protected List<Dependency> platformDependencies() {
        return List.of(
                Dependencies.CRAFT_ENGINE_BUKKIT_PROXY,
                Dependencies.BSTATS_BUKKIT,
                Dependencies.CLOUD_BUKKIT, Dependencies.CLOUD_PAPER, Dependencies.CLOUD_BRIGADIER, Dependencies.CLOUD_MINECRAFT_EXTRAS
        );
    }

    @Override
    public void onPluginEnable() {
        if (this.successfullyEnabled) {
            logger().error(" ");
            logger().error(" ");
            logger().error(" ");
            logger().error("Please do not restart plugins at runtime.");
            logger().error(" ");
            logger().error(" ");
            logger().error(" ");
            Bukkit.getPluginManager().disablePlugin(this.javaPlugin);
            return;
        }
        this.initASMProxies(); // 仅 dev 模式下生效
        this.successfullyEnabled = true;
        if (!this.successfullyLoaded) {
            logger().error(" ");
            logger().error(" ");
            logger().error(" ");
            logger().error("Failed to enable CraftEngine. Please check the log on loading stage.");
            logger().error("To reduce the loss caused by plugin not loaded, now shutting down the server");
            logger().error(" ");
            logger().error(" ");
            logger().error(" ");
            Bukkit.getServer().shutdown();
            return;
        }
        // 初始化指令发送者工厂
        super.senderFactory = new BukkitSenderFactory(this);
        // 初始化指令管理器
        super.commandManager = new BukkitCommandManager(this);
        // 初始化代理消息管理器
        super.proxyMessageManager = new BukkitProxyMessageManager(this);
        try {
            super.compatibilityManager().onEnable();
        } catch (Throwable t) {
            this.logger.error("Failed to enable compatibility manager", t);
        }
        super.onPluginEnable();
        Bukkit.getMessenger().registerOutgoingPluginChannel(this.javaPlugin(), "BungeeCord");
        if (VersionHelper.hasPaperPatch) {
            this.serverEventListener = new ServerEventListener(this);
            Bukkit.getPluginManager().registerEvents(this.serverEventListener, javaPlugin());
        }
    }

    @Override
    public void onPluginDisable() {
        if (super.isDisabled) return;
        RuntimePatcher.clearEntityWorldCallbacks(this);
        super.onPluginDisable();
        if (this.tickTask != null) this.tickTask.cancel();
        if (this.asyncTickTask != null) this.asyncTickTask.cancel();
        if (VersionHelper.hasPaperPatch && ServerUtils.isRunning()) {
            logger().error(" ");
            logger().error(" ");
            logger().error(" ");
            logger().error("Please do not disable plugins at runtime.");
            logger().error(" ");
            logger().error(" ");
            logger().error(" ");
            Bukkit.getServer().shutdown();
        }
    }

    @Override
    public void platformDelayedEnable() {
        if (Config.metrics()) {
            new Metrics(this.javaPlugin(), 24333);
        }
        this.asyncTickTask = this.scheduler().platform().runAsyncRepeating(new AsyncTickTask(this), 1, 1);
        // tick task
        if (!VersionHelper.hasFoliaPatch) {
            this.tickTask = this.scheduler().platform().runRepeating(new MainTickTask(this), 1, 1);
        }
    }

    @Override
    public void setupProxy() {
        BukkitProxy.init(VersionHelper.MINECRAFT_VERSION.version(), getPatches(), ReflectionUtils.LOOKUP);
    }

    private void initASMProxies() {
        if (!VersionHelper.IS_RUNNING_IN_DEV) return;
        CraftEngine.instance().logger().info("Initializing ASM proxies...");
        ClassLoader classLoader = ReflectionUtils.class.getClassLoader();
        ExceptionCollector<Throwable> collector = new ExceptionCollector<>(Throwable.class);
        try (InputStream resourceAsStream = classLoader.getResourceAsStream("proxy.jarinjar")) {
            if (resourceAsStream == null) return;
            try (ByteArrayInputStream bais = new ByteArrayInputStream(resourceAsStream.readAllBytes());
                 ZipInputStream zis = new ZipInputStream(bais)) {
                ZipEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    String entryName = entry.getName();
                    if (!entryName.endsWith(".class")) continue;
                    String className = entryName.replace('/', '.').substring(0, entryName.length() - 6);
                    try {
                        Class.forName(className);
                    } catch (Throwable e) {
                        collector.add(e);
                    }
                }
            } catch (Throwable e) {
                collector.add(e);
            }
        } catch (Throwable e) {
            collector.add(e);
        }
        try {
            collector.throwIfPresent();
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    private List<String> getPatches() {
        List<String> patches = new ObjectArrayList<>();
        if (VersionHelper.hasPaperPatch)
            patches.add("paper");
        if (VersionHelper.hasFoliaPatch)
            patches.add("folia");
        if (VersionHelper.hasLeavesPatch)
            patches.add("leaves");
        if (VersionHelper.hasCanvasPatch)
            patches.add("canvas");
        if (VersionHelper.hasLeafPatch)
            patches.add("leaf");
        if (VersionHelper.hasUniverseSpigotPatch)
            patches.add("universespigot");
        return patches;
    }

    @Override
    public InputStream resourceStream(String filePath) {
        return getResource(CharacterUtils.replaceBackslashWithSlash(filePath));
    }

    private @Nullable InputStream getResource(String filename) {
        if (filename == null) {
            throw new IllegalArgumentException("filename cannot be null");
        }
        try {
            URL url = this.getClass().getClassLoader().getResource(filename);
            if (url == null) {
                return null;
            }
            URLConnection connection = url.openConnection();
            connection.setUseCaches(false);
            return connection.getInputStream();
        } catch (IOException ex) {
            return null;
        }
    }

    @Override
    public File dataFolderFile() {
        return this.dataFolderPath.toFile();
    }

    @Override
    public Path dataFolderPath() {
        return this.dataFolderPath;
    }

    @SuppressWarnings("deprecation")
    @Override
    public String pluginVersion() {
        return javaPlugin().getDescription().getVersion();
    }

    @Override
    public String serverVersion() {
        return VersionHelper.MINECRAFT_VERSION.version();
    }

    @Override
    public BukkitItemManager itemManager() {
        return (BukkitItemManager) this.itemManager;
    }

    @Override
    public BukkitBlockManager blockManager() {
        return (BukkitBlockManager) this.blockManager;
    }

    @Override
    public BukkitAdvancementManager advancementManager() {
        return (BukkitAdvancementManager) this.advancementManager;
    }

    @Override
    public BukkitEntityManager entityManager() {
        return (BukkitEntityManager) this.entityManager;
    }

    @Override
    public BukkitFurnitureManager furnitureManager() {
        return (BukkitFurnitureManager) this.furnitureManager;
    }

    @Override
    public BukkitNetworkManager networkManager() {
        return (BukkitNetworkManager) this.networkManager;
    }

    @Override
    public BukkitPackManager packManager() {
        return (BukkitPackManager) this.packManager;
    }

    @Override
    public BukkitFontManager fontManager() {
        return (BukkitFontManager) this.fontManager;
    }

    @Override
    public BukkitWorldManager worldManager() {
        return (BukkitWorldManager) this.worldManager;
    }

    @Override
    public SenderFactory<CraftEngine, CommandSender> senderFactory() {
        return (SenderFactory<CraftEngine, CommandSender>) this.senderFactory;
    }

    @Override
    public BukkitSchedulerAdapter scheduler() {
        return (BukkitSchedulerAdapter) this.scheduler;
    }

    public JavaPlugin javaPlugin() {
        return this.javaPlugin;
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    @Override
    public void saveResource(String resourcePath) {
        if (resourcePath.isEmpty()) {
            throw new IllegalArgumentException("ResourcePath cannot be null or empty");
        }

        File outFile = new File(dataFolderFile(), resourcePath);
        if (outFile.exists())
            return;

        resourcePath = resourcePath.replace('\\', '/');
        InputStream in = resourceStream(resourcePath);
        if (in == null)
            return;

        int lastIndex = resourcePath.lastIndexOf('/');
        File outDir = new File(dataFolderFile(), resourcePath.substring(0, Math.max(lastIndex, 0)));

        if (!outDir.exists()) {
            outDir.mkdirs();
        }

        try {
            OutputStream out = new FileOutputStream(outFile);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            out.close();
            in.close();

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Register custom protection logics
     *
     * @param provider protection provider
     */
    public void registerProtectionProvider(AntiGriefCompatibility provider) {
        this.antiGriefProviders.add(provider);
        this.antiGrief = null;
    }

    public AntiGriefLib antiGriefProvider() {
        if (this.antiGrief == null) {
            AntiGriefLib.Builder builder = AntiGriefLib.builder(this.javaPlugin)
                    .ignoreOP(true)
                    .silentLogs(false)
                    .bypassPermission("craftengine.antigrief.bypass");
            for (AntiGriefCompatibility compatibility : this.antiGriefProviders) {
                builder.register(compatibility);
            }
            this.antiGrief = builder.build();
        }
        return this.antiGrief;
    }
}
