package net.momirealms.craftengine.core.pack;

public final class LoadingSequence {
    private LoadingSequence() {}

    // 模板第一位
    public static final int TEMPLATE = 0;
    public static final int BLOCK_STATE_MAPPING = 10;
    public static final int GLOBAL_VAR = 20;
    public static final int TRANSLATION = 30;
    public static final int EQUIPMENT = 40;
    public static final int ITEM = 50;
    public static final int BLOCK = 60;
    public static final int FURNITURE = 70;
    public static final int IMAGE = 80;
    public static final int RECIPE = 90;
    public static final int CATEGORY = 100;
    public static final int SOUND = 110;
    public static final int JUKEBOX_SONG = 120;
    public static final int VANILLA_LOOTS = 130;
    public static final int EMOJI = 140;
    public static final int ADVANCEMENT = 150;
    public static final int LANG = 160;
    public static final int SKIP_OPTIMIZATION = 170;
    public static final int CONFIGURED_FEATURE = 180;
    public static final int PLACED_FEATURE = 190;
}
