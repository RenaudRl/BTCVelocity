package net.momirealms.craftengine.core.item.component;

public final class DataComponentIds {
    private DataComponentIds() {}

    public static final String ITEM_NAME = "minecraft:item_name";
    public static final String ITEM_MODEL = "minecraft:item_model";
    public static final String CUSTOM_NAME = "minecraft:custom_name";
    public static final String ENCHANTMENTS = "minecraft:enchantments";
    public static final String LORE = "minecraft:lore";
    public static final String CUSTOM_DATA = "minecraft:custom_data";
}
