/*
 * Copyright (C) 2018-2026 Velocity Contributors
 *
 * The Velocity API is licensed under the terms of the MIT License. For more details,
 * reference the LICENSE file in the api top-level directory.
 */

package com.velocitypowered.api.event.player;

import static com.google.common.base.Preconditions.checkNotNull;

import com.google.common.io.BaseEncoding;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteStreams;
import com.velocitypowered.api.event.ResultedEvent;
import com.velocitypowered.api.event.annotation.AwaitingEvent;
import com.velocitypowered.api.event.player.ServerLoginPluginMessageEvent.ResponseResult;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.messages.ChannelIdentifier;
import java.io.ByteArrayInputStream;
import java.util.Arrays;
import org.checkerframework.checker.nullness.qual.Nullable;

/**
 * Fired when a server sends a login plugin message to the proxy. Plugins have the opportunity to
 * respond to the messages as needed. Velocity will wait on this event to finish. The server will
 * be responsible for continuing the login process once the server is satisfied with any login
 * plugin responses sent by proxy plugins (or messages indicating a lack of response).
 */
@AwaitingEvent
public class ServerLoginPluginMessageEvent implements ResultedEvent<ResponseResult> {

  /**
   * The connection from which the login plugin message was received.
   */
  private final ServerConnection connection;

  /**
   * The identifier of the channel the message was sent on.
   */
  private final ChannelIdentifier identifier;

  /**
   * The raw contents of the plugin message.
   */
  private final byte[] contents;

  /**
   * The unique sequence ID of this plugin message, used for response routing.
   */
  private final int sequenceId;

  /**
   * The result representing the response to this login plugin message.
   */
  private ResponseResult result;

  /**
   * Constructs a new {@code ServerLoginPluginMessageEvent}.
   *
   * @param connection the connection on which the plugin message was sent
   * @param identifier the channel identifier for the message sent
   * @param contents the contents of the message
   * @param sequenceId the ID of the message
   */
  public ServerLoginPluginMessageEvent(final ServerConnection connection, final ChannelIdentifier identifier,
                                       final byte[] contents, final int sequenceId) {
    this.connection = checkNotNull(connection, "connection");
    this.identifier = checkNotNull(identifier, "identifier");
    this.contents = checkNotNull(contents, "contents");
    this.sequenceId = sequenceId;
    this.result = ResponseResult.UNKNOWN;
  }

  /**
   * Gets the current {@link ResponseResult} associated with this plugin message event.
   *
   * <p>If the result is {@link ResponseResult#unknown()}, the proxy will indicate that it did not handle
   * the plugin message and will return a negative response to the backend server.</p>
   *
   * @return the result of this event
   */
  @Override
  public ResponseResult getResult() {
    return this.result;
  }

  /**
   * Sets the {@link ResponseResult} for this plugin message event.
   *
   * <p>Use {@link ResponseResult#reply(byte[])} to respond with data, or {@link ResponseResult#unknown()}
   * to indicate that the plugin message was not handled.</p>
   *
   * @param result the new result to apply to this event
   * @throws NullPointerException if {@code result} is null
   */
  @Override
  public void setResult(final ResponseResult result) {
    this.result = checkNotNull(result, "result");
  }

  /**
   * Gets the connection from which the login plugin message was received.
   *
   * @return the server connection
   */
  public ServerConnection getConnection() {
    return connection;
  }

  /**
   * Gets the identifier of the channel this login plugin message was sent on.
   *
   * @return the channel identifier
   */
  public ChannelIdentifier getIdentifier() {
    return identifier;
  }

  /**
   * Returns a copy of the contents contained in the login plugin message sent by the server.
   *
   * @return the contents of the message
   */
  public byte[] getContents() {
    return contents.clone();
  }

  /**
   * Returns the contents of the login plugin message sent by the server as an
   * {@link java.io.InputStream}.
   *
   * @return the contents of the message as a stream
   */
  public ByteArrayInputStream contentsAsInputStream() {
    return new ByteArrayInputStream(contents);
  }

  /**
   * Returns the contents of the login plugin message sent by the server as an
   * {@link ByteArrayDataInput}.
   *
   * @return the contents of the message as a {@link java.io.DataInput}
   */
  public ByteArrayDataInput contentsAsDataStream() {
    return ByteStreams.newDataInput(contents);
  }

  /**
   * Gets the sequence ID of the plugin message sent by the server.
   *
   * @return the sequence ID
   */
  public int getSequenceId() {
    return sequenceId;
  }

  /**
   * Returns a string representation of this {@code ServerLoginPluginMessageEvent}.
   *
   * <p>The output includes the connection, message channel identifier, sequence ID,
   * base-16 encoded message content, and the current response result.</p>
   *
   * @return a human-readable string describing the event state
   */
  @Override
  public String toString() {
    return "ServerLoginPluginMessageEvent{"
        + "connection=" + connection
        + ", identifier=" + identifier
        + ", sequenceId=" + sequenceId
        + ", contents=" + BaseEncoding.base16().encode(contents)
        + ", result=" + result
        + '}';
  }

  /**
   * The result class, containing a response to the login plugin message sent by the server.
   */
  public static final class ResponseResult implements ResultedEvent.Result {

    /**
     * A result indicating that no response was provided for the message.
     */
    private static final ResponseResult UNKNOWN = new ResponseResult(null);

    /**
     * The response payload to be sent back to the server, or {@code null} if not handled.
     */
    private final byte @Nullable [] response;

    private ResponseResult(final byte @Nullable [] response) {
      this.response = response;
    }

    @Override
    public boolean isAllowed() {
      return response != null;
    }

    /**
     * Returns the response to the message.
     *
     * @return the response to the message
     * @throws IllegalStateException if there is no reply (an unknown message)
     */
    public byte[] getResponse() {
      if (response == null) {
        throw new IllegalStateException("Fetching response of unknown message result");
      }

      return response.clone();
    }

    /**
     * Returns a result indicating that this login plugin message was not handled by the proxy.
     *
     * @return the unknown response result
     */
    public static ResponseResult unknown() {
      return UNKNOWN;
    }

    /**
     * Returns a result with a reply to the server's login plugin message.
     *
     * @param response the response bytes to send
     * @return a response result containing the response data
     */
    public static ResponseResult reply(final byte[] response) {
      checkNotNull(response, "response");
      return new ResponseResult(response);
    }

    @Override
    public boolean equals(final Object o) {
      if (this == o) {
        return true;
      }

      if (o == null || getClass() != o.getClass()) {
        return false;
      }

      ResponseResult that = (ResponseResult) o;
      return Arrays.equals(response, that.response);
    }

    @Override
    public int hashCode() {
      return Arrays.hashCode(response);
    }

    @Override
    public String toString() {
      return "ResponseResult{"
          + "response=" + (response == null ? "none" : BaseEncoding.base16().encode(response))
          + '}';
    }
  }
}
