/*
 * Copyright (C) 2018-2026 Velocity Contributors
 *
 * The Velocity API is licensed under the terms of the MIT License. For more details,
 * reference the LICENSE file in the api top-level directory.
 */

package com.velocitypowered.api.event.player;

import com.google.common.base.Preconditions;
import com.velocitypowered.api.event.ResultedEvent;
import com.velocitypowered.api.event.annotation.AwaitingEvent;
import com.velocitypowered.api.proxy.Player;
import net.kyori.adventure.key.Key;

/**
 * This event is fired when a cookie from a client is requested either by a proxy plugin or
 * by a backend server. Velocity will wait on this event to finish firing before discarding the
 * cookie request (if handled) or forwarding it to the client.
 */
@AwaitingEvent
public final class CookieRequestEvent implements ResultedEvent<CookieRequestEvent.ForwardResult> {

  /**
   * The player from whom the cookie is being requested.
   */
  private final Player player;

  /**
   * The original identifier of the cookie being requested.
   */
  private final Key originalKey;

  /**
   * The result determining whether the cookie request should be forwarded or handled.
   */
  private ForwardResult result;

  /**
   * Creates a new instance.
   *
   * @param player the player from whom the cookies is requested
   * @param key the identifier of the cookie
   */
  public CookieRequestEvent(final Player player, final Key key) {
    this.player = Preconditions.checkNotNull(player, "player");
    this.originalKey = Preconditions.checkNotNull(key, "key");
    this.result = ForwardResult.forward();
  }

  @Override
  public ForwardResult getResult() {
    return result;
  }

  @Override
  public void setResult(final ForwardResult result) {
    this.result = Preconditions.checkNotNull(result, "result");
  }

  /**
   * Returns the player from whom the cookie is being requested.
   *
   * @return the player
   */
  public Player getPlayer() {
    return player;
  }

  /**
   * Returns the original identifier of the cookie being requested.
   *
   * @return the original cookie key
   */
  public Key getOriginalKey() {
    return originalKey;
  }

  @Override
  public String toString() {
    return "CookieRequestEvent{"
        + ", originalKey=" + originalKey
        + ", result=" + result
        + '}';
  }

  /**
   * A result determining whether to forward the cookie request on.
   */
  public static final class ForwardResult implements Result {

    /**
     * A result indicating the cookie request should be forwarded to the client unchanged.
     */
    private static final ForwardResult ALLOWED = new ForwardResult(true, null);

    /**
     * A result indicating the cookie request has been handled by the proxy and should not be forwarded.
     */
    private static final ForwardResult DENIED = new ForwardResult(false, null);

    /**
     * Whether the cookie request should be forwarded to the client.
     */
    private final boolean status;

    /**
     * A replacement key for the cookie request, or {@code null} if the original key should be used.
     */
    private final Key key;

    private ForwardResult(final boolean status, final Key key) {
      this.status = status;
      this.key = key;
    }

    @Override
    public boolean isAllowed() {
      return status;
    }

    /**
     * Returns the replacement key to use for the cookie request, if one was provided.
     *
     * @return the new key, or {@code null} if unchanged
     */
    public Key getKey() {
      return key;
    }

    @Override
    public String toString() {
      return status ? "forward to client" : "handled by proxy";
    }

    /**
     * Allows the cookie request to be forwarded to the client.
     *
     * @return the forward result
     */
    public static ForwardResult forward() {
      return ALLOWED;
    }

    /**
     * Prevents the cookie request from being forwarded to the client, the cookie request is
     * handled by the proxy.
     *
     * @return the handled result
     */
    public static ForwardResult handled() {
      return DENIED;
    }

    /**
     * Allows the cookie request to be forwarded to the client, but silently replaces the
     * identifier of the cookie with another.
     *
     * @param key the identifier to use instead
     * @return a result with a new key
     */
    public static ForwardResult key(final Key key) {
      Preconditions.checkNotNull(key, "key");
      return new ForwardResult(true, key);
    }
  }
}
