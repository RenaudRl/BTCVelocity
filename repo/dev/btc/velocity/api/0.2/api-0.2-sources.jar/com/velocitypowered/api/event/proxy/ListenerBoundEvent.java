/*
 * Copyright (C) 2018-2026 Velocity Contributors
 *
 * The Velocity API is licensed under the terms of the MIT License. For more details,
 * reference the LICENSE file in the api top-level directory.
 */

package com.velocitypowered.api.event.proxy;

import com.google.common.base.Preconditions;
import com.velocitypowered.api.network.ListenerType;
import java.net.InetSocketAddress;

/**
 * The proxy fires this event after a listener starts accepting connections.
 */
public final class ListenerBoundEvent {

  /**
   * The socket address the listener is bound to.
   */
  private final InetSocketAddress address;

  /**
   * The type of listener that was bound.
   */
  private final ListenerType listenerType;

  /**
   * Constructs a new {@link ListenerBoundEvent}.
   *
   * @param address the socket address the listener is bound to
   * @param listenerType the type of listener that was bound
   */
  public ListenerBoundEvent(final InetSocketAddress address, final ListenerType listenerType) {
    this.address = Preconditions.checkNotNull(address, "address");
    this.listenerType = Preconditions.checkNotNull(listenerType, "listenerType");
  }

  /**
   * Returns the socket address the listener is bound to.
   *
   * @return the bound socket address
   */
  public InetSocketAddress getAddress() {
    return address;
  }

  /**
   * Returns the type of listener that was bound.
   *
   * @return the listener type
   */
  public ListenerType getListenerType() {
    return listenerType;
  }

  @Override
  public String toString() {
    return "ListenerBoundEvent{"
        + "address=" + address
        + ", listenerType=" + listenerType
        + '}';
  }
}
