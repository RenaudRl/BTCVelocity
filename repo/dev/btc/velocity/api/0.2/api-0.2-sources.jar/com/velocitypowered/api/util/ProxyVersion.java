/*
 * Copyright (C) 2018-2026 Velocity Contributors
 *
 * The Velocity API is licensed under the terms of the MIT License. For more details,
 * reference the LICENSE file in the api top-level directory.
 */

package com.velocitypowered.api.util;

import com.google.common.base.Preconditions;
import java.util.Objects;
import org.checkerframework.checker.nullness.qual.Nullable;

/**
 * Provides a version object for the proxy.
 */
public final class ProxyVersion {

  /**
   * The name of the proxy implementation (e.g., "Velocity").
   */
  private final String name;

  /**
   * The vendor of the proxy implementation (e.g., "Velocity Contributors").
   */
  private final String vendor;

  /**
   * The version string of the proxy implementation.
   */
  private final String version;

  /**
   * Creates a new {@link ProxyVersion} instance.
   *
   * @param name the name for the proxy implementation
   * @param vendor the vendor for the proxy implementation
   * @param version the version for the proxy implementation
   */
  public ProxyVersion(final String name, final String vendor, final String version) {
    this.name = Preconditions.checkNotNull(name, "name");
    this.vendor = Preconditions.checkNotNull(vendor, "vendor");
    this.version = Preconditions.checkNotNull(version, "version");
  }

  /**
   * Gets the name of the proxy implementation.
   *
   * @return the name of the proxy
   */
  public String getName() {
    return name;
  }

  /**
   * Gets the vendor of the proxy implementation.
   *
   * @return the vendor of the proxy
   */
  public String getVendor() {
    return vendor;
  }

  /**
   * Gets the version of the proxy implementation.
   *
   * @return the version of the proxy
   */
  public String getVersion() {
    return version;
  }

  @Override
  public boolean equals(final @Nullable Object o) {
    if (this == o) {
      return true;
    }

    if (o == null || getClass() != o.getClass()) {
      return false;
    }

    ProxyVersion that = (ProxyVersion) o;
    return Objects.equals(name, that.name)
        && Objects.equals(vendor, that.vendor)
        && Objects.equals(version, that.version);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, vendor, version);
  }

  @Override
  public String toString() {
    return "ProxyVersion{"
        + "name='" + name + '\''
        + ", vendor='" + vendor + '\''
        + ", version='" + version + '\''
        + '}';
  }
}
