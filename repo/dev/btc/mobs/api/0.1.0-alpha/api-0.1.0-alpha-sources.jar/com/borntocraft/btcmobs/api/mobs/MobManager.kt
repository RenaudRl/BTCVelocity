package com.borntocraft.btcmobs.api.mobs

import org.bukkit.Location
import com.borntocraft.btcmobs.api.core.mobs.ActiveMob
import com.borntocraft.btcmobs.api.core.mobs.DespawnReason
import com.borntocraft.btcmobs.api.core.mobs.EggExecutor
import com.borntocraft.btcmobs.api.core.mobs.MobSpawnOptions
import com.borntocraft.btcmobs.api.core.mobs.MobStack
import com.borntocraft.btcmobs.api.mobs.entities.BtcEntityType
import com.borntocraft.btcmobs.api.skills.SkillCaster
import java.util.Collection
import java.util.Optional
import java.util.UUID

typealias MobLevelProvider = (BtcMob, Location, MobSpawnOptions) -> Double?

/**
 * Exposes information about active and registered Mythic mobs.
 *
 * This interface provides the primary API for querying, spawning, and managing
 * Mythic mob instances within the BornToCraft runtime. It serves as the central
 * registry for mob types and active mob instances, and coordinates with the
 * egg execution system for spawn egg interactions.
 */
interface MobManager {
    /** The egg executor that handles Mythic spawn egg interactions. */
    val eggManager: EggExecutor

    /**
     * Returns all registered Mythic mob types.
     *
     * @return A collection of all registered [BtcMob] definitions.
     */
    fun getMobTypes(): Collection<BtcMob>

    /**
     * Returns the names of all registered Mythic mob types.
     *
     * @return A collection of registered mob type names.
     */
    fun getMobNames(): Collection<String>

    /**
     * Returns all registered vanilla Mythic mob types.
     *
     * Vanilla types are those that mirror standard Minecraft entity types.
     *
     * @return A collection of [BtcMob] definitions for vanilla entity types.
     */
    fun getVanillaTypes(): Collection<BtcMob>

    /**
     * Looks up the vanilla Mythic mob type associated with the given entity type.
     *
     * @param entityType The Mythic entity type to look up.
     * @return An [Optional] containing the matching [BtcMob], or empty if none is registered.
     */
    fun getVanillaType(entityType: BtcEntityType): Optional<BtcMob>

    /**
     * Returns all registered mob stack definitions.
     *
     * Mob stacks define groups of mobs that spawn together.
     *
     * @return A collection of all registered [MobStack] instances.
     */
    fun getMobStacks(): Collection<MobStack>

    /**
     * Returns all currently active (spawned) Mythic mobs.
     *
     * @return A collection of all active [ActiveMob] instances.
     */
    fun getActiveMobs(): Collection<ActiveMob>

    /**
     * Returns all active Mythic mobs that are currently in combat.
     *
     * @return A collection of [ActiveMob] instances that have active threat targets.
     */
    fun getActiveMobsInCombat(): Collection<ActiveMob>

    /**
     * Looks up an active mob by its unique identifier.
     *
     * @param uniqueId The UUID of the active mob to look up.
     * @return An [Optional] containing the [ActiveMob] if found, or empty if no mob with the given UUID is active.
     */
    fun getActiveMob(uniqueId: UUID): Optional<ActiveMob>

    /**
     * Returns the [SkillCaster] associated with the active mob identified by the given UUID.
     *
     * @param uniqueId The UUID of the active mob.
     * @return An [Optional] containing the [SkillCaster], or empty if no active mob with the given UUID exists.
     */
    fun getSkillCaster(uniqueId: UUID): Optional<SkillCaster>

    /**
     * Looks up a registered Mythic mob type by its internal name.
     *
     * @param name The internal name of the mob type to look up.
     * @return An [Optional] containing the [BtcMob] if found, or empty if no mob type is registered under the given name.
     */
    fun getBtcMob(name: String): Optional<BtcMob>

    /**
     * Registers a new Mythic mob type.
     *
     * @param btcMob The mob type definition to register.
     */
    fun registerMobType(btcMob: BtcMob)

    /**
     * Unregisters a previously registered Mythic mob type.
     *
     * @param name The internal name of the mob type to unregister.
     * @return `true` if the mob type was found and removed, `false` if it was not registered.
     */
    fun unregisterMobType(name: String): Boolean

    /**
     * Returns the global level provider, if one has been set.
     *
     * The global level provider is used to determine the level of spawned mobs
     * based on the mob type, spawn location, and spawn options.
     *
     * @return The global [MobLevelProvider] function, or `null` if none is set.
     */
    fun getGlobalLevelProvider(): MobLevelProvider?

    /**
     * Sets or clears the global level provider.
     *
     * @param provider The level provider function to set, or `null` to clear the current provider.
     */
    fun setGlobalLevelProvider(provider: MobLevelProvider?)

    /**
     * Spawns a new instance of the given Mythic mob at the specified location.
     *
     * @param btcMob The mob type to spawn.
     * @param location The world location where the mob should be spawned.
     * @param options Optional spawn configuration overrides.
     * @return The newly created [ActiveMob] instance.
     */
    fun spawnMob(
        btcMob: BtcMob,
        location: Location,
        options: MobSpawnOptions = MobSpawnOptions(),
    ): ActiveMob

    /**
     * Despawns the active mob identified by the given UUID.
     *
     * @param uniqueId The UUID of the active mob to despawn.
     * @param reason The reason for the despawn, used for event dispatching and logging.
     * @return `true` if the mob was found and despawned, `false` if no active mob with the given UUID exists.
     */
    fun despawnMob(
        uniqueId: UUID,
        reason: DespawnReason = DespawnReason.PLUGIN,
    ): Boolean

    /**
     * Ticks all active mobs, updating their AI, threat tables, and other per-tick logic.
     *
     * This is called once per server tick by the plugin's tick scheduler.
     */
    fun tickActiveMobs()

    /**
     * Indicates whether the mob manager is currently in the process of spawning mobs.
     *
     * This can be used to prevent concurrent modification during iteration.
     *
     * @return `true` if a spawn operation is in progress, `false` otherwise.
     */
    fun isMythicMobSpawning(): Boolean

    /**
     * Checks whether an active mob with the given UUID exists.
     *
     * @param uniqueId The UUID to check.
     * @return `true` if an active mob with the given UUID exists, `false` otherwise.
     */
    fun isActiveMob(uniqueId: UUID): Boolean
}
