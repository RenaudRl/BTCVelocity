package com.borntocraft.btcmobs.api.core.skills.variables

import com.borntocraft.btcmobs.api.adapters.AbstractEntity
import java.time.Clock
import java.time.Duration
import java.time.Instant
import java.util.UUID

/**
 * Provides convenience helpers to interact with variables for a specific [VariableScope].
 */
class ScopedVariableAccess internal constructor(
    private val manager: VariableManager,
    val scope: VariableScope,
) {
    private val registry: VariableRegistry
        get() = manager.getRegistry(scope)

    fun has(name: String): Boolean = registry.has(name)

    fun get(name: String): VariableValue<*>? = registry.get(name)

    fun <T : Any> get(
        name: String,
        type: VariableType<T>,
    ): T? {
        val stored = registry.get(name) ?: return null
        if (!stored.typeId.equals(type.id, ignoreCase = true)) {
            return null
        }
        val value = stored.value
        return if (type.handledType.isInstance(value)) {
            @Suppress("UNCHECKED_CAST")
            value as T
        } else {
            null
        }
    }

    fun entries(): Map<String, VariableValue<*>> = registry.entries()

    fun keys(): Set<String> = registry.keys()

    fun <T : Any> set(
        name: String,
        type: VariableType<T>,
        value: T,
        expiresAt: Instant? = null,
    ) {
        registry.set(name, type.createValue(value, expiresAt))
    }

    fun <T : Any> set(
        name: String,
        type: VariableType<T>,
        value: T,
        ttl: Duration,
        clock: Clock = Clock.systemUTC(),
    ) {
        require(!ttl.isNegative) { "TTL must not be negative" }
        val expiresAt = clock.instant().plus(ttl)
        registry.set(name, type.createValue(value, expiresAt))
    }

    fun remove(name: String): Boolean = registry.remove(name)
}

fun VariableManager.scoped(scope: VariableScope): ScopedVariableAccess = ScopedVariableAccess(this, scope)

fun VariableManager.globalVariables(): ScopedVariableAccess = scoped(VariableScope.Global)

fun VariableManager.worldVariables(worldName: String): ScopedVariableAccess = scoped(VariableScope.World(worldName))

fun VariableManager.entityVariables(uniqueId: UUID): ScopedVariableAccess = scoped(VariableScope.Entity(uniqueId))

fun VariableManager.entityVariables(entity: AbstractEntity): ScopedVariableAccess = scoped(VariableScope.fromEntity(entity))
