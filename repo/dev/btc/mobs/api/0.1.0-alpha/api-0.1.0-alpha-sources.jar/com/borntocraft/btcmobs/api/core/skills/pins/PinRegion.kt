package com.borntocraft.btcmobs.api.core.skills.pins

/**
 * Represents a region associated with a pin.
 */
interface PinRegion
