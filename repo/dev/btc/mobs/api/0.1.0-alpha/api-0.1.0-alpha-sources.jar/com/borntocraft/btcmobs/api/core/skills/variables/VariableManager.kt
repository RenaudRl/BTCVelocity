package com.borntocraft.btcmobs.api.core.skills.variables

/**
 * Placeholder representation of the MythicMobs variable subsystem.
 *
 * Provides methods to manage variable registries scoped to different
 * [VariableScope]s, register custom [VariableType]s, and set global or
 * entity-specific variable values.
 */
interface VariableManager {
    /**
     * Returns the [VariableRegistry] for the given scope.
     *
     * @param scope the [VariableScope] whose registry should be retrieved.
     * @return the [VariableRegistry] for the scope, or an empty registry if none exists.
     */
    fun getRegistry(scope: VariableScope): VariableRegistry = VariableRegistry.empty()

    /**
     * Registers a custom variable type.
     *
     * @param type the [VariableType] to register.
     */
    fun registerType(type: VariableType<*>) {}

    /**
     * Unregisters a variable type by its identifier.
     *
     * @param typeId the identifier of the type to unregister.
     */
    fun unregisterType(typeId: String) {}

    /**
     * Persists any pending variable changes to storage.
     */
    fun saveChanges() {}

    /**
     * Flushes all variables in the given scope, clearing them from memory.
     *
     * @param scope the [VariableScope] to flush.
     */
    fun flush(scope: VariableScope) {}

    /**
     * Sets a global variable to the specified value.
     *
     * @param name the name of the global variable.
     * @param value the value to assign.
     */
    fun setGlobalVariable(
        name: String,
        value: String,
    ) {}

    /**
     * Sets an entity-scoped variable to the specified value.
     *
     * @param uniqueId the UUID of the entity.
     * @param name the name of the variable.
     * @param value the value to assign.
     */
    fun setEntityVariable(
        uniqueId: java.util.UUID,
        name: String,
        value: String,
    ) {}
}
