package com.borntocraft.btcmobs.api.skills

import org.bukkit.entity.LivingEntity
import com.borntocraft.btcmobs.api.core.skills.SkillTarget

/**
 * Encapsulates runtime data for skill execution.
 *
 * This interface provides access to all contextual information available when a
 * [Skill] is being executed, including the caster, trigger, targets, and any
 * variables or extra data attached to the execution context.
 */
interface SkillMetadata {
    /** The entity that cast or activated the skill. */
    val caster: LivingEntity

    /** The trigger that caused this skill execution, if any. */
    val trigger: SkillTrigger?

    /** The list of targets affected by this skill execution. */
    val targets: List<SkillTarget>

    /** Variables available during skill execution, keyed by variable name. */
    val variables: Map<String, Any?>

    /**
     * Mutable map of extra data that can be populated during skill execution
     * to share state between sequential skill actions.
     */
    val extras: MutableMap<String, Any?>
}
