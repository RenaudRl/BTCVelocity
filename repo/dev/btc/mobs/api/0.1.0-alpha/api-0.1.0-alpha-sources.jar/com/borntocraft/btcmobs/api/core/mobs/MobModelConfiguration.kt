package com.borntocraft.btcmobs.api.core.mobs

/**
 * Describes a visual model attachment to apply when spawning a mob.
 */
data class MobModelConfiguration(
    val provider: Provider,
    val modelId: String,
    val animations: List<String> = emptyList(),
    val trackerStates: Map<String, Boolean> = emptyMap(),
    val scale: Double? = null,
    val tint: Int? = null,
    val enchanted: Boolean = false,
    val boneVisibility: Map<String, Boolean> = emptyMap(),
    val bodyRotation: Map<String, String> = emptyMap(),
    val defaultAnimation: String? = null,
    val idleAnimation: String? = null,
    val walkAnimation: String? = null,
) {
    enum class Provider {
        MODEL_ENGINE,
        BETTER_MODEL,
    }
}
