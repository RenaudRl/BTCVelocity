package com.borntocraft.btcmobs.api.core.ai

import org.bukkit.Location
import org.bukkit.util.Vector
import kotlin.math.cos
import kotlin.math.sin

/**
 * Defines the shape and offset logic for squad formations.
 */
enum class FormationType {
    WEDGE {
        override fun calculateOffset(
            index: Int,
            total: Int,
            spacing: Double,
        ): Vector {
            if (index == 0) return Vector(0, 0, 0)
            val row = (index + 1) / 2
            val side = if (index % 2 == 1) -1 else 1 // Left or Right
            return Vector(side * row * spacing, 0.0, row * spacing)
        }
    },
    CIRCLE {
        override fun calculateOffset(
            index: Int,
            total: Int,
            spacing: Double,
        ): Vector {
            if (total <= 1) return Vector(0, 0, 0)
            val angle = 2 * Math.PI * index / total
            val radius = (total * spacing) / (2 * Math.PI) // Approximate circumference
            return Vector(cos(angle) * radius, 0.0, sin(angle) * radius)
        }
    },
    LINE {
        override fun calculateOffset(
            index: Int,
            total: Int,
            spacing: Double,
        ): Vector {
            // Centered line
            val start = -((total - 1) * spacing) / 2
            return Vector(start + (index * spacing), 0.0, 0.0)
        }
    },
    SCATTER {
        override fun calculateOffset(
            index: Int,
            total: Int,
            spacing: Double,
        ): Vector {
            // Pseudo-random scatter based on index to be deterministic
            val angle = index * 137.5 // Golden angle
            val radius = spacing * Math.sqrt(index.toDouble())
            return Vector(cos(angle) * radius, 0.0, sin(angle) * radius)
        }
    },
    BOX {
        override fun calculateOffset(
            index: Int,
            total: Int,
            spacing: Double,
        ): Vector {
            val sideLength = Math.ceil(Math.sqrt(total.toDouble())).toInt()
            val x = index % sideLength
            val z = index / sideLength
            val offset = (sideLength - 1) * spacing / 2
            return Vector((x * spacing) - offset, 0.0, (z * spacing) - offset)
        }
    },
    COLUMN {
        override fun calculateOffset(
            index: Int,
            total: Int,
            spacing: Double,
        ): Vector {
            return Vector(0.0, 0.0, index * spacing)
        }
    }, ;

    /**
     * Calculates the offset from the leader for a member at [index].
     * @param index The 0-based index of the squad member (0 is usually the leader/center).
     * @param total The total number of members in the formation.
     * @param spacing The distance between members.
     */
    abstract fun calculateOffset(
        index: Int,
        total: Int,
        spacing: Double,
    ): Vector

    /**
     * Applies the offset to a [leaderLocation] considering its rotation.
     */
    fun getTargetLocation(
        leaderLocation: Location,
        index: Int,
        total: Int,
        spacing: Double,
    ): Location {
        val offset = calculateOffset(index, total, spacing)
        // Rotate offset by leader's yaw
        val yawRadians = Math.toRadians(leaderLocation.yaw.toDouble())
        val cosYaw = cos(yawRadians)
        val sinYaw = sin(yawRadians)

        val rotatedX = offset.x * cosYaw - offset.z * sinYaw
        val rotatedZ = offset.x * sinYaw + offset.z * cosYaw

        return leaderLocation.clone().add(rotatedX, offset.y, rotatedZ)
    }
}
