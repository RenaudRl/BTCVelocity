package com.borntocraft.btcmobs.api.skills.auras

import com.borntocraft.btcmobs.api.adapters.AbstractEntity
import com.borntocraft.btcmobs.api.core.skills.auras.AuraRegistry
import java.util.UUID

/**
 * Entry point to query and manage entity auras.
 *
 * Provides methods to retrieve [AuraRegistry] instances for entities,
 * check for active auras, query stack counts, and remove aura stacks.
 */
interface AuraManager {
    /**
     * Returns the [AuraRegistry] for the given entity.
     *
     * @param entity the entity whose aura registry should be retrieved.
     * @return the [AuraRegistry] associated with the entity.
     */
    fun getAuraRegistry(entity: AbstractEntity): AuraRegistry

    /**
     * Returns the [AuraRegistry] for the entity with the given unique id.
     *
     * @param uniqueId the UUID of the entity.
     * @return the [AuraRegistry] associated with the entity.
     */
    fun getAuraRegistry(uniqueId: UUID): AuraRegistry

    /**
     * Checks whether the given entity has a specific aura active.
     *
     * @param entity the entity to check.
     * @param auraName the name of the aura to look for.
     * @return `true` if the entity has the specified aura, `false` otherwise.
     */
    fun getHasAura(
        entity: AbstractEntity,
        auraName: String,
    ): Boolean

    /**
     * Returns the number of stacks of a specific aura on the given entity.
     *
     * @param entity the entity to query.
     * @param auraName the name of the aura.
     * @return the number of aura stacks, or `0` if the aura is not active.
     */
    fun getAuraStacks(
        entity: AbstractEntity,
        auraName: String,
    ): Int

    /**
     * Removes a number of stacks of a specific aura from the given entity.
     *
     * @param entity the entity to modify.
     * @param auraName the name of the aura.
     * @param amount the number of stacks to remove.
     */
    fun removeAuraStacks(
        entity: AbstractEntity,
        auraName: String,
        amount: Int,
    )
}
