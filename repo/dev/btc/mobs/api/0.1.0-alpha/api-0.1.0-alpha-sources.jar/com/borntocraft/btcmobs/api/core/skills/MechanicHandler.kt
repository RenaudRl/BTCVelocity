package com.borntocraft.btcmobs.api.core.skills

interface MechanicHandler {
    fun execute(
        context: SkillExecutionContext,
        params: Map<String, String>,
    ): Boolean

    val isAsync: Boolean get() = false
}
