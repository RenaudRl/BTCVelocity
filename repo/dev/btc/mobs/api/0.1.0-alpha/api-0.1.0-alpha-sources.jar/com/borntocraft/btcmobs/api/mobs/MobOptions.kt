package com.borntocraft.btcmobs.api.mobs

/**
 * Configuration options for a [BtcMob].
 *
 * This interface exposes the various behavioural and visual settings that can be
 * configured for a Mythic mob type. All properties are optional and may be `null`
 * when the default behaviour is desired.
 */
interface MobOptions {
    /** Whether the mob's name tag should always be visible. */
    val alwaysShowName: Boolean?

    /** The attack speed modifier for the mob. */
    val attackSpeed: Double?

    /** Whether the mob should be invisible. */
    val invisible: Boolean?

    /** Whether the mob should have collision enabled. */
    val collidable: Boolean?

    /** Whether the mob should have the glowing effect. */
    val glowing: Boolean?

    /** Whether the mob is invincible (cannot take damage). */
    val invincible: Boolean?

    /** Whether the mob should produce no sounds. */
    val silent: Boolean?

    /** Whether the mob should be unaffected by gravity. */
    val noGravity: Boolean?

    /** Whether the mob should have no AI (no movement or behaviour). */
    val noAi: Boolean?

    /** Whether the mob's health bar should be displayed. */
    val showHealth: Boolean?

    /** Whether the mob should be prevented from picking up items. */
    val preventItemPickup: Boolean?

    /** The knockback resistance value (0.0 = no resistance, 1.0 = full resistance). */
    val knockbackResistance: Double?

    /** The follow range for the mob's AI targeting. */
    val followRange: Double?

    /** Whether the mob is visible by default (before any visibility conditions are applied). */
    val visibleByDefault: Boolean?

    /** The despawn behaviour, which can be a [Boolean] or a [DespawnMode] value. */
    val despawn: Any?

    /** Whether the mob can be interacted with (e.g., right-clicked). */
    val interactable: Boolean?

    /** Whether the mob can be leashed. */
    val preventLeashing: Boolean?

    /** Whether the mob should drop items when killed by another mob. */
    val preventMobKillDrops: Boolean?

    /** Whether the mob should drop any items other than configured drops. */
    val preventOtherDrops: Boolean?

    /** Whether the mob should receive random equipment on spawn. */
    val preventRandomEquipment: Boolean?

    /** Whether the mob can be renamed with a name tag. */
    val preventRenaming: Boolean?

    /** Whether the mob should be immune to sunburn (for undead mobs). */
    val preventSunburn: Boolean?

    /** Pacification settings as a map of key-value pairs, or `null` if not configured. */
    val pacify: Map<String, Any>?
}
