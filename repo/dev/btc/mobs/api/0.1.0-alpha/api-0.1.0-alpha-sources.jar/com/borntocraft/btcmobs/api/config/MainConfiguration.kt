package com.borntocraft.btcmobs.api.config

import java.util.logging.Level

/**
 * Represents the strongly-typed configuration exposed by `config.yml`.
 */
data class MainConfiguration(
    val general: General = General(),
    val components: Components = Components(),
    val randomSpawns: RandomSpawns = RandomSpawns(),
    val compatibility: Compatibility = Compatibility(),
    val packs: Packs = Packs(),
    val mobs: Mobs = Mobs(),
    val items: Items = Items(),
    val skills: Skills = Skills(),
    val spawning: Spawning = Spawning(),
) {
    data class General(
        val language: String = "en_us",
        val debug: Debug = Debug(),
        val examples: Examples = Examples(),
    ) {
        data class Debug(
            val level: Level = Level.INFO,
            val logStacktraces: Boolean = true,
        )

        data class Examples(
            val installOnFirstRun: Boolean = true,
            val includeAdvancedPack: Boolean = true,
        )
    }

    data class Components(
        val customSpawners: Toggle = Toggle(true),
        val randomSpawns: Toggle = Toggle(true),
        val holograms: Toggle = Toggle(true),
    ) {
        data class Toggle(val enabled: Boolean = true)
    }

    data class RandomSpawns(
        val scheduler: Scheduler = Scheduler(),
        val scoreboardTagPrefix: String = "btc_random_spawn",
    ) {
        data class Scheduler(
            val enabled: Boolean = true,
            val intervalTicks: Long = 40L,
            val maxSpawnsPerTick: Int = 48,
        )
    }

    data class Compatibility(
        val modelEngine: Boolean = true,
        val betterModel: Boolean = true,
        val packetEvents: Boolean = true,
        val vault: Boolean = true,
    )

    data class Packs(
        val installExamples: Boolean = true,
        val autoReload: Boolean = true,
    )

    data class Mobs(
        val cancelDamageIfZero: Boolean = false,
        val killMessagePrefix: String = "",
        val defaultOptions: DefaultOptions = DefaultOptions(),
        val drops: Drops = Drops(),
        val eggs: Eggs = Eggs(),
        val holograms: Holograms = Holograms(),
        val leveling: Leveling = Leveling(),
    ) {
        data class DefaultOptions(
            val despawn: Boolean = true,
            val preventOtherDrops: Boolean = false,
            val preventVanillaDamage: Boolean = false,
        )

        data class Drops(
            val defaultMethod: String = "VANILLA",
            val lootsplosion: Boolean = false,
        )

        data class Eggs(
            val material: String = "PIG_SPAWN_EGG",
            val model: Int = 0,
        )

        data class Holograms(
            val globalOffset: Double = 0.15,
        )

        data class Leveling(
            val worldScaling: Map<String, Any> = emptyMap(),
        )
    }

    data class Items(
        val itemUpdating: ItemUpdating = ItemUpdating(),
        val defaultOptions: DefaultOptions = DefaultOptions(),
    ) {
        data class ItemUpdating(
            val enabled: Boolean = false,
        )

        data class DefaultOptions(
            val material: String = "STONE",
            val preventEnchanting: Boolean = false,
        )
    }

    data class Skills(
        val targeters: Targeters = Targeters(),
        val timers: Timers = Timers(),
        val variables: Variables = Variables(),
    ) {
        data class Targeters(
            val defaultEntityFilters: Map<String, Boolean> = emptyMap(),
        )

        data class Timers(
            val defaultInterval: Int = 20,
        )

        data class Variables(
            val saveInterval: Int = 6000,
        )
    }

    data class Spawning(
        val randomSpawning: RandomSpawning = RandomSpawning(),
        val spawners: Spawners = Spawners(),
        val scheduler: Scheduler = Scheduler(),
    ) {
        data class RandomSpawning(
            val disableVanillaSpawns: Boolean = false,
        )

        data class Spawners(
            val defaultRadius: Int = 16,
        )

        data class Scheduler(
            val enabled: Boolean = true,
            val intervalTicks: Int = 40,
            val maxSpawnsPerTick: Int = 48,
        )
    }
}
