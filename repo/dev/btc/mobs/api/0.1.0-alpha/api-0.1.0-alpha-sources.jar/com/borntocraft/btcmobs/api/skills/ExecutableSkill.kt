package com.borntocraft.btcmobs.api.skills

/**
 * Marks a [Skill] that can be executed through the BornToCraft runtime.
 */
interface ExecutableSkill : Skill {
    /**
     * Executes the skill and returns the resulting outcome.
     */
    fun execute(
        metadata: SkillMetadata,
        trigger: SkillTrigger? = null,
    ): SkillExecutionResult

    /**
     * Indicates whether the skill can safely run off the server thread.
     */
    val isAsynchronous: Boolean get() = false
}
