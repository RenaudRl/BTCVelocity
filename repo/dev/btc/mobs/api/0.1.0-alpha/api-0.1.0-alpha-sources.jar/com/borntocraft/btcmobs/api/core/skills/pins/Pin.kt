package com.borntocraft.btcmobs.api.core.skills.pins

/**
 * Represents a Mythic pin definition.
 */
interface Pin
