package com.borntocraft.btcmobs.api.skills.stats

import com.borntocraft.btcmobs.api.adapters.AbstractEntity
import com.borntocraft.btcmobs.api.core.skills.stats.StatType
import java.util.Collection
import java.util.Locale
import java.util.Optional
import kotlin.jvm.JvmStatic

/**
 * Provides access to Mythic stat definitions and snapshots.
 *
 * Allows querying [StatType] definitions by name, retrieving per-entity
 * [StatSnapshot] registries, and translating legacy stat key aliases.
 */
interface StatManager {
    /**
     * Retrieves a stat type by its name.
     *
     * @param name the name of the stat to look up.
     * @return an [Optional] containing the [StatType] if found, or empty otherwise.
     */
    fun getStat(name: String): Optional<StatType>

    /**
     * Returns the stat registry (snapshot) for the given entity.
     *
     * @param entity the entity whose stat snapshot should be retrieved.
     * @return an [Optional] containing the [StatSnapshot], or empty if the entity has no stats.
     */
    fun getStatRegistry(entity: AbstractEntity): Optional<out StatSnapshot>

    /**
     * Returns all stat types that have a non-zero base value.
     *
     * @return a collection of [StatType] instances with non-zero defaults.
     */
    fun getNonZeroBaseStats(): Collection<StatType>

    companion object {
        /**
         * Translates a legacy stat key to its modern uppercase equivalent.
         *
         * @param key the legacy stat key to translate, may be `null`.
         * @return the uppercase version of the key, or `null` if the input was `null`.
         */
        @JvmStatic
        fun translateLegacyStatAliases(key: String?): String? = key?.uppercase(Locale.ROOT)
    }
}
