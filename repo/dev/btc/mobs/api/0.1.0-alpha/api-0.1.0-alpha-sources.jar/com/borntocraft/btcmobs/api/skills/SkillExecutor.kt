package com.borntocraft.btcmobs.api.skills

import kotlinx.coroutines.Deferred

/**
 * Coordinator able to execute compiled skills synchronously or asynchronously.
 *
 * Implementations must delegate to the [SkillManager] contract for lookups while
 * providing higher-level execution helpers and contextual result types.
 */
interface SkillExecutor : SkillManager {
    /**
     * Executes the provided [skill] with the supplied [metadata] and optional [trigger].
     *
     * Implementations must honour any synchronous execution requirements exposed by the
     * skill implementation and ensure thread-safety when dispatching mechanics.
     */
    override fun execute(
        skill: Skill,
        metadata: SkillMetadata,
        trigger: SkillTrigger?,
    ): SkillExecutionResult

    /**
     * Resolves and executes the skill registered under [skillName].
     */
    override fun execute(
        skillName: String,
        metadata: SkillMetadata,
        trigger: SkillTrigger?,
    ): SkillExecutionResult

    /**
     * Asynchronously executes the provided [skill].
     */
    fun executeAsync(
        skill: Skill,
        metadata: SkillMetadata,
        trigger: SkillTrigger? = null,
    ): Deferred<SkillExecutionResult>

    /**
     * Asynchronously resolves and executes the skill registered under [skillName].
     */
    fun executeAsync(
        skillName: String,
        metadata: SkillMetadata,
        trigger: SkillTrigger? = null,
    ): Deferred<SkillExecutionResult>
}

/**
 * Outcome of a skill execution attempt.
 */
sealed interface SkillExecutionResult {
    val skill: Skill?
    val skillName: String
    val metadata: SkillMetadata
    val trigger: SkillTrigger?

    data class Success(
        override val skillName: String,
        override val metadata: SkillMetadata,
        override val trigger: SkillTrigger?,
        override val skill: Skill? = null,
    ) : SkillExecutionResult

    data class Failure(
        override val skillName: String,
        override val metadata: SkillMetadata,
        override val trigger: SkillTrigger?,
        val reason: String,
        override val skill: Skill? = null,
    ) : SkillExecutionResult

    data class Error(
        override val skillName: String,
        override val metadata: SkillMetadata,
        override val trigger: SkillTrigger?,
        val exception: Throwable,
        override val skill: Skill? = null,
    ) : SkillExecutionResult

    data class Delay(
        override val skillName: String,
        override val metadata: SkillMetadata,
        override val trigger: SkillTrigger?,
        val ticks: Long,
        override val skill: Skill? = null,
    ) : SkillExecutionResult
}
