package com.borntocraft.btcmobs.api.core.skills.variables

import com.borntocraft.btcmobs.api.adapters.AbstractEntity
import java.util.UUID

/**
 * Represents the scope of a stored Mythic variable.
 */
sealed class VariableScope {
    data object Global : VariableScope()

    data class World(val worldName: String) : VariableScope() {
        init {
            require(worldName.isNotBlank()) { "World name cannot be blank" }
        }
    }

    data class Entity(val uniqueId: UUID) : VariableScope()

    companion object
}

fun VariableScope.Companion.fromEntity(entity: AbstractEntity): VariableScope = VariableScope.Entity(entity.uniqueId)
