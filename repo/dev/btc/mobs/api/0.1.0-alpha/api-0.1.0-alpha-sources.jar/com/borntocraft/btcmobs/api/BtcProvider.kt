package com.borntocraft.btcmobs.api

import com.borntocraft.btcmobs.api.BtcMobsRegistry

/**
 * Provides access to the BornToCraft mobs registry once the plugin has been initialised.
 */
object BtcProvider {
    @Volatile
    private var registry: BtcMobsRegistry? = null

    /**
     * Returns the active [BtcMobsRegistry] instance.
     *
     * @throws IllegalStateException if the provider has not been initialised yet.
     */
    @JvmStatic
    fun get(): BtcMobsRegistry = registry ?: throw IllegalStateException("The BornToCraft mobs framework is not ready yet.")

    /**
     * Registers the [BtcMobsRegistry] instance that should be exposed through this provider.
     *
     * Attempting to register a different instance after the provider has been initialised will fail to
     * avoid accidental reconfiguration from external plugins.
     */
    @JvmStatic
    fun register(registry: BtcMobsRegistry) {
        synchronized(this) {
            val current = this.registry
            if (current != null && current !== registry) {
                throw IllegalStateException("BtcProvider has already been initialised.")
            }
            this.registry = registry
        }
    }
}
