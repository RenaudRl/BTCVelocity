package com.borntocraft.btcmobs.api.core.skills

/**
 * Represents a Mythic skill condition.
 */
interface SkillCondition
