package com.borntocraft.btcmobs.api.core.skills

/**
 * Contract for an executable Mythic mechanic.
 */
interface SkillMechanic {
    val name: String
    val parameters: Map<String, String>
}
