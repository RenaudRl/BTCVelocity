package com.borntocraft.btcmobs.api

/**
 * Main entry point for the BTCMobs public API.
 *
 * This interface provides access to all BTCMobs subsystems and services.
 * External plugins can obtain an instance of this API through Bukkit's
 * ServicesManager or by accessing the plugin directly.
 *
 * Example usage:
 * ```kotlin
 * val api = server.servicesManager.getRegistration(BTCMobsApi::class.java)?.provider
 *     ?: throw IllegalStateException("BTCMobs not found")
 *
 * // Access mob information
 * val mobs = api.mobManager.getActiveMobs()
 *
 * // Access damage tracking
 * val damage = api.damageTracker.getTrackedDamage(entity)
 * ```
 */
interface BTCMobsApi {
    /**
     * Access the mob registry for registering and querying mob types.
     */
    val registry: BtcMobsRegistry

    /**
     * Access the mob manager for querying active mobs.
     */
    val mobManager: MobManager

    /**
     * Access the damage tracking API.
     */
    val damageTracker: DamageTrackerApi

    /**
     * Access the AI goal registry for querying available goals and targets.
     */
    val aiGoalRegistry: AiGoalRegistry

    /**
     * Get the current API version.
     */
    val apiVersion: String
}
