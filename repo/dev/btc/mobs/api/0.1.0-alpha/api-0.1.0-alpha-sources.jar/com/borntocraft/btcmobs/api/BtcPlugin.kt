package com.borntocraft.btcmobs.api

import com.borntocraft.btcmobs.api.adapters.ServerInterface
import com.borntocraft.btcmobs.api.config.ConfigManager
import com.borntocraft.btcmobs.api.core.skills.variables.VariableManager
import com.borntocraft.btcmobs.api.drops.DropManager
import com.borntocraft.btcmobs.api.items.ItemManager
import com.borntocraft.btcmobs.api.mobs.MobManager
import com.borntocraft.btcmobs.api.packs.PackManager
import com.borntocraft.btcmobs.api.skills.SkillManager
import com.borntocraft.btcmobs.api.skills.pins.PinManager
import com.borntocraft.btcmobs.api.skills.placeholders.PlaceholderManager
import com.borntocraft.btcmobs.api.skills.stats.StatManager
import com.borntocraft.btcmobs.api.volatilecode.VolatileCodeHandler

/**
 * Abstraction of the MythicMobs plugin services exposed to BornToCraft integrations.
 */
interface BtcPlugin {
    val bootstrap: ServerInterface

    val configuration: ConfigManager

    val packManager: PackManager

    val pinManager: PinManager

    val mobManager: MobManager

    val skillManager: SkillManager

    val itemManager: ItemManager

    val dropManager: DropManager

    val statManager: StatManager

    val variableManager: VariableManager

    val placeholderManager: PlaceholderManager

    val volatileCodeHandler: VolatileCodeHandler

    val isShuttingDown: Boolean
}
