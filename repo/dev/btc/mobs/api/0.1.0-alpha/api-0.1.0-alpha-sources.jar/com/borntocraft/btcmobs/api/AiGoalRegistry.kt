package com.borntocraft.btcmobs.api

/**
 * API interface for accessing AI goal information.
 */
interface AiGoalInfo {
    /** Unique identifier for this goal type */
    val name: String

    /** Human-readable description of this goal */
    val description: String

    /** List of aliases for this goal */
    val aliases: List<String>

    /** Required mob type (if any) */
    val requiredMobType: String?
}

/**
 * API interface for accessing AI target selector information.
 */
interface AiTargetInfo {
    /** Unique identifier for this target selector */
    val name: String

    /** Human-readable description */
    val description: String

    /** List of aliases */
    val aliases: List<String>
}

/**
 * Registry for accessing available AI goals and targets.
 */
interface AiGoalRegistry {
    /** Get all registered AI goal types */
    fun getAvailableGoals(): Set<String>

    /** Get all registered AI target selector types */
    fun getAvailableTargets(): Set<String>

    /** Check if a goal type is supported */
    fun isGoalSupported(name: String): Boolean

    /** Check if a target selector type is supported */
    fun isTargetSupported(name: String): Boolean
}
