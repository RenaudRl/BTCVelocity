package com.borntocraft.btcmobs.api.skills

import com.borntocraft.btcmobs.api.adapters.AbstractEntity
import com.borntocraft.btcmobs.api.adapters.AbstractLocation
import com.borntocraft.btcmobs.api.core.skills.TriggeredSkill
import com.borntocraft.btcmobs.api.core.skills.triggers.SkillTriggerMetadata
import com.borntocraft.btcmobs.api.skills.stats.StatSnapshot

/**
 * Dispatches skill-related events mirroring the MythicMobs API.
 *
 * The event bus is responsible for processing skill triggers, building execution metadata,
 * resolving trigger mechanics, and applying stat modifications before and after skill execution.
 * It serves as the central coordination point between the skill system and the event pipeline.
 */
interface SkillEventBus {
    /**
     * Processes a skill trigger for the given caster and target entity.
     *
     * @param trigger The trigger type that initiated the skill.
     * @param caster The entity casting the skill.
     * @param target The entity targeted by the skill.
     * @return A [TriggeredSkill] representing the result of processing the trigger.
     */
    fun processTrigger(
        trigger: SkillTrigger,
        caster: SkillCaster,
        target: AbstractEntity,
    ): TriggeredSkill

    /**
     * Processes a skill trigger with the option to bypass condition checks.
     *
     * @param trigger The trigger type that initiated the skill.
     * @param caster The entity casting the skill.
     * @param target The entity targeted by the skill.
     * @param bypassConditions If `true`, condition checks are skipped during processing.
     * @return A [TriggeredSkill] representing the result of processing the trigger.
     */
    fun processTrigger(
        trigger: SkillTrigger,
        caster: SkillCaster,
        target: AbstractEntity,
        bypassConditions: Boolean,
    ): TriggeredSkill

    /**
     * Processes a skill trigger with explicit trigger metadata and condition bypass control.
     *
     * @param trigger The trigger type that initiated the skill.
     * @param metadata Additional metadata associated with the trigger invocation.
     * @param caster The entity casting the skill.
     * @param target The entity targeted by the skill.
     * @param bypassConditions If `true`, condition checks are skipped during processing.
     * @return A [TriggeredSkill] representing the result of processing the trigger.
     */
    fun processTrigger(
        trigger: SkillTrigger,
        metadata: SkillTriggerMetadata,
        caster: SkillCaster,
        target: AbstractEntity,
        bypassConditions: Boolean,
    ): TriggeredSkill

    /**
     * Processes a skill trigger with full context including a target location.
     *
     * @param trigger The trigger type that initiated the skill.
     * @param metadata Additional metadata associated with the trigger invocation.
     * @param caster The entity casting the skill.
     * @param target The entity targeted by the skill.
     * @param location The location targeted by the skill.
     * @param bypassConditions If `true`, condition checks are skipped during processing.
     * @return A [TriggeredSkill] representing the result of processing the trigger.
     */
    fun processTrigger(
        trigger: SkillTrigger,
        metadata: SkillTriggerMetadata,
        caster: SkillCaster,
        target: AbstractEntity,
        location: AbstractLocation,
        bypassConditions: Boolean,
    ): TriggeredSkill

    /**
     * Builds skill execution metadata from the given trigger, caster, and target context.
     *
     * @param trigger The trigger type that initiated the skill.
     * @param caster The entity casting the skill.
     * @param triggerTarget The entity targeted by the trigger, if any.
     * @param triggerLocation The location targeted by the trigger, if any.
     * @param bypassConditions If `true`, condition checks are skipped during metadata construction.
     * @return A [SkillMetadata] instance populated with the execution context.
     */
    fun buildSkillMetadata(
        trigger: SkillTrigger,
        caster: SkillCaster,
        triggerTarget: AbstractEntity?,
        triggerLocation: AbstractLocation?,
        bypassConditions: Boolean,
    ): SkillMetadata

    /**
     * Builds skill execution metadata with explicit trigger metadata.
     *
     * @param trigger The trigger type that initiated the skill.
     * @param metadata Additional metadata associated with the trigger invocation.
     * @param caster The entity casting the skill.
     * @param triggerTarget The entity targeted by the trigger, if any.
     * @param triggerLocation The location targeted by the trigger, if any.
     * @param bypassConditions If `true`, condition checks are skipped during metadata construction.
     * @return A [SkillMetadata] instance populated with the execution context.
     */
    fun buildSkillMetadata(
        trigger: SkillTrigger,
        metadata: SkillTriggerMetadata,
        caster: SkillCaster,
        triggerTarget: AbstractEntity?,
        triggerLocation: AbstractLocation?,
        bypassConditions: Boolean,
    ): SkillMetadata

    /**
     * Processes trigger mechanics using the provided skill metadata.
     *
     * @param metadata The runtime metadata for the execution context.
     * @return A [TriggeredSkill] representing the result of processing the mechanics.
     */
    fun processTriggerMechanics(metadata: SkillMetadata): TriggeredSkill

    /**
     * Processes trigger mechanics with explicit trigger metadata.
     *
     * @param metadata The runtime metadata for the execution context.
     * @param triggerMetadata Additional metadata associated with the trigger invocation.
     * @return A [TriggeredSkill] representing the result of processing the mechanics.
     */
    fun processTriggerMechanics(
        metadata: SkillMetadata,
        triggerMetadata: SkillTriggerMetadata,
    ): TriggeredSkill

    /**
     * Applies pre-execution stat modifications to the skill metadata.
     *
     * This is called before skill mechanics are executed and allows stat-based
     * modifications to the execution context.
     *
     * @param metadata The runtime metadata for the execution context.
     * @param triggerMetadata Additional metadata associated with the trigger invocation.
     * @param snapshot The current stat snapshot for the caster.
     */
    fun processStatsPre(
        metadata: SkillMetadata,
        triggerMetadata: SkillTriggerMetadata,
        snapshot: StatSnapshot,
    )

    /**
     * Applies post-execution stat modifications to the skill metadata.
     *
     * This is called after skill mechanics have been executed and allows stat-based
     * modifications to be applied as a result of the skill execution.
     *
     * @param metadata The runtime metadata for the execution context.
     * @param triggerMetadata Additional metadata associated with the trigger invocation.
     * @param snapshot The current stat snapshot for the caster.
     */
    fun processStatsPost(
        metadata: SkillMetadata,
        triggerMetadata: SkillTriggerMetadata,
        snapshot: StatSnapshot,
    )
}
