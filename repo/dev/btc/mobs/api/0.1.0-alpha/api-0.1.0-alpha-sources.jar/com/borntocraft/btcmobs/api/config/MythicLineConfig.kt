package com.borntocraft.btcmobs.api.config

/**
 * Represents a line-based configuration section.
 */
interface MythicLineConfig
