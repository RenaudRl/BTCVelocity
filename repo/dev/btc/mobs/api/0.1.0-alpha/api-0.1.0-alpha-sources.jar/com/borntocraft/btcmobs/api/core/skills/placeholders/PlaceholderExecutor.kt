package com.borntocraft.btcmobs.api.core.skills.placeholders

/**
 * Executes placeholder lookups.
 */
interface PlaceholderExecutor {
    interface PlaceholderEntry
}
