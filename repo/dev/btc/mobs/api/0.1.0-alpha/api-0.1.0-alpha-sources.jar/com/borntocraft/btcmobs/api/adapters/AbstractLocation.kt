package com.borntocraft.btcmobs.api.adapters

/**
 * Represents a location abstraction in MythicMobs.
 */
interface AbstractLocation {
    val x: Double
    val y: Double
    val z: Double
    val worldName: String?
    val yaw: Float
    val pitch: Float
}
