package com.borntocraft.btcmobs.api.skills

/**
 * Enumeration placeholder for skill trigger identifiers.
 *
 * A [SkillTrigger] represents the event or condition that causes a [Skill] to
 * execute. Examples include entity death, attack, spawn, or timer-based triggers.
 */
interface SkillTrigger
