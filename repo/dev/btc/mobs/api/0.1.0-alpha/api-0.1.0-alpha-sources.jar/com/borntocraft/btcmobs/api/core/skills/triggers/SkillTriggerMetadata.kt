package com.borntocraft.btcmobs.api.core.skills.triggers

/**
 * Metadata associated with trigger invocations.
 */
interface SkillTriggerMetadata
