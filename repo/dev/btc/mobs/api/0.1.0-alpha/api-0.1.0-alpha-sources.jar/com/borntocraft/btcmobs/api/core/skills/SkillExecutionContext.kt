package com.borntocraft.btcmobs.api.core.skills

import com.borntocraft.btcmobs.api.skills.SkillMetadata

interface SkillExecutionContext {
    val metadata: SkillMetadata
    val targets: List<SkillTarget>
    val mechanic: SkillMechanic
    val chance: Double?
    val priority: Int?
}
