package com.borntocraft.btcmobs.api.skills.pins

import com.borntocraft.btcmobs.api.core.skills.pins.Pin
import com.borntocraft.btcmobs.api.core.skills.pins.PinRegion
import java.util.Optional

/**
 * Registry of Mythic pins and regions.
 *
 * Provides lookup methods for [Pin] and [PinRegion] instances by name.
 */
interface PinManager {
    /**
     * Retrieves a pin by its unique name.
     *
     * @param name the name of the pin to look up.
     * @return an [Optional] containing the [Pin] if found, or empty otherwise.
     */
    fun getPin(name: String): Optional<Pin>

    /**
     * Retrieves a pin region by its unique name.
     *
     * @param name the name of the region to look up.
     * @return an [Optional] containing the [PinRegion] if found, or empty otherwise.
     */
    fun getRegion(name: String): Optional<PinRegion>
}
