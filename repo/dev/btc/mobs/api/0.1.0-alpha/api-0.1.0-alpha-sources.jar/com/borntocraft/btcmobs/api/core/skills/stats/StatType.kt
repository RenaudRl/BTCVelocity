package com.borntocraft.btcmobs.api.core.skills.stats

/**
 * Placeholder for stat type definitions.
 */
interface StatType
