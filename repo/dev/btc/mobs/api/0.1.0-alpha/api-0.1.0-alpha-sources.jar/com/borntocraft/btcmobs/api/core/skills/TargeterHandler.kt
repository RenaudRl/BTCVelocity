package com.borntocraft.btcmobs.api.core.skills

import com.borntocraft.btcmobs.api.skills.SkillMetadata

interface TargeterHandler {
    fun resolve(
        metadata: SkillMetadata,
        params: Map<String, String>,
    ): List<SkillTarget>
}
