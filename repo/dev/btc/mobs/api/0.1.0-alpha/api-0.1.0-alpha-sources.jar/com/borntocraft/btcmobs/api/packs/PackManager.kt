package com.borntocraft.btcmobs.api.packs

import java.nio.file.Path
import java.util.Collection

/**
 * Manages resource packs exposed by btcMobs.
 *
 * Provides access to the packs directory, enumeration of available packs,
 * lookup by identifier, and the ability to reload packs from disk.
 */
interface PackManager {
    /** The file-system directory containing all available resource packs. */
    val packsDirectory: Path

    /** Returns an immutable view of all currently loaded [Pack] instances. */
    fun availablePacks(): Collection<Pack>

    /**
     * Retrieves a pack by its unique identifier.
     *
     * @param id the identifier of the pack to look up.
     * @return the [Pack] if found, or `null` if no pack with the given id is loaded.
     */
    fun findPack(id: String): Pack?

    /**
     * Reloads all packs from disk.
     *
     * @return `true` when the reload operation succeeds, `false` otherwise.
     */
    fun reloadPacks(): Boolean
}
