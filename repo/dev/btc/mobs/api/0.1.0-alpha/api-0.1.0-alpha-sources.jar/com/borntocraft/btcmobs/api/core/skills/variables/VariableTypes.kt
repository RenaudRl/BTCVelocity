package com.borntocraft.btcmobs.api.core.skills.variables

import org.bukkit.inventory.ItemStack
import org.bukkit.util.Vector
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.Locale
import kotlin.reflect.KClass

/**
 * Collection of built-in variable type definitions matching Mythic defaults.
 */
object VariableTypes {
    private val base64Encoder = Base64.getEncoder()
    private val base64Decoder = Base64.getDecoder()

    @Suppress("UNCHECKED_CAST")
    private val listClass: KClass<List<String>> = List::class as KClass<List<String>>

    @Suppress("UNCHECKED_CAST")
    private val setClass: KClass<Set<String>> = Set::class as KClass<Set<String>>

    val StringType: VariableType<String> =
        SimpleVariableType(
            id = "string",
            handledType = String::class,
            encoder = { it },
            decoder = { it },
        )

    val BooleanType: VariableType<Boolean> =
        SimpleVariableType(
            id = "bool",
            handledType = Boolean::class,
            encoder = { it.toString() },
            decoder = { raw ->
                when (raw.lowercase(Locale.ROOT)) {
                    "true", "yes", "y", "1" -> true
                    "false", "no", "n", "0" -> false
                    else -> null
                }
            },
        )

    val DoubleType: VariableType<Double> =
        SimpleVariableType(
            id = "double",
            handledType = Double::class,
            encoder = { it.toString() },
            decoder = { raw -> raw.toDoubleOrNull() },
        )

    val LongType: VariableType<Long> =
        SimpleVariableType(
            id = "long",
            handledType = Long::class,
            encoder = { it.toString() },
            decoder = { raw -> raw.toLongOrNull() },
        )

    val VectorType: VariableType<Vector> =
        SimpleVariableType(
            id = "vector",
            handledType = Vector::class,
            encoder = { vector ->
                listOf(vector.x, vector.y, vector.z).joinToString(separator = VECTOR_DELIMITER) { it.toString() }
            },
            decoder = { raw ->
                val parts = raw.split(VECTOR_DELIMITER)
                if (parts.size != 3) {
                    return@SimpleVariableType null
                }
                val x = parts[0].toDoubleOrNull() ?: return@SimpleVariableType null
                val y = parts[1].toDoubleOrNull() ?: return@SimpleVariableType null
                val z = parts[2].toDoubleOrNull() ?: return@SimpleVariableType null
                Vector(x, y, z)
            },
        )

    val StringListType: VariableType<List<String>> =
        SimpleVariableType(
            id = "list",
            handledType = listClass,
            encoder = ::encodeStringCollection,
            decoder = { raw -> decodeStringCollection(raw)?.toList() },
        )

    val StringSetType: VariableType<Set<String>> =
        SimpleVariableType(
            id = "set",
            handledType = setClass,
            encoder = { values -> encodeStringCollection(values) },
            decoder = { raw -> decodeStringCollection(raw)?.toCollection(linkedSetOf()) },
        )

    val ItemStackType: VariableType<ItemStack> =
        SimpleVariableType(
            id = "item",
            handledType = ItemStack::class,
            encoder = ::encodeItemStack,
            decoder = ::decodeItemStack,
        )

    private fun encodeStringCollection(values: Collection<String>): String =
        values.joinToString(separator = COLLECTION_SEPARATOR) { value ->
            base64Encoder.encodeToString(value.toByteArray(StandardCharsets.UTF_8))
        }

    private fun decodeStringCollection(serialized: String): MutableList<String>? {
        if (serialized.isEmpty()) {
            return mutableListOf()
        }
        val tokens = serialized.split(COLLECTION_SEPARATOR)
        val result = ArrayList<String>(tokens.size)
        for (token in tokens) {
            val decoded = decodeBase64(token) ?: return null
            result += decoded
        }
        return result
    }

    private fun decodeBase64(token: String): String? =
        runCatching {
            val bytes = base64Decoder.decode(token)
            String(bytes, StandardCharsets.UTF_8)
        }.getOrNull()

    private fun encodeItemStack(stack: ItemStack): String {
        val clone = stack.clone()
        return try {
            val bytes = clone.serializeAsBytes()
            base64Encoder.encodeToString(bytes)
        } catch (ex: Exception) {
            throw IllegalStateException("Failed to serialise ItemStack", ex)
        }
    }

    private fun decodeItemStack(serialized: String): ItemStack? =
        runCatching {
            val bytes = base64Decoder.decode(serialized)
            ItemStack.deserializeBytes(bytes)
        }.getOrNull()

    private const val VECTOR_DELIMITER = ","
    private const val COLLECTION_SEPARATOR = ";"
}
