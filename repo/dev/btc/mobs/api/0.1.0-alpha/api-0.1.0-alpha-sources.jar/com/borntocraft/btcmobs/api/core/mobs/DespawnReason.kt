package com.borntocraft.btcmobs.api.core.mobs

/**
 * Reason used when removing an [ActiveMob] from the world.
 */
enum class DespawnReason {
    /** Removed programmatically by the plugin. */
    PLUGIN,

    /** The entity died or was killed. */
    DEATH,

    /** The entity naturally despawned due to game rules. */
    NATURAL,

    /** Chunk unload forced the mob to be removed. */
    CHUNK_UNLOAD,

    /** The entity was removed due to distance/despawn rules. */
    DISTANCE,

    /** Catch-all value for untracked external causes. */
    UNKNOWN,

    /** Legacy/Generic other reason. */
    OTHER,
}
