package com.borntocraft.btcmobs.api.drops

import com.borntocraft.btcmobs.api.core.drops.DropTable
import java.util.Collection
import java.util.Optional

/**
 * Access to configured Mythic drop tables.
 *
 * Provides methods to query and manage [DropTable] instances as well as
 * custom [ConditionEvaluator]s that control when drops are awarded.
 */
interface DropManager {
    /**
     * Retrieves a drop table by its unique name.
     *
     * @param name the name of the drop table to look up.
     * @return an [Optional] containing the [DropTable] if found, or empty otherwise.
     */
    fun getDropTable(name: String): Optional<DropTable>

    /**
     * Returns all currently configured drop tables.
     *
     * @return a collection of all registered [DropTable] instances.
     */
    fun getDropTables(): Collection<DropTable>

    /**
     * Registers a custom condition evaluator.
     *
     * @param evaluator the [ConditionEvaluator] to register for drop condition checks.
     */
    fun registerConditionEvaluator(evaluator: ConditionEvaluator)

    /**
     * Returns all registered condition evaluators.
     *
     * @return a collection of all registered [ConditionEvaluator] instances.
     */
    fun getConditionEvaluators(): Collection<ConditionEvaluator>
}
