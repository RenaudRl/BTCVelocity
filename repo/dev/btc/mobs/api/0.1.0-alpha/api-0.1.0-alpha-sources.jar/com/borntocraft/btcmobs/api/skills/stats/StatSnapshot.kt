package com.borntocraft.btcmobs.api.skills.stats

/**
 * Snapshot of statistics for a caster.
 */
interface StatSnapshot
