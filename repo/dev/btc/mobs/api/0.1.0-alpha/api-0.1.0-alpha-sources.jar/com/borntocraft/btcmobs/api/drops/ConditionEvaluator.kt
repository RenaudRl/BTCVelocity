package com.borntocraft.btcmobs.api.drops

import org.bukkit.entity.Player

/**
 * Interface for external systems to provide custom condition evaluation logic
 * for Mythic drop tables.
 */
interface ConditionEvaluator {
    /**
     * The unique namespace of this evaluator (e.g., "btc", "quest").
     */
    val namespace: String

    /**
     * Evaluates a custom condition for a player.
     *
     * @param player The player to check the condition for.
     * @param condition The condition string (without the namespace prefix).
     * @return True if the condition is met, false otherwise.
     */
    fun evaluate(
        player: Player,
        condition: String,
    ): Boolean
}
