package com.borntocraft.btcmobs.api.items

import org.bukkit.inventory.ItemStack
import com.borntocraft.btcmobs.api.adapters.AbstractItemStack

/**
 * Source of Mythic items tied to a namespace.
 */
interface ItemSupplier {
    val namespace: String

    fun getItem(
        name: String,
        player: org.bukkit.entity.Player? = null,
    ): ItemStack

    fun isSimilar(
        name: String,
        itemStack: ItemStack,
    ): Boolean

    fun getMythicItem(name: String): AbstractItemStack =
        throw UnsupportedOperationException("Mythic item adaptation is not available in the API layer.")

    fun getAvailableItemNames(): Collection<String>
}
