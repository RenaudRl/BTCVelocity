package com.borntocraft.btcmobs.api.core.skills.variables

import kotlin.reflect.KClass

/**
 * Describes how a variable value is serialised and deserialised.
 */
interface VariableType<T : Any> {
    val id: String

    val handledType: KClass<T>

    fun encode(value: T): String

    fun decode(serialized: String): T?
}
