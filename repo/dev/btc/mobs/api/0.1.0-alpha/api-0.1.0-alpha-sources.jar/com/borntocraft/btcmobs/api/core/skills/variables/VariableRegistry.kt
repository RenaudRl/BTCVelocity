package com.borntocraft.btcmobs.api.core.skills.variables

/**
 * Represents a collection of variables for a given scope.
 */
interface VariableRegistry {
    fun has(name: String): Boolean = get(name) != null

    fun get(name: String): VariableValue<*>?

    fun set(
        name: String,
        value: VariableValue<*>,
    )

    fun remove(name: String): Boolean

    fun keys(): Set<String>

    fun entries(): Map<String, VariableValue<*>>

    companion object {
        fun empty(): VariableRegistry = EmptyVariableRegistry
    }
}

private object EmptyVariableRegistry : VariableRegistry {
    override fun get(name: String): VariableValue<*>? = null

    override fun set(
        name: String,
        value: VariableValue<*>,
    ) = Unit

    override fun remove(name: String): Boolean = false

    override fun keys(): Set<String> = emptySet()

    override fun entries(): Map<String, VariableValue<*>> = emptyMap()
}
