package com.borntocraft.btcmobs.api.adapters

import org.bukkit.entity.LivingEntity
import java.util.UUID

/**
 * Lightweight representation of an entity in MythicMobs.
 */
interface AbstractEntity {
    val uniqueId: UUID
    val livingEntity: LivingEntity?
}
