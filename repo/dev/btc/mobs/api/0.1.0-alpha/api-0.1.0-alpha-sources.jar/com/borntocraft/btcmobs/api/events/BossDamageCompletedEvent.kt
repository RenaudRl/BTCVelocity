package com.borntocraft.btcmobs.api.events

import org.bukkit.event.Event
import org.bukkit.event.HandlerList
import java.util.UUID

/**
 * Fired when a tracked boss fight concludes and damage totals are available.
 */
public class BossDamageCompletedEvent(
    public val bossId: String,
    public val mobUuid: UUID,
    playerDamageMap: Map<UUID, Double>,
    public val maxHealth: Double,
    async: Boolean = false,
) : Event(async) {
    public val playerDamageMap: Map<UUID, Double> = playerDamageMap.toMap()

    override fun getHandlers(): HandlerList = handlerList

    public companion object {
        private val handlerList = HandlerList()

        @JvmStatic
        public fun getHandlerList(): HandlerList = handlerList
    }
}
