package com.borntocraft.btcmobs.api.core.skills.variables

import kotlin.reflect.KClass

/**
 * Helper implementation of [VariableType] for simple value conversions.
 */
class SimpleVariableType<T : Any>(
    override val id: String,
    override val handledType: KClass<T>,
    private val encoder: (T) -> String,
    private val decoder: (String) -> T?,
) : VariableType<T> {
    override fun encode(value: T): String = encoder(value)

    override fun decode(serialized: String): T? = decoder(serialized)
}
