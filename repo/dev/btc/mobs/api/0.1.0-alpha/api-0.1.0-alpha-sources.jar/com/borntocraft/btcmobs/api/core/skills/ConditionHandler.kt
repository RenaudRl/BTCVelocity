package com.borntocraft.btcmobs.api.core.skills

interface ConditionHandler {
    fun matches(
        context: SkillExecutionContext,
        params: Map<String, String>,
    ): Boolean
}
