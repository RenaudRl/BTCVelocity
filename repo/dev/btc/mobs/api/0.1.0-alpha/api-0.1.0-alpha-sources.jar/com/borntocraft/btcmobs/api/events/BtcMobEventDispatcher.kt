package com.borntocraft.btcmobs.api.events

/**
 * Abstraction capable of dispatching BornToCraft mob events.
 *
 * Implementations are expected to bridge to Bukkit's event bus or custom pipelines
 * while returning the same instance for fluent post-processing.
 */
public interface BtcMobEventDispatcher {
    public fun fire(event: BtcMobSpawnEvent): BtcMobSpawnEvent

    public fun fire(event: BtcMobDamageEvent): BtcMobDamageEvent

    public fun fire(event: BtcMobDeathEvent): BtcMobDeathEvent
}
