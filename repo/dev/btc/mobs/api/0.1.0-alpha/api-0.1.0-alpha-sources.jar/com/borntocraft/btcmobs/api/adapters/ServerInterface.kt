package com.borntocraft.btcmobs.api.adapters

/**
 * Marker abstraction for the platform-specific bootstrap component.
 */
interface ServerInterface
