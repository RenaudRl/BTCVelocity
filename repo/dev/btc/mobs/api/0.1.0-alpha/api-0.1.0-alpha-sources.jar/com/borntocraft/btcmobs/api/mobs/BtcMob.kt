package com.borntocraft.btcmobs.api.mobs

import org.bukkit.Location
import org.bukkit.entity.LivingEntity

/**
 * Represents a Mythic mob template.
 *
 * A [BtcMob] defines the blueprint for a type of mob that can be spawned
 * into the world. It contains the mob's configuration, display properties,
 * default level, faction, options, and associated skills.
 */
interface BtcMob {
    /** The internal name used to identify this mob type in configuration files. */
    val internalName: String

    /** The display name shown to players, or `null` if no custom display name is set. */
    val displayName: String?

    /** The default level assigned to mobs of this type when no level override is provided. */
    val defaultLevel: Double

    /** The faction this mob belongs to, used for threat table calculations, or `null` if unaffiliated. */
    val faction: String?

    /** The configuration options for this mob type, or `null` if default options are used. */
    val options: MobOptions?

    /** The list of skills associated with this mob type. */
    val skills: List<com.borntocraft.btcmobs.api.skills.Skill>

    /**
     * Creates a new [LivingEntity] instance for this mob type at the given location and level.
     *
     * @param location The world location where the entity should be created.
     * @param level The level of the spawned entity.
     * @return A new [LivingEntity] instance configured according to this mob type's template.
     */
    fun createEntity(
        location: Location,
        level: Double,
    ): LivingEntity
}
