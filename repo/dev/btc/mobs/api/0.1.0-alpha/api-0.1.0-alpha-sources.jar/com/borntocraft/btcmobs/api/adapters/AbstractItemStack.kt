package com.borntocraft.btcmobs.api.adapters

/**
 * Mythic representation of an item stack.
 */
interface AbstractItemStack
