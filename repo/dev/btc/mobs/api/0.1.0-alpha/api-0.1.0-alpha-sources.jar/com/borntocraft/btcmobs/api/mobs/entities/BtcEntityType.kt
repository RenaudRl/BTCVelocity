package com.borntocraft.btcmobs.api.mobs.entities

/**
 * Placeholder for Mythic entity type metadata.
 */
interface BtcEntityType
