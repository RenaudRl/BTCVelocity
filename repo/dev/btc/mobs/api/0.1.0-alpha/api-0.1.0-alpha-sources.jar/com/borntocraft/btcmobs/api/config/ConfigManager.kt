package com.borntocraft.btcmobs.api.config

/**
 * Configuration access facade mirroring the MythicMobs API.
 */
interface ConfigManager
