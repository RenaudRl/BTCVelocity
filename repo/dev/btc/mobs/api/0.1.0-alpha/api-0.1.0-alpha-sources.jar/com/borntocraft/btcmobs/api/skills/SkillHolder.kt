package com.borntocraft.btcmobs.api.skills

/**
 * Marker interface for skill holders.
 *
 * Any entity or object that can hold and execute [Skill] instances should
 * implement this interface. It serves as a type marker for the skill system
 * to identify valid skill containers.
 */
interface SkillHolder
