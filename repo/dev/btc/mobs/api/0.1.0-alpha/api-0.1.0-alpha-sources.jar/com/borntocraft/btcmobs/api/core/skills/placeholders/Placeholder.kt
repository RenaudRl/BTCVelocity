package com.borntocraft.btcmobs.api.core.skills.placeholders

/**
 * Represents a placeholder binding.
 */
interface Placeholder
