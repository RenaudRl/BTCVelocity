package com.borntocraft.btcmobs.api.spawners

import org.bukkit.Location

/**
 * Detects specific structures or markers within a radius to serve as spawn points.
 */
interface StructureDetector {
    /**
     * Scans for spawn locations within [radius] of [location].
     * @return Map of label names to locations.
     */
    fun detect(
        location: Location,
        radius: Int,
    ): Map<String, Location>
}
