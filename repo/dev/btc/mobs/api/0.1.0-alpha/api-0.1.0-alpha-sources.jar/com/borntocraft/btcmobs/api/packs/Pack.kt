package com.borntocraft.btcmobs.api.packs

import java.nio.file.Path

/**
 * Represents a Mythic resource pack descriptor located on disk.
 */
interface Pack {
    /**
     * Unique identifier for the pack. Mirrors the folder name by convention.
     */
    val id: String

    /**
     * Human readable title displayed to administrators.
     */
    val name: String

    /**
     * Optional textual description of the pack content.
     */
    val description: String?

    /**
     * Semantic version of the pack.
     */
    val version: String

    /**
     * Authors credited for the pack.
     */
    val authors: List<String>

    /**
     * Root directory where the pack data is stored.
     */
    val root: Path
}
