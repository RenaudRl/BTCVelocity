package com.borntocraft.btcmobs.api.volatilecode

import org.bukkit.Location
import org.bukkit.Particle
import org.bukkit.entity.Entity
import org.bukkit.entity.LivingEntity
import org.bukkit.entity.Player
import org.bukkit.event.entity.EntityDamageEvent
import org.bukkit.util.Vector

/**
 * Volatile code bridge allowing runtime-specific behaviour backed by
 * Paper/Purpur APIs when available. Implementations are expected to be safe to
 * call on the main server thread and should fail gracefully when an operation
 * cannot be performed.
 */
interface VolatileCodeHandler {
    /**
     * Bridge providing particle spawning utilities via the volatile code handler.
     */
    val particles: ParticleBridge

    /**
     * Bridge providing low-level packet sending utilities via the volatile code handler.
     */
    val packets: PacketBridge

    /**
     * Triggers a main-hand swing animation for the provided entity.
     *
     * @return `true` if the animation could be performed, `false` otherwise.
     */
    fun swingMainHand(entity: LivingEntity): Boolean

    /**
     * Applies damage to the target entity. Implementations may fall back to
     * vanilla damage behaviour if the requested cause cannot be honoured.
     *
     * @param target entity receiving the damage.
     * @param amount damage amount, ignored when zero or negative.
     * @param source optional source responsible for the damage.
     * @param cause optional override for the damage cause.
     *
     * @return `true` when the damage call was attempted, `false` otherwise.
     */
    fun applyDamage(
        target: LivingEntity,
        amount: Double,
        source: Entity? = null,
        cause: EntityDamageEvent.DamageCause? = null,
    ): Boolean

    /**
     * Particle spawning contract exposed by the volatile code handler.
     */
    interface ParticleBridge {
        /**
         * Spawns the provided particle either globally in the world or for the
         * given set of viewers.
         *
         * @return `true` if the particle call succeeded, `false` otherwise.
         */
        fun spawn(
            particle: Particle,
            location: Location,
            count: Int = 1,
            offset: Vector = Vector(),
            extra: Double = 0.0,
            data: Any? = null,
            receivers: Collection<Player> = emptyList(),
        ): Boolean
    }

    /**
     * Packet sending contract exposed by the volatile code handler.
     */
    interface PacketBridge {
        /**
         * Sends a raw packet to the provided player.
         *
         * @return `true` if the packet could be dispatched, `false` otherwise.
         */
        fun send(
            player: Player,
            packet: Any,
        ): Boolean

        /**
         * Sends each packet from the collection to the player, returning the
         * number of successfully dispatched packets.
         */
        fun send(
            player: Player,
            packets: Collection<Any>,
        ): Int

        /**
         * Convenience overload to send multiple packets.
         */
        fun send(
            player: Player,
            vararg packets: Any,
        ): Int = send(player, packets.toList())
    }
}
