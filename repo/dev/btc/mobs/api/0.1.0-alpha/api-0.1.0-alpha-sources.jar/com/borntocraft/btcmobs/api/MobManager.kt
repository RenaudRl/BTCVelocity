package com.borntocraft.btcmobs.api

import org.bukkit.entity.LivingEntity
import java.util.UUID

/**
 * Read-only information about an active BTCMob.
 */
interface ActiveMobInfo {
    /** Unique UUID of this mob instance */
    val uuid: UUID

    /** Internal mob type identifier */
    val mobType: String

    /** Display name (if set) */
    val displayName: String?

    /** The underlying Bukkit entity */
    val entity: LivingEntity

    /** Current level of the mob */
    val level: Int

    /** Whether this mob is still alive */
    val isAlive: Boolean
}

/**
 * API for accessing active mob information.
 */
interface MobManager {
    /**
     * Get an active mob by its UUID.
     */
    fun getActiveMob(uuid: UUID): ActiveMobInfo?

    /**
     * Get an active mob from a Bukkit entity.
     */
    fun getActiveMob(entity: LivingEntity): ActiveMobInfo?

    /**
     * Get all active mobs.
     */
    fun getActiveMobs(): Collection<ActiveMobInfo>

    /**
     * Get all active mobs of a specific type.
     */
    fun getActiveMobsByType(mobType: String): Collection<ActiveMobInfo>

    /**
     * Check if an entity is a BTCMob.
     */
    fun isBtcMob(entity: LivingEntity): Boolean

    /**
     * Get all registered mob type identifiers.
     */
    fun getRegisteredMobTypes(): Set<String>
}
