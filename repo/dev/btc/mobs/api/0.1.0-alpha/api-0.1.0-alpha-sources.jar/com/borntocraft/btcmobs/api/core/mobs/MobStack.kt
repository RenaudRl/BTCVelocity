package com.borntocraft.btcmobs.api.core.mobs

/**
 * Represents a Mythic mob stack definition.
 */
interface MobStack
