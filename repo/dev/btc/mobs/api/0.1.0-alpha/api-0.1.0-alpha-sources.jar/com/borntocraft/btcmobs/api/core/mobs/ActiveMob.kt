package com.borntocraft.btcmobs.api.core.mobs

import org.bukkit.Location
import org.bukkit.entity.LivingEntity
import com.borntocraft.btcmobs.api.mobs.BtcMob
import java.util.UUID

/**
 * Wrapper for a spawned Mythic mob.
 */
interface ActiveMob {
    val uniqueId: UUID

    val mobType: BtcMob

    val entity: LivingEntity

    var level: Double

    var customNbt: Map<String, String>

    var scoreboardTags: Set<String>

    val threatTable: ThreatTable

    val power: Double

    val spawnLocation: Location

    var trackedLocation: Location?

    val faction: String?

    var parentId: UUID?

    val childIds: MutableSet<UUID>

    var stance: String

    val lastSignal: String?

    fun tick()

    fun despawn(reason: DespawnReason = DespawnReason.PLUGIN)

    fun signal(signal: String)

    fun remove()

    fun isDead(): Boolean
}
