package com.borntocraft.btcmobs.api.core.skills.variables

import java.time.Clock
import java.time.Instant

/**
 * Holds the effective value of a variable along with metadata.
 */
data class VariableValue<T : Any>(
    val typeId: String,
    val value: T,
    val expiresAtEpochMillis: Long? = null,
) {
    fun isExpired(clock: Clock = Clock.systemUTC()): Boolean = expiresAtEpochMillis?.let { it <= clock.millis() } ?: false

    fun expiresAtInstant(): Instant? = expiresAtEpochMillis?.let(Instant::ofEpochMilli)
}

fun <T : Any> VariableType<T>.createValue(
    value: T,
    expiresAt: Instant? = null,
): VariableValue<T> = VariableValue(id, value, expiresAt?.toEpochMilli())
