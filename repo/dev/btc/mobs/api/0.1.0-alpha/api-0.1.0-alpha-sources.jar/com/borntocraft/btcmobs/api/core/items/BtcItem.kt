package com.borntocraft.btcmobs.api.core.items

/**
 * Represents a Mythic item definition.
 */
interface BtcItem
