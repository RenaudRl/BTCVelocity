package com.borntocraft.btcmobs.api.core.skills

/**
 * Result of executing skill mechanics.
 */
interface TriggeredSkill
