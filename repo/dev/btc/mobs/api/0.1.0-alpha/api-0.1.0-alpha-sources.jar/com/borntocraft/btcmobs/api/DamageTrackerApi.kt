package com.borntocraft.btcmobs.api

import org.bukkit.entity.LivingEntity
import java.util.UUID

/**
 * Read-only snapshot of damage contribution from a player.
 */
interface DamageContribution {
    /** UUID of the player who dealt damage */
    val playerUuid: UUID

    /** Player name at time of contribution */
    val playerName: String

    /** Total damage dealt by this player */
    val totalDamage: Double

    /** Percentage of total boss damage */
    val percentage: Double
}

/**
 * Read-only snapshot of tracked damage for a boss entity.
 */
interface TrackedDamageInfo {
    /** UUID of the tracked boss */
    val bossUuid: UUID

    /** Total damage dealt to the boss */
    val totalDamage: Double

    /** All damage contributions sorted by damage (descending) */
    val contributions: List<DamageContribution>

    /** Top N contributors */
    fun topContributors(n: Int): List<DamageContribution>

    /** Get contribution for a specific player */
    fun getContribution(playerUuid: UUID): DamageContribution?
}

/**
 * Public API for accessing damage tracking information.
 */
interface DamageTrackerApi {
    /**
     * Get tracked damage info for a specific boss entity.
     * @return TrackedDamageInfo or null if entity is not tracked
     */
    fun getTrackedDamage(entity: LivingEntity): TrackedDamageInfo?

    /**
     * Get tracked damage info by boss UUID.
     * @return TrackedDamageInfo or null if not found
     */
    fun getTrackedDamage(bossUuid: UUID): TrackedDamageInfo?

    /**
     * Check if an entity is being tracked for damage.
     */
    fun isTracked(entity: LivingEntity): Boolean

    /**
     * Get all currently tracked boss UUIDs.
     */
    fun getTrackedBosses(): Set<UUID>
}
