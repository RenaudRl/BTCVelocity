package com.borntocraft.btcmobs.api.skills.placeholders

import com.borntocraft.btcmobs.api.core.skills.placeholders.Placeholder
import com.borntocraft.btcmobs.api.core.skills.placeholders.PlaceholderExecutor
import com.borntocraft.btcmobs.api.core.skills.placeholders.PlaceholderParser

/**
 * Registry and dispatcher for Mythic placeholders.
 *
 * Manages the registration and lookup of [Placeholder] instances across
 * namespaces, as well as custom [PlaceholderParser]s for resolving
 * placeholder expressions at runtime.
 */
interface PlaceholderManager {
    /**
     * Registers a placeholder under multiple namespaces.
     *
     * @param namespaces the array of namespace strings under which the placeholder is accessible.
     * @param placeholder the [Placeholder] instance to register.
     */
    fun register(
        namespaces: Array<String>,
        placeholder: Placeholder,
    )

    /**
     * Registers a placeholder under a single namespace.
     *
     * @param namespace the namespace under which the placeholder is accessible.
     * @param placeholder the [Placeholder] instance to register.
     */
    fun register(
        namespace: String,
        placeholder: Placeholder,
    )

    /**
     * Resolves a placeholder entry from its full path string.
     *
     * @param path the placeholder path (e.g. `"namespace:identifier"`).
     * @return the resolved [PlaceholderExecutor.PlaceholderEntry].
     */
    fun getPlaceholder(path: String): PlaceholderExecutor.PlaceholderEntry

    /**
     * Registers a custom placeholder parser.
     *
     * @param parser the [PlaceholderParser] to register for resolving placeholder expressions.
     */
    fun registerParser(parser: PlaceholderParser)

    /**
     * Triggers a re-check of all registered placeholders, refreshing their
     * resolved values where applicable.
     */
    fun recheckForPlaceholders()
}
