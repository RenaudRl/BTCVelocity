package com.borntocraft.btcmobs.api.spawners

import org.bukkit.Location

/**
 * Manages spawner systems and structure detection.
 */
interface SpawnerManager {
    /**
     * Registers a new structure detector.
     */
    fun registerStructureDetector(
        name: String,
        detector: StructureDetector,
    )

    /**
     * Aggregates results from all registered detectors.
     */
    fun detectLabels(
        location: Location,
        radius: Int,
    ): Map<String, Location>
}
