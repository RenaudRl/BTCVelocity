package com.borntocraft.btcmobs.api

import java.util.Collections
import java.util.concurrent.ConcurrentSkipListSet

class MutableBtcMobsRegistry : BtcMobsRegistry {
    private val registered: MutableSet<String> = ConcurrentSkipListSet()

    override fun registerMob(identifier: String) {
        registered += identifier
    }

    override fun registeredMobs(): Set<String> = Collections.unmodifiableSet(registered)
}
