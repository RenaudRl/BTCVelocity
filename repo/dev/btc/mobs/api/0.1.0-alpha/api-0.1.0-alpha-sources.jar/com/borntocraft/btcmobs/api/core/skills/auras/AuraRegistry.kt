package com.borntocraft.btcmobs.api.core.skills.auras

/**
 * Registry for active auras on an entity.
 */
interface AuraRegistry {
    /**
     * Checks if the entity has an aura with the given name.
     */
    fun hasAura(name: String): Boolean

    /**
     * Gets the number of stacks of the given aura.
     */
    fun getStacks(name: String): Int

    /**
     * Removes all stacks of the given aura.
     */
    fun removeAura(name: String)

    /**
     * Removes a specific amount of stacks from the given aura.
     */
    fun removeStacks(
        name: String,
        amount: Int,
    )
}
