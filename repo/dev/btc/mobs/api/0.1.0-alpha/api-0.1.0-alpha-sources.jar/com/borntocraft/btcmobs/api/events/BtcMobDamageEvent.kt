package com.borntocraft.btcmobs.api.events

import net.kyori.adventure.text.Component
import org.bukkit.entity.Entity
import org.bukkit.event.Cancellable
import org.bukkit.event.HandlerList
import org.bukkit.event.entity.EntityDamageEvent
import com.borntocraft.btcmobs.api.core.mobs.ActiveMob

/**
 * Fired whenever a BTCMob is about to take damage.
 *
 * Integrations may cancel the event, adjust [damage] or provide feedback via [feedbackMessage].
 */
public class BtcMobDamageEvent(
    activeMob: ActiveMob,
    public val damager: Entity?,
    public var damage: Double,
    public val cause: EntityDamageEvent.DamageCause,
    /** Optional Adventure component sent to participants to describe the interaction. */
    public var feedbackMessage: Component? = null,
) : BtcMobEvent(activeMob), Cancellable {
    private var cancelled: Boolean = false

    override fun isCancelled(): Boolean = cancelled

    override fun setCancelled(cancel: Boolean) {
        cancelled = cancel
    }

    override fun getHandlers(): HandlerList = HANDLERS

    public companion object {
        @JvmStatic
        private val HANDLERS = HandlerList()

        @JvmStatic
        public fun getHandlerList(): HandlerList = HANDLERS
    }
}
