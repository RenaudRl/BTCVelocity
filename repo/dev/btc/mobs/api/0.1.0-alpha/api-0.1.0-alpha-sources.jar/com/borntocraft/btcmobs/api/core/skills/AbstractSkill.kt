package com.borntocraft.btcmobs.api.core.skills

import com.borntocraft.btcmobs.api.skills.Skill

/**
 * Base type for compiled Mythic skill implementations.
 */
interface AbstractSkill : Skill
