package com.borntocraft.btcmobs.api.skills

import com.borntocraft.btcmobs.api.BtcPlugin
import com.borntocraft.btcmobs.api.adapters.AbstractEntity
import com.borntocraft.btcmobs.api.adapters.AbstractLocation
import com.borntocraft.btcmobs.api.config.MythicLineConfig
import com.borntocraft.btcmobs.api.core.skills.AbstractSkill
import com.borntocraft.btcmobs.api.core.skills.SkillAudience
import com.borntocraft.btcmobs.api.core.skills.SkillCondition
import com.borntocraft.btcmobs.api.core.skills.SkillMechanic
import com.borntocraft.btcmobs.api.core.skills.SkillTargeter
import com.borntocraft.btcmobs.api.skills.auras.AuraManager
import java.io.File
import java.util.Collection
import java.util.List
import java.util.Optional

/**
 * Central registry and execution coordinator for Mythic skills.
 *
 * This interface provides the primary API for registering, looking up, and executing
 * Mythic skills within the BornToCraft runtime. It manages skill cooldowns, mechanic
 * and condition registration, targeter resolution, and the full skill lifecycle from
 * trigger to execution result.
 *
 * Implementations are expected to be thread-safe for read operations and should
 * document any thread-safety constraints for mutation operations.
 */
interface SkillManager {
    /** The parent plugin instance that owns this manager. */
    val plugin: BtcPlugin

    /** The aura manager used to query and modify entity auras during skill execution. */
    val auraManager: AuraManager

    /** The event bus used to dispatch skill trigger events. */
    val eventBus: SkillEventBus

    /**
     * Queues a task to be executed during the second pass of plugin loading.
     *
     * Second-pass tasks run after all packs have been loaded but before the plugin
     * is fully enabled, allowing cross-referencing between packs.
     *
     * @param task The runnable task to execute during the second pass.
     */
    fun queueSecondPass(task: Runnable)

    /**
     * Queues a task to be executed after the plugin has fully loaded.
     *
     * After-load tasks run once during startup after all initialization is complete.
     *
     * @param task The runnable task to execute after loading completes.
     */
    fun queueAfterLoad(task: Runnable)

    /**
     * Returns a [SkillCaster] wrapper for the given entity.
     *
     * @param entity The entity to wrap as a skill caster.
     * @return A [SkillCaster] instance associated with the entity.
     */
    fun getCaster(entity: AbstractEntity): SkillCaster

    /**
     * Registers a skill definition under the given name.
     *
     * If a skill with the same name already exists, the behaviour is implementation-defined
     * (typically the new registration replaces the old one).
     *
     * @param name The unique name to register the skill under.
     * @param skill The skill definition to register.
     */
    fun registerSkill(
        name: String,
        skill: Skill,
    )

    /**
     * Looks up a skill by its registered name.
     *
     * @param name The name of the skill to look up.
     * @return An [Optional] containing the skill if found, or empty if no skill is registered under the given name.
     */
    fun getSkill(name: String): Optional<Skill>

    /**
     * Looks up a skill by name within a specific configuration file context.
     *
     * @param file The configuration file that defines the skill.
     * @param name The name of the skill to look up.
     * @return An [Optional] containing the skill if found, or empty if no matching skill exists.
     */
    fun getSkill(
        file: File,
        name: String,
    ): Optional<Skill>

    /**
     * Looks up a skill by name within a specific file and skill holder context.
     *
     * @param file The configuration file that defines the skill.
     * @param holder The skill holder that owns the skill definition.
     * @param name The name of the skill to look up.
     * @return An [Optional] containing the skill if found, or empty if no matching skill exists.
     */
    fun getSkill(
        file: File,
        holder: SkillHolder,
        name: String,
    ): Optional<Skill>

    /**
     * Returns the names of all registered skills.
     *
     * @return A collection of registered skill names.
     */
    fun getSkillNames(): Collection<String>

    /**
     * Returns all registered skill definitions.
     *
     * @return A collection of all registered [Skill] instances.
     */
    fun getSkills(): Collection<Skill>

    /**
     * Sets a cooldown for a specific skill on a caster.
     *
     * While the cooldown is active, subsequent attempts to execute the same skill
     * on the same caster will be blocked.
     *
     * @param caster The entity whose cooldown is being set.
     * @param skill The skill to put on cooldown.
     * @param ticks The duration of the cooldown in server ticks.
     */
    fun setSkillCooldown(
        caster: SkillCaster,
        skill: AbstractSkill,
        ticks: Double,
    )

    /**
     * Checks whether a specific skill is currently on cooldown for the given caster.
     *
     * @param caster The entity to check.
     * @param skill The skill to check.
     * @return `true` if the skill is on cooldown for the caster, `false` otherwise.
     */
    fun isSkillOnCooldown(
        caster: SkillCaster,
        skill: AbstractSkill,
    ): Boolean

    /**
     * Clears all skill cooldowns for the given caster.
     *
     * @param caster The entity whose cooldowns should be cleared.
     */
    fun clearSkillCooldowns(caster: SkillCaster)

    /**
     * Returns the remaining cooldown time for a skill on a caster.
     *
     * @param caster The entity to check.
     * @param skill The skill to check.
     * @return The remaining cooldown in milliseconds, or 0 if the skill is not on cooldown.
     */
    fun getSkillCooldownRemainingMillis(
        caster: SkillCaster,
        skill: AbstractSkill,
    ): Long

    /**
     * Removes the cooldown for a specific skill on a caster, allowing immediate re-execution.
     *
     * @param caster The entity whose cooldown should be removed.
     * @param skill The skill to remove the cooldown for.
     */
    fun removeSkillCooldown(
        caster: SkillCaster,
        skill: AbstractSkill,
    )

    /**
     * Purges all expired cooldown entries from the internal cache.
     *
     * This is called periodically to prevent memory leaks from accumulated cooldown data.
     */
    fun purgeExpiredCooldowns()

    /**
     * Executes a skill with the provided metadata and optional trigger.
     *
     * @param skill The skill definition to execute.
     * @param metadata The runtime metadata for the execution context.
     * @param trigger An optional trigger that initiated the skill execution.
     * @return A [SkillExecutionResult] describing the outcome of the execution.
     */
    fun execute(
        skill: Skill,
        metadata: SkillMetadata,
        trigger: SkillTrigger? = null,
    ): SkillExecutionResult

    /**
     * Resolves and executes the skill registered under the given name.
     *
     * @param skillName The name of the skill to resolve and execute.
     * @param metadata The runtime metadata for the execution context.
     * @param trigger An optional trigger that initiated the skill execution.
     * @return A [SkillExecutionResult] describing the outcome of the execution.
     */
    fun execute(
        skillName: String,
        metadata: SkillMetadata,
        trigger: SkillTrigger? = null,
    ): SkillExecutionResult

    /**
     * Looks up a registered mechanic by name.
     *
     * @param name The name of the mechanic to look up.
     * @return The [SkillMechanic] instance associated with the name.
     * @throws IllegalArgumentException if no mechanic is registered under the given name.
     */
    fun getMechanic(name: String): SkillMechanic

    /**
     * Resolves a targeter by name with the provided configuration.
     *
     * @param name The name of the targeter to resolve.
     * @param config The line configuration containing targeter parameters.
     * @return A configured [SkillTargeter] instance.
     * @throws IllegalArgumentException if no targeter is registered under the given name.
     */
    fun getTargeter(
        name: String,
        config: MythicLineConfig,
    ): SkillTargeter

    /**
     * Looks up a registered targeter by name.
     *
     * @param name The name of the targeter to look up.
     * @return The [SkillTargeter] instance associated with the name.
     * @throws IllegalArgumentException if no targeter is registered under the given name.
     */
    fun getTargeter(name: String): SkillTargeter

    /**
     * Resolves the target location from a targeter using the provided metadata.
     *
     * @param targeter The targeter to resolve the location from.
     * @param metadata The runtime metadata for the execution context.
     * @return The resolved [AbstractLocation] target.
     */
    fun getLocationTarget(
        targeter: SkillTargeter,
        metadata: SkillMetadata,
    ): AbstractLocation

    /**
     * Looks up a registered condition by name.
     *
     * @param name The name of the condition to look up.
     * @return The [SkillCondition] instance associated with the name.
     * @throws IllegalArgumentException if no condition is registered under the given name.
     */
    fun getCondition(name: String): SkillCondition

    /**
     * Resolves multiple conditions by their names.
     *
     * @param names The names of the conditions to resolve.
     * @return A list of [SkillCondition] instances in the same order as the input names.
     * @throws IllegalArgumentException if any condition name is not registered.
     */
    fun getConditions(names: List<String>): List<SkillCondition>

    /**
     * Resolves a comma-separated list of condition names.
     *
     * @param name A comma-separated string of condition names.
     * @return A list of [SkillCondition] instances.
     * @throws IllegalArgumentException if any condition name is not registered.
     */
    fun getConditions(name: String): List<SkillCondition>

    /**
     * Looks up a registered audience by name.
     *
     * @param name The name of the audience to look up.
     * @return The [SkillAudience] instance associated with the name.
     * @throws IllegalArgumentException if no audience is registered under the given name.
     */
    fun getAudience(name: String): SkillAudience

    // Registration API

    /**
     * Registers a custom mechanic handler under the given name.
     *
     * @param name The unique name to register the mechanic under.
     * @param handler The handler that implements the mechanic logic.
     */
    fun registerMechanic(
        name: String,
        handler: com.borntocraft.btcmobs.api.core.skills.MechanicHandler,
    )

    /**
     * Registers a custom condition handler under the given name.
     *
     * @param name The unique name to register the condition under.
     * @param handler The handler that implements the condition logic.
     */
    fun registerCondition(
        name: String,
        handler: com.borntocraft.btcmobs.api.core.skills.ConditionHandler,
    )

    /**
     * Registers a custom targeter handler under the given name.
     *
     * @param name The unique name to register the targeter under.
     * @param handler The handler that implements the targeter logic.
     */
    fun registerTargeter(
        name: String,
        handler: com.borntocraft.btcmobs.api.core.skills.TargeterHandler,
    )

    /**
     * Unregisters a previously registered mechanic.
     *
     * @param name The name of the mechanic to unregister.
     * @return `true` if the mechanic was found and removed, `false` if it was not registered.
     */
    fun unregisterMechanic(name: String): Boolean

    /**
     * Unregisters a previously registered condition.
     *
     * @param name The name of the condition to unregister.
     * @return `true` if the condition was found and removed, `false` if it was not registered.
     */
    fun unregisterCondition(name: String): Boolean

    /**
     * Unregisters a previously registered targeter.
     *
     * @param name The name of the targeter to unregister.
     * @return `true` if the targeter was found and removed, `false` if it was not registered.
     */
    fun unregisterTargeter(name: String): Boolean
}
