package com.borntocraft.btcmobs.api.core.skills

/**
 * Identifies the set of receivers for a skill effect.
 */
interface SkillAudience
