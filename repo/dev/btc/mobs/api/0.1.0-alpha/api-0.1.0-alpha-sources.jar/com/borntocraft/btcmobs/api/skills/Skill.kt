package com.borntocraft.btcmobs.api.skills

/**
 * Represents a Mythic skill definition.
 *
 * A skill is the fundamental unit of behaviour in the MythicMobs system.
 * Implementations define how a skill is triggered, what conditions must be met,
 * and what actions are executed when the skill fires.
 */
interface Skill
