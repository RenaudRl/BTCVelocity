package com.borntocraft.btcmobs.api.core.skills

import com.borntocraft.btcmobs.api.adapters.AbstractEntity
import com.borntocraft.btcmobs.api.adapters.AbstractLocation

interface SkillTarget {
    val location: AbstractLocation

    interface Entity : SkillTarget {
        val entity: AbstractEntity
    }

    interface Location : SkillTarget
}
