package com.borntocraft.btcmobs.api.core.mobs

import java.util.Locale
import java.util.UUID

/**
 * Stores combat threat values for entities interacting with an [ActiveMob].
 */
interface ThreatTable {
    /**
     * Updates the behavioural settings used by the table. Implementations may ignore this call when configuration is
     * immutable.
     */
    fun configure(settings: ThreatSettings) {}

    /** Adds [amount] to the existing threat value for the [targetId]. */
    fun addThreat(
        targetId: UUID,
        amount: Double,
        faction: String? = null,
        timestamp: Long = System.currentTimeMillis(),
    )

    /** Updates the faction associated with [targetId], if it is being tracked. */
    fun setFaction(
        targetId: UUID,
        faction: String?,
    ) {}

    /** Invoked periodically to allow the table to apply threat decay or cleanup logic. */
    fun tick(currentTimeMillis: Long = System.currentTimeMillis()) {}

    /** Returns the threat currently associated with [targetId]. */
    fun getThreat(targetId: UUID): Double

    /** Removes a previously tracked [targetId] from the table. */
    fun removeThreat(targetId: UUID)

    /** Clears every tracked entry. */
    fun reset()

    /** Returns an immutable snapshot of the tracked threat values. */
    val entries: Collection<ThreatEntry>

    /** The highest threat entry currently tracked, if any. */
    val highestThreat: ThreatEntry?

    data class ThreatEntry(
        val targetId: UUID,
        val threat: Double,
        val faction: String?,
        val lastUpdated: Long,
        val disposition: ThreatSettings.FactionDisposition,
    ) {
        val isHostile: Boolean
            get() = disposition == ThreatSettings.FactionDisposition.ENEMY

        val isAlly: Boolean
            get() = disposition == ThreatSettings.FactionDisposition.ALLY

        val isNeutral: Boolean
            get() = disposition == ThreatSettings.FactionDisposition.NEUTRAL
    }

    data class ThreatSettings(
        val gainMultiplier: Double = 1.0,
        val decayPerSecond: Double = 0.0,
        val minimumThreat: Double = 0.0,
        val factions: FactionRelationships = FactionRelationships(),
    ) {
        data class FactionRelationships(
            val faction: String? = null,
            val allies: Set<String> = emptySet(),
            val enemies: Set<String> = emptySet(),
            val neutrals: Set<String> = emptySet(),
            val respectNeutrals: Boolean = false,
            val treatUnknownAsEnemy: Boolean = true,
        ) {
            fun dispositionOf(faction: String?): FactionDisposition {
                val normalized = faction?.trim()?.lowercase(Locale.ROOT)
                val selfFaction = this.faction?.trim()?.lowercase(Locale.ROOT)
                if (normalized.isNullOrEmpty()) {
                    return if (treatUnknownAsEnemy) FactionDisposition.ENEMY else FactionDisposition.UNKNOWN
                }
                if (selfFaction != null && normalized == selfFaction) {
                    return FactionDisposition.ALLY
                }
                if (enemies.any { it.equals(normalized, ignoreCase = true) }) {
                    return FactionDisposition.ENEMY
                }
                if (allies.any { it.equals(normalized, ignoreCase = true) }) {
                    return FactionDisposition.ALLY
                }
                if (neutrals.any { it.equals(normalized, ignoreCase = true) }) {
                    return if (respectNeutrals) FactionDisposition.NEUTRAL else FactionDisposition.ENEMY
                }
                return if (respectNeutrals) FactionDisposition.NEUTRAL else FactionDisposition.ENEMY
            }
        }

        enum class FactionDisposition {
            ENEMY,
            ALLY,
            NEUTRAL,
            UNKNOWN,
        }
    }
}
