package com.borntocraft.btcmobs.api.core.mobs

import com.borntocraft.btcmobs.api.mobs.BtcMob

/**
 * Options used when spawning a new [ActiveMob].
 */
data class MobSpawnOptions(
    val level: Double? = null,
    val levelProvider: ((BtcMob) -> Double)? = null,
    val scoreboardTags: Set<String> = emptySet(),
    val customNbt: Map<String, String> = emptyMap(),
    val model: MobModelConfiguration? = null,
)
