package com.borntocraft.btcmobs.api.core.skills

/**
 * Represents Mythic targeter implementations.
 */
interface SkillTargeter
