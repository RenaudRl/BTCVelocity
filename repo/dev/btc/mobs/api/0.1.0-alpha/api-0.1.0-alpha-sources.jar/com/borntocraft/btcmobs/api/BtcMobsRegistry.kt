package com.borntocraft.btcmobs.api

/**
 * Public API surface for BornToCraft custom mobs modules.
 */
interface BtcMobsRegistry {
    /**
     * Registers a custom mob identifier to make it available to the BornToCraft ecosystem.
     */
    fun registerMob(identifier: String)

    /**
     * Returns the list of mobs that were previously registered.
     */
    fun registeredMobs(): Set<String>
}
