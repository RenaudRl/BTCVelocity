package com.borntocraft.btcmobs.api.core.drops

/**
 * Represents a Mythic drop table definition.
 */
interface DropTable
