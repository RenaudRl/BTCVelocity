package com.borntocraft.btcmobs.api.core.mobs

/**
 * Handles Mythic egg interactions.
 */
interface EggExecutor
