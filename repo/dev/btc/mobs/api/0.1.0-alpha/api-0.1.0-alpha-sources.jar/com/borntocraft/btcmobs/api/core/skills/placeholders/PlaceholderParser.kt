package com.borntocraft.btcmobs.api.core.skills.placeholders

/**
 * Parses placeholder patterns.
 */
interface PlaceholderParser
