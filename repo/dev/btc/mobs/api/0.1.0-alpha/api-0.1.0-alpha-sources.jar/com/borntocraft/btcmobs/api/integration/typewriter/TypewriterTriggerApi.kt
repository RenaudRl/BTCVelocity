package com.borntocraft.btcmobs.api.integration.typewriter

import com.borntocraft.btcmobs.api.skills.SkillExecutionResult
import com.borntocraft.btcmobs.api.skills.SkillMetadata
import com.borntocraft.btcmobs.api.skills.SkillTrigger

/**
 * Optional service exposed by the Typewriter plugin to listen to Mythic skill executions.
 */
interface TypewriterTriggerApi {
    fun publishSkillTrigger(
        skillName: String,
        trigger: SkillTrigger?,
        metadata: SkillMetadata,
        result: SkillExecutionResult,
    )
}
