package com.borntocraft.btcmobs.api.skills

import com.borntocraft.btcmobs.api.adapters.AbstractEntity

/**
 * Base contract for a skill caster wrapper.
 */
interface SkillCaster {
    val entity: AbstractEntity
}
