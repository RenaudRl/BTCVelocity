package com.borntocraft.btcmobs.api.items

import org.bukkit.inventory.ItemStack
import com.borntocraft.btcmobs.api.core.items.BtcItem
import java.util.Optional

/**
 * Registry of Mythic items and suppliers.
 *
 * Provides methods to query, register, and filter [BtcItem] instances
 * as well as their associated [ItemSupplier]s.
 */
interface ItemManager {
    /**
     * Registers an [ItemSupplier] that can provide Mythic items at runtime.
     *
     * @param supplier the supplier to register.
     */
    fun registerItemSupplier(supplier: ItemSupplier)

    /**
     * Returns all registered Mythic items.
     *
     * @return a collection of all known [BtcItem] instances.
     */
    fun getItems(): Collection<BtcItem>

    /**
     * Returns the names of all registered Mythic items.
     *
     * @return a collection of item name strings.
     */
    fun getItemNames(): Collection<String>

    /**
     * Retrieves a Mythic item by its name.
     *
     * @param name the name of the item to look up.
     * @return an [Optional] containing the [BtcItem] if found, or empty otherwise.
     */
    fun getItem(name: String): Optional<BtcItem>

    /**
     * Checks whether the given [ItemStack] represents a Mythic item.
     *
     * @param itemStack the item stack to check.
     * @return `true` if the item stack is a Mythic item, `false` otherwise.
     */
    fun isMythicItem(itemStack: ItemStack): Boolean

    /**
     * Returns the Mythic item type identifier from the given [ItemStack].
     *
     * @param itemStack the item stack to inspect.
     * @return the Mythic type string, or an empty string if not a Mythic item.
     */
    fun getMythicTypeFromItem(itemStack: ItemStack): String

    /**
     * Filters a collection of Mythic items by a search string.
     *
     * @param items the collection of [BtcItem] instances to filter.
     * @param search the search string to match against item names or properties.
     * @return a filtered collection of [BtcItem] instances matching the search.
     */
    fun filterItems(
        items: Collection<BtcItem>,
        search: String,
    ): Collection<BtcItem>
}
