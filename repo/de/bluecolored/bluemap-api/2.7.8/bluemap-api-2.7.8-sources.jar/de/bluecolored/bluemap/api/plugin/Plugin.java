/*
 * This file is part of BlueMap, licensed under the MIT License (MIT).
 *
 * Copyright (c) Blue (Lukas Rieger) <https://bluecolored.de>
 * Copyright (c) contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package de.bluecolored.bluemap.api.plugin;

@SuppressWarnings("unused")
public interface Plugin {

    /**
     * Get the {@link SkinProvider} that bluemap is using to fetch player-skins
     * @return the {@link SkinProvider} instance bluemap is using
     */
    SkinProvider getSkinProvider();

    /**
     * Sets the {@link SkinProvider} that bluemap will use to fetch new player-skins.
     * @param skinProvider The new {@link SkinProvider} bluemap should use
     */
    void setSkinProvider(SkinProvider skinProvider);

    /**
     * Get the {@link PlayerIconFactory} that bluemap is using to convert a player-skin into the icon-image that is used
     * for the Player-Markers
     * @return The {@link PlayerIconFactory} bluemap uses to convert skins into player-marker icons
     */
    PlayerIconFactory getPlayerMarkerIconFactory();

    /**
     * Set the {@link PlayerIconFactory} that bluemap will use to convert a player-skin into the icon-image that is used
     * for the Player-Markers
     * @param playerMarkerIconFactory The {@link PlayerIconFactory} bluemap uses to convert skins into player-marker icons
     */
    void setPlayerMarkerIconFactory(PlayerIconFactory playerMarkerIconFactory);

}
