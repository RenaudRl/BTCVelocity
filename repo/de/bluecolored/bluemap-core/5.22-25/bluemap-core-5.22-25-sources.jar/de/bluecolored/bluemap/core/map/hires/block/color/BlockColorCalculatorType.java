/*
 * This file is part of BlueMap, licensed under the MIT License (MIT).
 *
 * Copyright (c) Blue (Lukas Rieger) <https://bluecolored.de>
 * Copyright (c) contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package de.bluecolored.bluemap.core.map.hires.block.color;

import de.bluecolored.bluemap.core.util.Key;
import de.bluecolored.bluemap.core.util.Keyed;
import de.bluecolored.bluemap.core.util.Registry;
import de.bluecolored.bluemap.core.util.math.Color;
import de.bluecolored.bluemap.core.world.biome.Biome;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.experimental.Delegate;

public interface BlockColorCalculatorType extends Keyed, BlockColorCalculatorFactory {

    BlockColorCalculatorType FOLIAGE = new Impl(Key.minecraft("foliage"), BlockColorCalculatorFactory
            .colorMap(Key.minecraft("colormap/foliage"), new Color().set(0xff48B518, true))
            .withBiomeOverlay(Biome::getOverlayFoliageColor)
            .blended()
    );

    BlockColorCalculatorType DRY_FOLIAGE = new Impl(Key.minecraft("dry_foliage"), BlockColorCalculatorFactory
            .colorMap(Key.minecraft("colormap/dry_foliage"), new Color().set(0xff8f5f33, true))
            .withBiomeOverlay(Biome::getOverlayFoliageColor)
            .blended()
    );

    BlockColorCalculatorType GRASS = new Impl(Key.minecraft("grass"), BlockColorCalculatorFactory
            .colorMap(Key.minecraft("colormap/grass"), new Color().set(0xff52952f, true))
            .withBiomeOverlay(Biome::getOverlayGrassColor)
            .withBiomeColorModifier(Biome::getGrassColorModifier)
            .blended()
    );

    BlockColorCalculatorType WATER = new Impl(Key.minecraft("water"), BlockColorCalculatorFactory
            .biome(Biome::getWaterColor)
            .blended()
    );

    BlockColorCalculatorType REDSTONE = new Impl(Key.minecraft("redstone"), _ ->
            new RedstoneBlockColorCalculator()
    );

    Registry<BlockColorCalculatorType> REGISTRY = new Registry<>(
            FOLIAGE,
            DRY_FOLIAGE,
            GRASS,
            WATER,
            REDSTONE
    );

    @RequiredArgsConstructor
    class Impl implements BlockColorCalculatorType {

        @Getter private final Key key;
        @Delegate private final BlockColorCalculatorFactory colorCalculatorFactory;

    }

}
