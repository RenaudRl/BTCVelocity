/*
 * This file is part of BlueMap, licensed under the MIT License (MIT).
 *
 * Copyright (c) Blue (Lukas Rieger) <https://bluecolored.de>
 * Copyright (c) contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package de.bluecolored.bluemap.core.util;

import com.flowpowered.math.vector.Vector2i;

public class Vector2iCache {

    private static final int CACHE_SIZE = 0x4000;
    private static final int CACHE_MASK = CACHE_SIZE - 1;
    private final Vector2i[] cache;

    public Vector2iCache() {
        this.cache = new Vector2i[CACHE_SIZE];
    }

    public Vector2i get(int x, int y) {
        int cacheIndex = (x * 1456 ^ y * 948375892) & CACHE_MASK;
        Vector2i possibleMatch = cache[cacheIndex];

        if (possibleMatch != null && possibleMatch.getX() == x && possibleMatch.getY() == y) {
            return possibleMatch;
        }
        return cache[cacheIndex] = new Vector2i(x, y);
    }

}
