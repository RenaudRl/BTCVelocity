/*
 * This file is part of BlueMap, licensed under the MIT License (MIT).
 *
 * Copyright (c) Blue (Lukas Rieger) <https://bluecolored.de>
 * Copyright (c) contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package de.bluecolored.bluemap.core.map.hires.entity;

import de.bluecolored.bluemap.core.util.Key;
import de.bluecolored.bluemap.core.util.Keyed;
import de.bluecolored.bluemap.core.util.Registry;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.experimental.Delegate;

public interface EntityRendererType extends Keyed, EntityRendererFactory {

    EntityRendererType DEFAULT = new Impl(Key.bluemap("default"), ResourceModelRenderer::new);
    EntityRendererType MISSING = new Impl(Key.bluemap("missing"), MissingModelRenderer::new);
    EntityRendererType ITEM_DISPLAY = new ItemDisplayRendererType();

    Registry<EntityRendererType> REGISTRY = new Registry<>(
            DEFAULT,
            MISSING,
            ITEM_DISPLAY
    );

    /**
     * If the loaded resourcepack does not have any resources for this entity, this method will be called.
     * If this method returns true, this renderer will be used to render the entity instead.
     *
     * <p>
     *     This can (and should only then) be used to provide a way of rendering entities that are completely dynamically
     *     created by a mod, and there is no way to provide static entity resources that point at the correct renderer.
     * </p>
     *
     * @param entityType The entity-type {@link Key} that was not found in the loaded resources.
     * @return true if this renderer-type can render the provided entity-type {@link Key} despite missing resources.
     */
    default boolean isFallbackFor(Key entityType) {
        return false;
    }

    @RequiredArgsConstructor
    class Impl implements EntityRendererType {

        @Getter private final Key key;
        @Delegate private final EntityRendererFactory rendererFactory;

    }

}
