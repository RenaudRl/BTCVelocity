/*
 * This file is part of BlueMap, licensed under the MIT License (MIT).
 *
 * Copyright (c) Blue (Lukas Rieger) <https://bluecolored.de>
 * Copyright (c) contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package de.bluecolored.bluemap.core.map.hires.entity;

import de.bluecolored.bluemap.core.map.TextureGallery;
import de.bluecolored.bluemap.core.map.hires.RenderSettings;
import de.bluecolored.bluemap.core.resources.pack.resourcepack.ResourcePack;
import de.bluecolored.bluemap.core.util.Key;
import lombok.Getter;

/**
 * EntityRendererType for item_display and block_display entities.
 * Provides fallback rendering for CraftEngine furniture and other display
 * entities.
 */
public class ItemDisplayRendererType implements EntityRendererType {

    public static final Key ITEM_DISPLAY = Key.minecraft("item_display");
    public static final Key BLOCK_DISPLAY = Key.minecraft("block_display");

    @Getter
    private final Key key = Key.bluemap("item_display");

    @Override
    public EntityRenderer create(ResourcePack resourcePack, TextureGallery textureGallery,
            RenderSettings renderSettings) {
        return new ItemDisplayRenderer(resourcePack, textureGallery, renderSettings);
    }

    @Override
    public boolean isFallbackFor(Key entityType) {
        // Handle both item_display and block_display entities
        return ITEM_DISPLAY.equals(entityType) || BLOCK_DISPLAY.equals(entityType);
    }
}
